---
synthetic: true
tags: [type/term]
start: 2026-06-01
end: 2026-07-23
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Summer 2026

2026-06-01 → 2026-07-23.

- Cohorts: [[Cohorts/Cohort 5 — Adjunct Faculty|Cohort 5 — Adjunct Faculty]]
- Integrity cases: not yet reported
- Meetings: [[Meetings/2026-06-03 WS5 Automation Roadmap|2026-06-03 WS5 Automation Roadmap]], [[Meetings/2026-06-17 Mock Site Visit Debrief|2026-06-17 Mock Site Visit Debrief]], [[Meetings/2026-07-08 Budget Mid-year Review|2026-07-08 Budget Mid-year Review]]
- Incidents: —
