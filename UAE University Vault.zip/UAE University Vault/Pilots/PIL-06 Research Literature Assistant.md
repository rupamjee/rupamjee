---
synthetic: true
tags: [type/pilot, ws/research-data]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# PIL-06 Research Literature Assistant

Library-run assistant ([[People/Ms. Moza Al Qubaisi-Hameli|Ms. Moza Al Qubaisi-Hameli]]) for systematic-review screening; DPIA approved 2025-12-04 ([[Datasets/DPIA Register|DPIA Register]]). Used in [[Courses/NUR 310 Evidence-Based Practice|NUR 310 Evidence-Based Practice]] and [[Courses/LNG 530 Corpus Linguistics|LNG 530 Corpus Linguistics]]. Governed by [[Policies/POL-03 Research Data Governance Framework|POL-03 Research Data Governance Framework]]; runs on [[Vendors/Qamar Cloud|Qamar Cloud]].
