---
synthetic: true
tags: [type/pilot, ws/research-data]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# PIL-05 Predictive At-Risk Model

Vendor [[Vendors/Sidra Analytics|Sidra Analytics]]; owner [[People/Ms. Hind Al Mehairbi-Yahyaee|Ms. Hind Al Mehairbi-Yahyaee]]. [[Datasets/At-Risk Model Performance & Fairness|At-Risk Model Performance & Fairness]]: AUC 0.81, recall 0.72, 1,140 students flagged (11.6%). Fairness incident [[Incidents/INC-03 At-risk model flag-rate disparity|INC-03 At-risk model flag-rate disparity]] → [[Decisions/DEC-06 Require model cards and parity thresholds|DEC-06 Require model cards and parity thresholds]]. Interventions routed to [[People/Dr. Elena Vasquez-Moreau|Dr. Elena Vasquez-Moreau]]. Concepts: [[Concepts/Learning Analytics|Learning Analytics]], [[Concepts/Algorithmic Fairness|Algorithmic Fairness]], [[Concepts/Explainability|Explainability]].
