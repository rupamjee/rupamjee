---
synthetic: true
tags: [type/pilot, ws/assessment]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# PIL-04 Grading Assistant in BUS 205

[[Courses/BUS 205 Business Communication|BUS 205 Business Communication]]; feedback-only assistant (never assigns marks). Champion [[People/Dr. Saeed Al Hosani-Mehairi|Dr. Saeed Al Hosani-Mehairi]]. DPIA approved 2026-01-15 ([[Datasets/DPIA Register|DPIA Register]]). Incident [[Incidents/INC-06 Grading assistant feedback leaked rubric weights|INC-06 Grading assistant feedback leaked rubric weights]]. Governed by [[Policies/POL-01 AI in Assessment Policy|POL-01 AI in Assessment Policy]].
