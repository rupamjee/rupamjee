---
synthetic: true
tags: [type/pilot, ws/automation]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# PIL-03 Registrar Service Chatbot

Vendor [[Vendors/Tarhal AI|Tarhal AI]]; owner [[People/Ms. Aisha Al Otaiba-Mazrui|Ms. Aisha Al Otaiba-Mazrui]]. [[Datasets/Registrar Chatbot Analytics Spring 2026|Registrar Chatbot Analytics Spring 2026]]: 38,400 queries in [[Terms/Spring 2026|Spring 2026]], 62% deflected, CSAT 4.1/5; top intents: transcript requests, add/drop deadlines, fee statements, attendance appeals. Incident [[Incidents/INC-04 Prompt injection attempt on registrar chatbot|INC-04 Prompt injection attempt on registrar chatbot]] → [[Decisions/DEC-07 Pause Tarhal contract pending remediation|DEC-07 Pause Tarhal contract pending remediation]] → [[Decisions/DEC-10 Resume Tarhal with human-in-the-loop for record lookups|DEC-10 Resume Tarhal with human-in-the-loop for record lookups]].
