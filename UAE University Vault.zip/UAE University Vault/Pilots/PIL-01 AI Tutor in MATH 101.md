---
synthetic: true
tags: [type/pilot, ws/tutor]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# PIL-01 AI Tutor in MATH 101

[[Courses/MATH 101 Calculus I|MATH 101 Calculus I]], [[Terms/Fall 2025|Fall 2025]]. Vendor [[Vendors/Falaj Learning Systems|Falaj Learning Systems]] ([[Concepts/Retrieval-Augmented Generation|Retrieval-Augmented Generation]] over the approved textbook). 6 treatment sections (n=214) vs 6 control (n=208). Results in [[Datasets/MATH 101 Tutor Pilot Outcomes|MATH 101 Tutor Pilot Outcomes]]: pass 71.5% vs 63.9%; 17 hallucinations in 9,840 interactions. Incident [[Incidents/INC-02 Tutor hallucinated a theorem statement|INC-02 Tutor hallucinated a theorem statement]]. Reviewed [[Meetings/2025-11-12 Tutor Pilot Mid-term Check|2025-11-12 Tutor Pilot Mid-term Check]], [[Meetings/2026-01-28 Tutor Pilot Results Review|2026-01-28 Tutor Pilot Results Review]] → [[Decisions/DEC-05 Extend AI tutor to CHEM 110|DEC-05 Extend AI tutor to CHEM 110]]. Owner [[People/Dr. Sara Al Marzooqi-Kindi|Dr. Sara Al Marzooqi-Kindi]]; engineer [[People/Mr. Daniel Okafor-Whitcombe|Mr. Daniel Okafor-Whitcombe]].
