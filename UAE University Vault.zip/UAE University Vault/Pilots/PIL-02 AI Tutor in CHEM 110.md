---
synthetic: true
tags: [type/pilot, ws/tutor]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# PIL-02 AI Tutor in CHEM 110

[[Courses/CHEM 110 General Chemistry|CHEM 110 General Chemistry]], [[Terms/Spring 2026|Spring 2026]], wave 2 with student-level randomisation. n=176/181; pass 68.2% vs 62.4% ([[Datasets/CHEM 110 Tutor Pilot Wave 2|CHEM 110 Tutor Pilot Wave 2]]). Same vendor and guardrails as [[Pilots/PIL-01 AI Tutor in MATH 101|PIL-01 AI Tutor in MATH 101]]. Champion [[People/Dr. Mariam Al Kuwaiti-Rumaithi|Dr. Mariam Al Kuwaiti-Rumaithi]].
