---
synthetic: true
tags: [type/concept]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Model Card

Standard documentation of a model's data, intended use, metrics and limitations. Mandatory under [[Decisions/DEC-06 Require model cards and parity thresholds|DEC-06 Require model cards and parity thresholds]]; first delivered by [[Vendors/Sidra Analytics|Sidra Analytics]] for [[Pilots/PIL-05 Predictive At-Risk Model|PIL-05 Predictive At-Risk Model]]. Assignment in [[Courses/AI 501 Machine Learning|AI 501 Machine Learning]].
