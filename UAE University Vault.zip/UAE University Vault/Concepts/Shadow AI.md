---
synthetic: true
tags: [type/concept]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Shadow AI

Use of unapproved AI tools/accounts for institutional data. 23 of 41 research groups ([[Meetings/2026-04-08 WS4 Research Data Governance Workshop|2026-04-08 WS4 Research Data Governance Workshop]]); [[Incidents/INC-05 Research data uploaded to personal AI account|INC-05 Research data uploaded to personal AI account]]; risk [[Risks/RSK-07 Shadow AI use in research groups|RSK-07 Shadow AI use in research groups]]. Remedy is an approved-tools path on [[Vendors/Qamar Cloud|Qamar Cloud]], not prohibition alone.
