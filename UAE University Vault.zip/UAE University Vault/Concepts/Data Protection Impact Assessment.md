---
synthetic: true
tags: [type/concept]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Data Protection Impact Assessment

Structured risk assessment before processing personal data with a new system; NFU's register is [[Datasets/DPIA Register|DPIA Register]] (9 entries). Required by [[Policies/POL-04 Student Data Protection Standard|POL-04 Student Data Protection Standard]]; legal anchor [[Regulatory Context/UAE PDPL (Federal Decree-Law 45 of 2021)|UAE PDPL (Federal Decree-Law 45 of 2021)]]. One rejection: [[Decisions/DEC-09 Reject proctoring analytics DPIA|DEC-09 Reject proctoring analytics DPIA]].
