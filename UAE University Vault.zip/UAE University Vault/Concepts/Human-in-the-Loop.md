---
synthetic: true
tags: [type/concept]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Human-in-the-Loop

A person approves before an AI output becomes an action. Applied to registrar record lookups ([[Decisions/DEC-10 Resume Tarhal with human-in-the-loop for record lookups|DEC-10 Resume Tarhal with human-in-the-loop for record lookups]]) and to at-risk interventions routed through [[People/Dr. Elena Vasquez-Moreau|Dr. Elena Vasquez-Moreau]] ([[Pilots/PIL-05 Predictive At-Risk Model|PIL-05 Predictive At-Risk Model]]). Grading assistant is feedback-only for the same reason ([[Pilots/PIL-04 Grading Assistant in BUS 205|PIL-04 Grading Assistant in BUS 205]]).
