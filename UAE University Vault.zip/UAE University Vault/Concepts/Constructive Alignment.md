---
synthetic: true
tags: [type/concept]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Constructive Alignment

Outcomes → activities → assessment designed together. Used with [[Regulatory Context/QFEmirates|QFEmirates]] level descriptors when re-writing course outcomes in [[Workstreams/WS2 Assessment & Academic Integrity|WS2 Assessment & Academic Integrity]]; sibling [[Concepts/Authentic Assessment|Authentic Assessment]].
