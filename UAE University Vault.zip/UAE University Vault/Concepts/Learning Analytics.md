---
synthetic: true
tags: [type/concept]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Learning Analytics

Using learner data to improve outcomes. Pilots: [[Pilots/PIL-05 Predictive At-Risk Model|PIL-05 Predictive At-Risk Model]], [[Datasets/MATH 101 Tutor Pilot Outcomes|MATH 101 Tutor Pilot Outcomes]]. Method caveat: section-level assignment in MATH 101 vs student-level randomisation in [[Datasets/CHEM 110 Tutor Pilot Wave 2|CHEM 110 Tutor Pilot Wave 2]]. Lead [[People/Ms. Hind Al Mehairbi-Yahyaee|Ms. Hind Al Mehairbi-Yahyaee]], engineer [[People/Mr. Daniel Okafor-Whitcombe|Mr. Daniel Okafor-Whitcombe]].
