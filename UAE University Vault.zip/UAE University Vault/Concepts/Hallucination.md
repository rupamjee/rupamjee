---
synthetic: true
tags: [type/concept]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Hallucination

Fluent but false output. 17 of 9,840 tutor interactions (0.17%) in [[Datasets/MATH 101 Tutor Pilot Outcomes|MATH 101 Tutor Pilot Outcomes]]; case [[Incidents/INC-02 Tutor hallucinated a theorem statement|INC-02 Tutor hallucinated a theorem statement]]. Mitigation: [[Concepts/Retrieval-Augmented Generation|Retrieval-Augmented Generation]] over approved sources; student trust only 54% ([[Datasets/Student AI Tutor Survey|Student AI Tutor Survey]]) — arguably healthy.
