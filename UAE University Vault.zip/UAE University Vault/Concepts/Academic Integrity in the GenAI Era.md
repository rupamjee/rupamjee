---
synthetic: true
tags: [type/concept]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Academic Integrity in the GenAI Era

Re-framing misconduct from 'used AI' to 'misrepresented authorship against the declared tier'. Basis of [[Policies/POL-01 AI in Assessment Policy|POL-01 AI in Assessment Policy]] and [[Policies/POL-06 Academic Integrity Policy (rev. 2026)|POL-06 Academic Integrity Policy (rev. 2026)]]; evidence [[Datasets/Academic Integrity Cases by Term|Academic Integrity Cases by Term]]; student position at [[Meetings/2025-10-22 WS2 Integrity Data Review|2025-10-22 WS2 Integrity Data Review]] ([[People/Mr. Saif Al Shamsi-Kaabi|Mr. Saif Al Shamsi-Kaabi]]).
