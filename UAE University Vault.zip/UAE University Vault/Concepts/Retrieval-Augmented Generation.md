---
synthetic: true
tags: [type/concept]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Retrieval-Augmented Generation

Model answers grounded in retrieved approved documents. Used by [[Vendors/Falaj Learning Systems|Falaj Learning Systems]] tutor ([[Pilots/PIL-01 AI Tutor in MATH 101|PIL-01 AI Tutor in MATH 101]]) and the registrar bot ([[Pilots/PIL-03 Registrar Service Chatbot|PIL-03 Registrar Service Chatbot]]). Reduces but does not eliminate [[Concepts/Hallucination|Hallucination]]; the retrieval layer is also where the injection guard sits ([[Concepts/Prompt Injection|Prompt Injection]]).
