---
synthetic: true
tags: [type/concept]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# AI Literacy

Understanding what models can and cannot do, and when to verify. Module 1 of WS1; measured by the readiness scale in [[Datasets/WS1 Cohort Completion & Readiness|WS1 Cohort Completion & Readiness]] and [[Datasets/Faculty AI Readiness Survey 2025|Faculty AI Readiness Survey 2025]]. Programme-level KPI [[KPIs/KPI-01 Faculty AI-literate share|KPI-01 Faculty AI-literate share]]. Anchor: [[Regulatory Context/UAE National AI Strategy 2031|UAE National AI Strategy 2031]] talent objectives.
