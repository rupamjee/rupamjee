---
synthetic: true
tags: [type/concept]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Algorithmic Fairness

Equal treatment across groups by a chosen metric — NFU uses flag-rate parity (≤2 pp). Case: [[Incidents/INC-03 At-risk model flag-rate disparity|INC-03 At-risk model flag-rate disparity]], [[Datasets/At-Risk Model Performance & Fairness|At-Risk Model Performance & Fairness]]; rule [[Decisions/DEC-06 Require model cards and parity thresholds|DEC-06 Require model cards and parity thresholds]]; KPI [[KPIs/KPI-05 At-risk flag-rate parity|KPI-05 At-risk flag-rate parity]]. Taught in [[Courses/AI 501 Machine Learning|AI 501 Machine Learning]].
