---
synthetic: true
tags: [type/concept]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Data Minimisation

Collect and expose only what the purpose needs. Principle in [[Policies/POL-02 Acceptable Use of Generative AI|POL-02 Acceptable Use of Generative AI]] and [[Policies/POL-03 Research Data Governance Framework|POL-03 Research Data Governance Framework]]; anchor [[Regulatory Context/UAE PDPL (Federal Decree-Law 45 of 2021)|UAE PDPL (Federal Decree-Law 45 of 2021)]]. Violated in spirit by [[Incidents/INC-05 Research data uploaded to personal AI account|INC-05 Research data uploaded to personal AI account]].
