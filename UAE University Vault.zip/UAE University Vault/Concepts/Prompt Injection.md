---
synthetic: true
tags: [type/concept]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Prompt Injection

Instructions hidden in user input or documents that redirect a system. Realised in [[Incidents/INC-04 Prompt injection attempt on registrar chatbot|INC-04 Prompt injection attempt on registrar chatbot]]; controlled by retrieval guards and [[Concepts/Human-in-the-Loop|Human-in-the-Loop]]; taught in WS1 module 3. Risk [[Risks/RSK-05 Prompt injection via public channels|RSK-05 Prompt injection via public channels]].
