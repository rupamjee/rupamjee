---
synthetic: true
tags: [type/concept]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Prompt Engineering

Module 2 of the WS1 curriculum ([[Decisions/DEC-02 Adopt five-module faculty AI curriculum|DEC-02 Adopt five-module faculty AI curriculum]]): clear task, context/role, examples, tag the source, output format, chain steps. Readiness gain 2.92 → 4.11 ([[Datasets/WS1 Cohort Completion & Readiness|WS1 Cohort Completion & Readiness]]). Sibling: [[Concepts/AI Literacy|AI Literacy]].
