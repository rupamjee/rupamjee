---
synthetic: true
tags: [type/concept]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Authentic Assessment

Tasks that mirror real practice (portfolios, oral defences, process evidence), harder to outsource to a model. Backbone of [[Policies/POL-01 AI in Assessment Policy|POL-01 AI in Assessment Policy]] and the redesigns in [[Datasets/Course Redesign Tracker|Course Redesign Tracker]] (e.g. [[Courses/CSC 201 Data Structures|CSC 201 Data Structures]] oral defence, [[Courses/MCM 150 Media Writing|MCM 150 Media Writing]] process portfolio). Preferred over surveillance: [[Decisions/DEC-09 Reject proctoring analytics DPIA|DEC-09 Reject proctoring analytics DPIA]].
