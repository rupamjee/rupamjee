---
synthetic: true
tags: [type/meeting, ws/research-data]
date: 2026-04-08
workstream: '[[Workstreams/WS4 Research Data Governance]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# 2026-04-08 WS4 Research Data Governance Workshop

**Workstream:** [[Workstreams/WS4 Research Data Governance|WS4 Research Data Governance]] · **Attendees:** [[People/Dr. Ibrahim Al Nuaimi-Dhanhani|Dr. Ibrahim Al Nuaimi-Dhanhani]] · [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]] · [[People/Ms. Moza Al Qubaisi-Hameli|Ms. Moza Al Qubaisi-Hameli]] · [[People/Mr. Majid Al Ghafli-Sharqi|Mr. Majid Al Ghafli-Sharqi]] · [[People/Dr. Latifa Al Shehhi-Ameri|Dr. Latifa Al Shehhi-Ameri]] · [[People/Dr. Saeed Al Hosani-Mehairi|Dr. Saeed Al Hosani-Mehairi]]

Classified 5 research data tiers; [[Concepts/Shadow AI|Shadow AI]] survey of 41 research groups found 23 using personal accounts for unpublished data → [[Risks/RSK-07 Shadow AI use in research groups|RSK-07 Shadow AI use in research groups]]. Output: [[Policies/POL-03 Research Data Governance Framework|POL-03 Research Data Governance Framework]].
