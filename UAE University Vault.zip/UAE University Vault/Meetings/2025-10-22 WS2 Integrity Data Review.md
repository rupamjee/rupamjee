---
synthetic: true
tags: [type/meeting, ws/assessment]
date: 2025-10-22
workstream: '[[Workstreams/WS2 Assessment & Academic Integrity]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# 2025-10-22 WS2 Integrity Data Review

**Workstream:** [[Workstreams/WS2 Assessment & Academic Integrity|WS2 Assessment & Academic Integrity]] · **Attendees:** [[People/Ms. Salama Al Kaabi-Shamsi|Ms. Salama Al Kaabi-Shamsi]] · [[People/Dr. Hamad Al Shorafa-Neyadi|Dr. Hamad Al Shorafa-Neyadi]] · [[People/Mr. Saif Al Shamsi-Kaabi|Mr. Saif Al Shamsi-Kaabi]] · [[People/Dr. Noor Al Ameri-Hamli|Dr. Noor Al Ameri-Hamli]]

Reviewed [[Datasets/Academic Integrity Cases by Term|Academic Integrity Cases by Term]]: cases rose 62 → 118 between Fall 2024 and Spring 2025, AI-related share 21% → 48%. Student Council ([[People/Mr. Saif Al Shamsi-Kaabi|Mr. Saif Al Shamsi-Kaabi]]) asked for clear tiers instead of blanket bans. Fed into [[Policies/POL-01 AI in Assessment Policy|POL-01 AI in Assessment Policy]].
