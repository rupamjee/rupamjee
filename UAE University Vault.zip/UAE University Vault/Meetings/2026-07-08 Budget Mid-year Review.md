---
synthetic: true
tags: [type/meeting, ws/governance]
date: 2026-07-08
workstream: '[[Workstreams/WS6 AI Governance & Policy]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# 2026-07-08 Budget Mid-year Review

**Workstream:** [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] · **Attendees:** [[People/Prof. Abdulla Al Rumaithi-Ghurair|Prof. Abdulla Al Rumaithi-Ghurair]] · [[People/Dr. Sultan Al Mansouri-Kalbani|Dr. Sultan Al Mansouri-Kalbani]] · [[People/Dr. Laila Al Zaabi-Marzooqi|Dr. Laila Al Zaabi-Marzooqi]] · [[People/Ms. Priyanka Raman-Iyer|Ms. Priyanka Raman-Iyer]]

[[Datasets/Programme Budget FY2025-26|Programme Budget FY2025-26]]: infrastructure line at 71% spent by month 10 vs 58% plan → [[Risks/RSK-08 Budget overrun on infrastructure|RSK-08 Budget overrun on infrastructure]]. Decision: [[Decisions/DEC-11 Cap infrastructure spend and reprioritise WS4|DEC-11 Cap infrastructure spend and reprioritise WS4]].
