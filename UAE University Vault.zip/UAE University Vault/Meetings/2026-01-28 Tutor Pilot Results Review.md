---
synthetic: true
tags: [type/meeting, ws/tutor]
date: 2026-01-28
workstream: '[[Workstreams/WS3 Student AI Tutor Pilot]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# 2026-01-28 Tutor Pilot Results Review

**Workstream:** [[Workstreams/WS3 Student AI Tutor Pilot|WS3 Student AI Tutor Pilot]] · **Attendees:** [[People/Dr. Sara Al Marzooqi-Kindi|Dr. Sara Al Marzooqi-Kindi]] · [[People/Mr. Daniel Okafor-Whitcombe|Mr. Daniel Okafor-Whitcombe]] · [[People/Dr. Ahmed Al Hammadi-Balushi|Dr. Ahmed Al Hammadi-Balushi]] · [[People/Prof. Maitha Al Hosani-Falahi|Prof. Maitha Al Hosani-Falahi]] · [[People/Ms. Hind Al Mehairbi-Yahyaee|Ms. Hind Al Mehairbi-Yahyaee]]

[[Datasets/MATH 101 Tutor Pilot Outcomes|MATH 101 Tutor Pilot Outcomes]]: pass 71.5% vs 63.9% control (n=214/208). Decision: [[Decisions/DEC-05 Extend AI tutor to CHEM 110|DEC-05 Extend AI tutor to CHEM 110]]. Caveat recorded: sections not randomised at student level ([[Concepts/Learning Analytics|Learning Analytics]]).
