---
synthetic: true
tags: [type/meeting, ws/governance]
date: 2026-08-26
workstream: '[[Workstreams/WS6 AI Governance & Policy]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# 2026-08-26 AI Steering Committee — Year-1 Review

**Workstream:** [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] · **Attendees:** [[People/Prof. Abdulla Al Rumaithi-Ghurair|Prof. Abdulla Al Rumaithi-Ghurair]] · [[People/Prof. Maitha Al Hosani-Falahi|Prof. Maitha Al Hosani-Falahi]] · [[People/Dr. Sultan Al Mansouri-Kalbani|Dr. Sultan Al Mansouri-Kalbani]] · [[People/Dr. Laila Al Zaabi-Marzooqi|Dr. Laila Al Zaabi-Marzooqi]] · [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]] · [[People/Dr. Noor Al Ameri-Hamli|Dr. Noor Al Ameri-Hamli]] · [[People/Dr. Hamad Al Shorafa-Neyadi|Dr. Hamad Al Shorafa-Neyadi]] · [[People/Ms. Salama Al Kaabi-Shamsi|Ms. Salama Al Kaabi-Shamsi]] · [[People/Dr. Ibrahim Al Nuaimi-Dhanhani|Dr. Ibrahim Al Nuaimi-Dhanhani]] · [[People/Ms. Aisha Al Otaiba-Mazrui|Ms. Aisha Al Otaiba-Mazrui]]

Year-1 scorecard ([[Datasets/Programme KPI Scorecard|Programme KPI Scorecard]]): faculty AI-literate 32.8% vs 40% target; DFW in MATH 101 36.1% → 28.5%; integrity cases 141 → 87. Decisions: [[Decisions/DEC-13 Approve Year-2 plan and Cohort 6|DEC-13 Approve Year-2 plan and Cohort 6]], [[Decisions/DEC-14 Add AI competency to promotion criteria|DEC-14 Add AI competency to promotion criteria]], [[Decisions/DEC-15 Publish annual AI transparency report|DEC-15 Publish annual AI transparency report]].
