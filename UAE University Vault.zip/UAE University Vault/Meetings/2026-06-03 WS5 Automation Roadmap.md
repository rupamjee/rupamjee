---
synthetic: true
tags: [type/meeting, ws/automation]
date: 2026-06-03
workstream: '[[Workstreams/WS5 Administrative Automation]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# 2026-06-03 WS5 Automation Roadmap

**Workstream:** [[Workstreams/WS5 Administrative Automation|WS5 Administrative Automation]] · **Attendees:** [[People/Ms. Aisha Al Otaiba-Mazrui|Ms. Aisha Al Otaiba-Mazrui]] · [[People/Dr. Sultan Al Mansouri-Kalbani|Dr. Sultan Al Mansouri-Kalbani]] · [[People/Ms. Priyanka Raman-Iyer|Ms. Priyanka Raman-Iyer]] · [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]]

[[Datasets/Registrar Chatbot Analytics Spring 2026|Registrar Chatbot Analytics Spring 2026]]: 38,400 queries, 62% deflected, CSAT 4.1/5. Admissions document triage DPIA still pending. Decision: [[Decisions/DEC-10 Resume Tarhal with human-in-the-loop for record lookups|DEC-10 Resume Tarhal with human-in-the-loop for record lookups]] ([[Concepts/Human-in-the-Loop|Human-in-the-Loop]]).
