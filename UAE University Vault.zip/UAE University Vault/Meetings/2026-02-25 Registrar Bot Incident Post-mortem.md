---
synthetic: true
tags: [type/meeting, ws/automation]
date: 2026-02-25
workstream: '[[Workstreams/WS5 Administrative Automation]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# 2026-02-25 Registrar Bot Incident Post-mortem

**Workstream:** [[Workstreams/WS5 Administrative Automation|WS5 Administrative Automation]] · **Attendees:** [[People/Ms. Aisha Al Otaiba-Mazrui|Ms. Aisha Al Otaiba-Mazrui]] · [[People/Mr. Majid Al Ghafli-Sharqi|Mr. Majid Al Ghafli-Sharqi]] · [[People/Dr. Sultan Al Mansouri-Kalbani|Dr. Sultan Al Mansouri-Kalbani]] · [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]]

[[Incidents/INC-04 Prompt injection attempt on registrar chatbot|INC-04 Prompt injection attempt on registrar chatbot]]: a crafted query attempted to extract another student's record; refused by the retrieval guard. Decision: [[Decisions/DEC-07 Pause Tarhal contract pending remediation|DEC-07 Pause Tarhal contract pending remediation]] ([[Concepts/Prompt Injection|Prompt Injection]]).
