---
synthetic: true
tags: [type/meeting, ws/tutor]
date: 2025-11-12
workstream: '[[Workstreams/WS3 Student AI Tutor Pilot]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# 2025-11-12 Tutor Pilot Mid-term Check

**Workstream:** [[Workstreams/WS3 Student AI Tutor Pilot|WS3 Student AI Tutor Pilot]] · **Attendees:** [[People/Dr. Sara Al Marzooqi-Kindi|Dr. Sara Al Marzooqi-Kindi]] · [[People/Mr. Daniel Okafor-Whitcombe|Mr. Daniel Okafor-Whitcombe]] · [[People/Dr. Ahmed Al Hammadi-Balushi|Dr. Ahmed Al Hammadi-Balushi]] · [[People/Ms. Farah Nasser-Lindqvist|Ms. Farah Nasser-Lindqvist]]

[[Pilots/PIL-01 AI Tutor in MATH 101|PIL-01 AI Tutor in MATH 101]]: 2.3 sessions/student/week; 17 flagged [[Concepts/Hallucination|Hallucination]] responses in 9,840 interactions (0.17%). Logged as [[Incidents/INC-02 Tutor hallucinated a theorem statement|INC-02 Tutor hallucinated a theorem statement]].
