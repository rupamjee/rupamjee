---
synthetic: true
tags: [type/meeting, ws/research-data]
date: 2025-10-01
workstream: '[[Workstreams/WS4 Research Data Governance]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# 2025-10-01 DPIA Review — AI Tutor

**Workstream:** [[Workstreams/WS4 Research Data Governance|WS4 Research Data Governance]] · **Attendees:** [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]] · [[People/Mr. Majid Al Ghafli-Sharqi|Mr. Majid Al Ghafli-Sharqi]] · [[People/Dr. Sara Al Marzooqi-Kindi|Dr. Sara Al Marzooqi-Kindi]] · [[People/Ms. Farah Nasser-Lindqvist|Ms. Farah Nasser-Lindqvist]]

Reviewed [[Vendors/Falaj Learning Systems|Falaj Learning Systems]] DPIA: UAE data residency, no training on student data, 90-day log retention. Approved 2025-10-02 ([[Datasets/DPIA Register|DPIA Register]]). Anchors: [[Regulatory Context/UAE PDPL (Federal Decree-Law 45 of 2021)|UAE PDPL (Federal Decree-Law 45 of 2021)]], [[Concepts/Data Minimisation|Data Minimisation]].
