---
synthetic: true
tags: [type/meeting, ws/tutor]
date: 2026-03-25
workstream: '[[Workstreams/WS3 Student AI Tutor Pilot]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# 2026-03-25 Student Council AI Forum

**Workstream:** [[Workstreams/WS3 Student AI Tutor Pilot|WS3 Student AI Tutor Pilot]] · **Attendees:** [[People/Mr. Saif Al Shamsi-Kaabi|Mr. Saif Al Shamsi-Kaabi]] · [[People/Dr. Hamad Al Shorafa-Neyadi|Dr. Hamad Al Shorafa-Neyadi]] · [[People/Dr. Sara Al Marzooqi-Kindi|Dr. Sara Al Marzooqi-Kindi]] · [[People/Dr. Elena Vasquez-Moreau|Dr. Elena Vasquez-Moreau]]

[[Datasets/Student AI Tutor Survey|Student AI Tutor Survey]]: 78% found the tutor helpful, 54% trust its answers, 63% still prefer a human for exam prep. Council request: disclosure of when a bot, not staff, answers ([[Regulatory Context/UAE AI Charter 2024|UAE AI Charter 2024]] transparency principle).
