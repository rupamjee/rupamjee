---
synthetic: true
tags: [type/meeting, ws/governance]
date: 2026-01-14
workstream: '[[Workstreams/WS6 AI Governance & Policy]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# 2026-01-14 AI Steering Committee — Q2

**Workstream:** [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] · **Attendees:** [[People/Prof. Abdulla Al Rumaithi-Ghurair|Prof. Abdulla Al Rumaithi-Ghurair]] · [[People/Prof. Maitha Al Hosani-Falahi|Prof. Maitha Al Hosani-Falahi]] · [[People/Dr. Sultan Al Mansouri-Kalbani|Dr. Sultan Al Mansouri-Kalbani]] · [[People/Dr. Laila Al Zaabi-Marzooqi|Dr. Laila Al Zaabi-Marzooqi]] · [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]] · [[People/Ms. Salama Al Kaabi-Shamsi|Ms. Salama Al Kaabi-Shamsi]] · [[People/Dr. Hamad Al Shorafa-Neyadi|Dr. Hamad Al Shorafa-Neyadi]]

Reviewed [[Datasets/WS1 Cohort Completion & Readiness|WS1 Cohort Completion & Readiness]] (Cohorts 1–2: 85 of 100 completed) and Fall 2025 integrity peak of 141 cases. Approved [[Decisions/DEC-03 Approve AI in Assessment Policy|DEC-03 Approve AI in Assessment Policy]] and [[Decisions/DEC-04 Approve Acceptable Use of Generative AI|DEC-04 Approve Acceptable Use of Generative AI]].
