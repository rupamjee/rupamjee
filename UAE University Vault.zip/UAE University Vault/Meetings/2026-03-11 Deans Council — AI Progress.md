---
synthetic: true
tags: [type/meeting, ws/upskilling]
date: 2026-03-11
workstream: '[[Workstreams/WS1 Faculty AI Upskilling]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# 2026-03-11 Deans Council — AI Progress

**Workstream:** [[Workstreams/WS1 Faculty AI Upskilling|WS1 Faculty AI Upskilling]] · **Attendees:** [[People/Prof. Maitha Al Hosani-Falahi|Prof. Maitha Al Hosani-Falahi]] · [[People/Dr. Laila Al Zaabi-Marzooqi|Dr. Laila Al Zaabi-Marzooqi]] · [[People/Dr. Khalid Al Mazrouei-Hashimi|Dr. Khalid Al Mazrouei-Hashimi]] · [[People/Dr. Fatima Al Ketbi-Rashdan|Dr. Fatima Al Ketbi-Rashdan]] · [[People/Dr. Hessa Al Nuaimi-Zaabi|Dr. Hessa Al Nuaimi-Zaabi]] · [[People/Prof. Marwan Al Shamsi-Darmaki|Prof. Marwan Al Shamsi-Darmaki]] · [[People/Dr. Noura Al Dhaheri-Kaabi|Dr. Noura Al Dhaheri-Kaabi]] · [[People/Dr. Salem Al Marri-Qubaisi|Dr. Salem Al Marri-Qubaisi]]

Per-college training coverage from [[Datasets/WS1 Cohort Completion & Readiness|WS1 Cohort Completion & Readiness]]; CHS and CED lag (Cohort 3 just closed). Deans commit to nominate adjuncts for Cohort 5. [[People/Dr. Hessa Al Nuaimi-Zaabi|Dr. Hessa Al Nuaimi-Zaabi]] proposed [[Policies/POL-07 AI Competency in Faculty Promotion Criteria|POL-07 AI Competency in Faculty Promotion Criteria]].
