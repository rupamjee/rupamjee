---
synthetic: true
tags: [type/meeting, ws/governance]
date: 2025-12-10
workstream: '[[Workstreams/WS6 AI Governance & Policy]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# 2025-12-10 WS6 Policy Drafting Workshop

**Workstream:** [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] · **Attendees:** [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]] · [[People/Ms. Salama Al Kaabi-Shamsi|Ms. Salama Al Kaabi-Shamsi]] · [[People/Dr. Jonathan Mbeki-Hartley|Dr. Jonathan Mbeki-Hartley]] · [[People/Prof. Maitha Al Hosani-Falahi|Prof. Maitha Al Hosani-Falahi]] · [[People/Ms. Moza Al Qubaisi-Hameli|Ms. Moza Al Qubaisi-Hameli]]

Drafted [[Policies/POL-01 AI in Assessment Policy|POL-01 AI in Assessment Policy]] and [[Policies/POL-02 Acceptable Use of Generative AI|POL-02 Acceptable Use of Generative AI]]; mapped principles to [[Regulatory Context/UAE AI Charter 2024|UAE AI Charter 2024]]. External advisor [[People/Dr. Jonathan Mbeki-Hartley|Dr. Jonathan Mbeki-Hartley]] recommended a three-tier AI-use scheme per assessment.
