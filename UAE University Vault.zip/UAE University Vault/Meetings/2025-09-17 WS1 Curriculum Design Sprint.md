---
synthetic: true
tags: [type/meeting, ws/upskilling]
date: 2025-09-17
workstream: '[[Workstreams/WS1 Faculty AI Upskilling]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# 2025-09-17 WS1 Curriculum Design Sprint

**Workstream:** [[Workstreams/WS1 Faculty AI Upskilling|WS1 Faculty AI Upskilling]] · **Attendees:** [[People/Dr. Hamad Al Shorafa-Neyadi|Dr. Hamad Al Shorafa-Neyadi]] · [[People/Dr. Sara Al Marzooqi-Kindi|Dr. Sara Al Marzooqi-Kindi]] · [[People/Dr. Laila Al Zaabi-Marzooqi|Dr. Laila Al Zaabi-Marzooqi]] · [[People/Dr. Ahmed Al Hammadi-Balushi|Dr. Ahmed Al Hammadi-Balushi]] · [[People/Dr. Reem Al Falasi-Mansoori|Dr. Reem Al Falasi-Mansoori]] · [[People/Dr. Omar Al Blooshi-Tayer|Dr. Omar Al Blooshi-Tayer]] · [[People/Dr. Latifa Al Shehhi-Ameri|Dr. Latifa Al Shehhi-Ameri]]

Agreed the 5-module faculty curriculum ([[Concepts/AI Literacy|AI Literacy]], [[Concepts/Prompt Engineering|Prompt Engineering]], [[Concepts/Academic Integrity in the GenAI Era|Academic Integrity in the GenAI Era]], [[Concepts/Authentic Assessment|Authentic Assessment]], tool practice). Badge threshold 28/40. Decision: [[Decisions/DEC-02 Adopt five-module faculty AI curriculum|DEC-02 Adopt five-module faculty AI curriculum]].
