---
synthetic: true
tags: [type/meeting, ws/governance]
date: 2026-04-29
workstream: '[[Workstreams/WS6 AI Governance & Policy]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# 2026-04-29 Accreditation Evidence Mapping

**Workstream:** [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] · **Attendees:** [[People/Dr. Noor Al Ameri-Hamli|Dr. Noor Al Ameri-Hamli]] · [[People/Dr. Laila Al Zaabi-Marzooqi|Dr. Laila Al Zaabi-Marzooqi]] · [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]] · [[People/Ms. Salama Al Kaabi-Shamsi|Ms. Salama Al Kaabi-Shamsi]]

Mapped programme evidence to [[Regulatory Context/CAA Standards 2019|CAA Standards 2019]] for [[Accreditation/CAA Licensure Renewal 2027|CAA Licensure Renewal 2027]]; see [[Accreditation/Self-Study Evidence Map (AI)|Self-Study Evidence Map (AI)]]. Gap: no documented faculty AI-competency baseline before 2025 → [[Risks/RSK-06 Accreditation evidence gaps|RSK-06 Accreditation evidence gaps]].
