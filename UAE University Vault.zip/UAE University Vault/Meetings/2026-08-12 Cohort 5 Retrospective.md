---
synthetic: true
tags: [type/meeting, ws/upskilling]
date: 2026-08-12
workstream: '[[Workstreams/WS1 Faculty AI Upskilling]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# 2026-08-12 Cohort 5 Retrospective

**Workstream:** [[Workstreams/WS1 Faculty AI Upskilling|WS1 Faculty AI Upskilling]] · **Attendees:** [[People/Dr. Hamad Al Shorafa-Neyadi|Dr. Hamad Al Shorafa-Neyadi]] · [[People/Dr. Sara Al Marzooqi-Kindi|Dr. Sara Al Marzooqi-Kindi]] · [[People/Mr. Rashed Al Dhanhani-Tunaiji|Mr. Rashed Al Dhanhani-Tunaiji]] · [[People/Dr. Shamma Al Muhairi-Yammahi|Dr. Shamma Al Muhairi-Yammahi]] · [[People/Dr. Rashid Al Shamisi-Ghafli|Dr. Rashid Al Shamisi-Ghafli]]

Adjunct cohort completion 47/60 — lowest of the five. Root cause: unpaid time. Decision: [[Decisions/DEC-12 Pay adjuncts for cohort hours|DEC-12 Pay adjuncts for cohort hours]]; HR ([[People/Mr. Rashed Al Dhanhani-Tunaiji|Mr. Rashed Al Dhanhani-Tunaiji]]) to fund from Emiratisation development budget.
