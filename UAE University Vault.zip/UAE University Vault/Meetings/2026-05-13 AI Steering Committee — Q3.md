---
synthetic: true
tags: [type/meeting, ws/governance]
date: 2026-05-13
workstream: '[[Workstreams/WS6 AI Governance & Policy]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# 2026-05-13 AI Steering Committee — Q3

**Workstream:** [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] · **Attendees:** [[People/Prof. Abdulla Al Rumaithi-Ghurair|Prof. Abdulla Al Rumaithi-Ghurair]] · [[People/Prof. Maitha Al Hosani-Falahi|Prof. Maitha Al Hosani-Falahi]] · [[People/Dr. Sultan Al Mansouri-Kalbani|Dr. Sultan Al Mansouri-Kalbani]] · [[People/Dr. Laila Al Zaabi-Marzooqi|Dr. Laila Al Zaabi-Marzooqi]] · [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]] · [[People/Dr. Noor Al Ameri-Hamli|Dr. Noor Al Ameri-Hamli]] · [[People/Dr. Ibrahim Al Nuaimi-Dhanhani|Dr. Ibrahim Al Nuaimi-Dhanhani]]

Spring 2026 integrity cases fell to 87 (AI-related 44%) after [[Policies/POL-01 AI in Assessment Policy|POL-01 AI in Assessment Policy]]. Approved [[Decisions/DEC-08 Adopt Research Data Governance Framework|DEC-08 Adopt Research Data Governance Framework]] and [[Decisions/DEC-09 Reject proctoring analytics DPIA|DEC-09 Reject proctoring analytics DPIA]].
