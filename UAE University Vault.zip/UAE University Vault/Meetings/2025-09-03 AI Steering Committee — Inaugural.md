---
synthetic: true
tags: [type/meeting, ws/governance]
date: 2025-09-03
workstream: '[[Workstreams/WS6 AI Governance & Policy]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# 2025-09-03 AI Steering Committee — Inaugural

**Workstream:** [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] · **Attendees:** [[People/Prof. Abdulla Al Rumaithi-Ghurair|Prof. Abdulla Al Rumaithi-Ghurair]] · [[People/Prof. Maitha Al Hosani-Falahi|Prof. Maitha Al Hosani-Falahi]] · [[People/Dr. Sultan Al Mansouri-Kalbani|Dr. Sultan Al Mansouri-Kalbani]] · [[People/Dr. Laila Al Zaabi-Marzooqi|Dr. Laila Al Zaabi-Marzooqi]] · [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]] · [[People/Dr. Noor Al Ameri-Hamli|Dr. Noor Al Ameri-Hamli]]

Chartered the NFU AI Adoption Programme 2025–27: six workstreams ([[Workstreams/WS1 Faculty AI Upskilling|WS1 Faculty AI Upskilling]], [[Workstreams/WS2 Assessment & Academic Integrity|WS2 Assessment & Academic Integrity]], [[Workstreams/WS3 Student AI Tutor Pilot|WS3 Student AI Tutor Pilot]], [[Workstreams/WS4 Research Data Governance|WS4 Research Data Governance]], [[Workstreams/WS5 Administrative Automation|WS5 Administrative Automation]], [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]]). Budget envelope AED 4.85 M ([[Datasets/Programme Budget FY2025-26|Programme Budget FY2025-26]]). Decision: [[Decisions/DEC-01 Charter the AI Adoption Programme|DEC-01 Charter the AI Adoption Programme]].
