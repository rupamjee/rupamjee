---
synthetic: true
tags: [type/meeting, ws/research-data]
date: 2026-02-11
workstream: '[[Workstreams/WS4 Research Data Governance]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# 2026-02-11 Fairness Review — At-Risk Model

**Workstream:** [[Workstreams/WS4 Research Data Governance|WS4 Research Data Governance]] · **Attendees:** [[People/Ms. Hind Al Mehairbi-Yahyaee|Ms. Hind Al Mehairbi-Yahyaee]] · [[People/Mr. Daniel Okafor-Whitcombe|Mr. Daniel Okafor-Whitcombe]] · [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]] · [[People/Mr. Karim Haddad-Osei|Mr. Karim Haddad-Osei]] · [[People/Dr. Elena Vasquez-Moreau|Dr. Elena Vasquez-Moreau]]

[[Datasets/At-Risk Model Performance & Fairness|At-Risk Model Performance & Fairness]]: flag rate 14.2% Emirati vs 10.1% non-Emirati. Raised as [[Incidents/INC-03 At-risk model flag-rate disparity|INC-03 At-risk model flag-rate disparity]]. Decision: [[Decisions/DEC-06 Require model cards and parity thresholds|DEC-06 Require model cards and parity thresholds]] ([[Concepts/Algorithmic Fairness|Algorithmic Fairness]], [[Concepts/Model Card|Model Card]]).
