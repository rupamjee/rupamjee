---
synthetic: true
tags: [type/regulatory, real-world]
synthetic_note: 'This note describes a real framework; only its links into NFU are fictional'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# MoHESR and CAA Oversight

> [!info] Real bodies — verify current structure

Federal oversight of UAE higher education sits with the Ministry of Higher Education and Scientific Research (MoHESR), with the Commission for Academic Accreditation (CAA) as the licensing and accreditation body; emirate-level regulators (e.g. ADEK in Abu Dhabi, KHDA in Dubai free zones) also apply to some institutions. The fictional [[University/Nujoom Federal University|NFU]] is treated as CAA-licensed; see [[Accreditation/CAA Licensure Renewal 2027|CAA Licensure Renewal 2027]] and [[Regulatory Context/CAA Standards 2019|CAA Standards 2019]].

Sources: [u.ae — Regulatory authorities of higher education](https://u.ae/en/information-and-services/education/higher-education/regulatory-authorities-of-higher-education) · [MoHESR — About the Ministry](https://www.mohesr.gov.ae/En/AboutTheMinistry/Pages/About-the-Ministers.aspx)
