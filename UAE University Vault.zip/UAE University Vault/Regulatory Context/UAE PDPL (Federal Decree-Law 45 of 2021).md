---
synthetic: true
tags: [type/regulatory, real-world]
synthetic_note: 'This note describes a real framework; only its links into NFU are fictional'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# UAE PDPL (Federal Decree-Law 45 of 2021)

> [!info] Real law — verify before quoting

Federal Decree-Law No. 45 of 2021 on the Protection of Personal Data is the UAE's federal data-protection law (free zones such as ADGM and DIFC have their own regimes). It underpins NFU's fictional [[Policies/POL-04 Student Data Protection Standard|POL-04 Student Data Protection Standard]], the [[Datasets/DPIA Register|DPIA Register]], and the [[Concepts/Data Minimisation|Data Minimisation]] rules in [[Policies/POL-02 Acceptable Use of Generative AI|POL-02 Acceptable Use of Generative AI]] and [[Policies/POL-03 Research Data Governance Framework|POL-03 Research Data Governance Framework]]. Whether a federal university is inside the law's scope (government entities have carve-outs) is a question for counsel — the vault assumes voluntary alignment.

Sources: [u.ae — Data protection laws](https://u.ae/en/about-the-uae/digital-uae/data/data-protection-laws) · [Securiti overview of Decree-Law 45/2021](https://securiti.ai/uae-personal-data-protection-law/) · [Global Privacy Blog, Dec 2021](https://www.globalprivacyblog.com/2021/12/uae-publishes-first-federal-data-protection-law/)
