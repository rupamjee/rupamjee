---
synthetic: true
tags: [type/regulatory, real-world]
synthetic_note: 'This note describes a real framework; only its links into NFU are fictional'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Emiratisation in Higher Education

> [!info] Real policy area — figures here are fictional

UAE Emiratisation policy sets targets for the share of Emirati nationals in the workforce; specific targets and mechanisms differ between the private sector and federal entities and change over time — verify current rules before citing. In this vault the fictional figures are: faculty 27% Emirati vs 30% target ([[Datasets/University Headcount & Emiratisation|University Headcount & Emiratisation]], [[KPIs/KPI-09 Emirati faculty share|KPI-09 Emirati faculty share]]); HR lead [[People/Mr. Rashed Al Dhanhani-Tunaiji|Mr. Rashed Al Dhanhani-Tunaiji]] funds adjunct cohort hours from the development budget ([[Decisions/DEC-12 Pay adjuncts for cohort hours|DEC-12 Pay adjuncts for cohort hours]]).
