---
synthetic: true
tags: [type/regulatory, real-world]
synthetic_note: 'This note describes a real framework; only its links into NFU are fictional'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# UAE AI Charter 2024

> [!info] Real policy — verify before quoting

The UAE Charter for the Development and Use of Artificial Intelligence (2024) sets out twelve principles including safety, fairness, transparency and privacy. NFU's fictional [[Policies/POL-02 Acceptable Use of Generative AI|POL-02 Acceptable Use of Generative AI]] maps to it ([[Meetings/2025-12-10 WS6 Policy Drafting Workshop|2025-12-10 WS6 Policy Drafting Workshop]]); the Student Council's transparency request ([[Meetings/2026-03-25 Student Council AI Forum|2026-03-25 Student Council AI Forum]]) and [[Decisions/DEC-15 Publish annual AI transparency report|DEC-15 Publish annual AI transparency report]] cite it.

Sources: [u.ae — The UAE Charter for the Development and Use of AI](https://u.ae/en/about-the-uae/strategies-initiatives-and-awards/policies/Ai/The-UAE-Charter-for-the-Development-and-Use-of-Artificial-Intelligence) · [uaelegislation.gov.ae policy page](https://uaelegislation.gov.ae/en/policy/details/the-uae-charter-for-the-development-and-use-of-artificial-intelligence) · [Gulf News launch report](https://gulfnews.com/uae/uae-launches-charter-for-safe-fair-and-inclusive-ai-development-1.103659722)
