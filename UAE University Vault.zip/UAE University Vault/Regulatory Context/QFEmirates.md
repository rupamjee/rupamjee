---
synthetic: true
tags: [type/regulatory, real-world]
synthetic_note: 'This note describes a real framework; only its links into NFU are fictional'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# QFEmirates

> [!info] Real framework — verify before quoting

The UAE National Qualifications Framework (QFEmirates) is a 10-level framework of learning-outcome descriptors; an updated framework was approved by Cabinet Resolution No. (106) of 2024. In this vault every [[Programmes/BSc Mechanical Engineering|programme note]] carries a QFEmirates level (7 = bachelor, 9 = master, as used in the fictional data) and [[Concepts/Constructive Alignment|Constructive Alignment]] work in [[Workstreams/WS2 Assessment & Academic Integrity|WS2 Assessment & Academic Integrity]] refers to its descriptors.

Sources: [Cabinet Resolution 106/2024 level descriptors (Ajman University copy)](https://www.ajman.ac.ae/upload/docs/QFEmirates_2024_Level_Descriptors.pdf?v=1754394123) · [uaelegislation.gov.ae — Cabinet Resolution approving the NQF](https://uaelegislation.gov.ae/en/legislations/2615/regulations/972/download) · [NQC — designing the QFEmirates](https://www.nqc.gov.ae/en/our-responsibility/qualifications-framework-department/designing-of-the-qfemirates.aspx) · [ADEK overview](https://www.adek.gov.ae/en/Education-System/Higher-Education/National-Qualification-Framework-in-the-Emirates)
