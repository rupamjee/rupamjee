---
synthetic: true
tags: [type/regulatory, real-world]
synthetic_note: 'This note describes a real framework; only its links into NFU are fictional'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# CAA Standards 2019

> [!info] Real framework — verify before quoting

The UAE Commission for Academic Accreditation's *Standards for Institutional Licensure and Program Accreditation* (2019 edition, in force from September 2019) govern licensure of higher-education institutions and accreditation of their programmes. NFU's fictional [[Accreditation/CAA Licensure Renewal 2027|CAA Licensure Renewal 2027]] maps AI-programme evidence to these standards in [[Accreditation/Standard Mapping — AI Policy Suite|Standard Mapping — AI Policy Suite]]. Standard numbering used in this vault should be checked against the published PDF before any external use.

Sources: [CAA Standards 2019 (PDF, hosted by University of Sharjah)](https://old.sharjah.ac.ae/en/Compliance/Documents/CAA_Standards_2019.pdf) · [Al Bawaba: new standards from September 2019](https://www.albawaba.com/business/pr/ministry-education-new-licensure-and-accreditation-standards-uae-higher-education-instit) · [TAMM: CAA overview](https://www.tamm.abudhabi/en/articles/commission-for-academic-accreditation)
