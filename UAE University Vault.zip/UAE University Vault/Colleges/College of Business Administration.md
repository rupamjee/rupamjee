---
synthetic: true
tags: [type/college]
dean: '[[People/Dr. Hessa Al Nuaimi-Zaabi]]'
faculty: 104
students: 2010
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# College of Business Administration

Part of [[University/Nujoom Federal University|NFU]]. Dean: [[People/Dr. Hessa Al Nuaimi-Zaabi|Dr. Hessa Al Nuaimi-Zaabi]]. 104 faculty, 2,010 students.

## Programmes
- [[Programmes/BBA Business Analytics|BBA Business Analytics]] — QFEmirates level 7 (Bachelor), 710 students; AI champion [[People/Dr. Saeed Al Hosani-Mehairi|Dr. Saeed Al Hosani-Mehairi]]
- [[Programmes/MBA Digital Transformation|MBA Digital Transformation]] — QFEmirates level 9 (Master), 188 students; AI champion [[People/Dr. Alia Al Qasimi-Suwaidi|Dr. Alia Al Qasimi-Suwaidi]]

## AI adoption touchpoints
- Faculty cohorts involving this college: [[Cohorts/Cohort 2 — Business & Humanities|Cohort 2 — Business & Humanities]], [[Cohorts/Cohort 4 — Deans & Chairs|Cohort 4 — Deans & Chairs]], [[Cohorts/Cohort 5 — Adjunct Faculty|Cohort 5 — Adjunct Faculty]]
- Courses redesigned: [[Courses/BUS 205 Business Communication|BUS 205 Business Communication]], [[Courses/MGT 610 Digital Strategy|MGT 610 Digital Strategy]]
- Deans Council review: [[Meetings/2026-03-11 Deans Council — AI Progress|2026-03-11 Deans Council — AI Progress]]
