---
synthetic: true
tags: [type/college]
dean: '[[People/Prof. Marwan Al Shamsi-Darmaki]]'
faculty: 88
students: 1260
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# College of Health Sciences

Part of [[University/Nujoom Federal University|NFU]]. Dean: [[People/Prof. Marwan Al Shamsi-Darmaki|Prof. Marwan Al Shamsi-Darmaki]]. 88 faculty, 1,260 students.

## Programmes
- [[Programmes/BSc Nursing|BSc Nursing]] — QFEmirates level 7 (Bachelor), 540 students; AI champion [[People/Dr. Mariam Al Kuwaiti-Rumaithi|Dr. Mariam Al Kuwaiti-Rumaithi]]
- [[Programmes/MSc Public Health Informatics|MSc Public Health Informatics]] — QFEmirates level 9 (Master), 74 students; AI champion [[People/Dr. Yousef Al Ali-Naqbi|Dr. Yousef Al Ali-Naqbi]]

## AI adoption touchpoints
- Faculty cohorts involving this college: [[Cohorts/Cohort 2 — Business & Humanities|Cohort 2 — Business & Humanities]], [[Cohorts/Cohort 3 — Health & Education|Cohort 3 — Health & Education]], [[Cohorts/Cohort 4 — Deans & Chairs|Cohort 4 — Deans & Chairs]], [[Cohorts/Cohort 5 — Adjunct Faculty|Cohort 5 — Adjunct Faculty]]
- Courses redesigned: [[Courses/CHEM 110 General Chemistry|CHEM 110 General Chemistry]], [[Courses/NUR 310 Evidence-Based Practice|NUR 310 Evidence-Based Practice]]
- Deans Council review: [[Meetings/2026-03-11 Deans Council — AI Progress|2026-03-11 Deans Council — AI Progress]]
