---
synthetic: true
tags: [type/college]
dean: '[[People/Dr. Salem Al Marri-Qubaisi]]'
faculty: 84
students: 1132
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# College of Education

Part of [[University/Nujoom Federal University|NFU]]. Dean: [[People/Dr. Salem Al Marri-Qubaisi|Dr. Salem Al Marri-Qubaisi]]. 84 faculty, 1,132 students.

## Programmes
- [[Programmes/BEd Primary Education|BEd Primary Education]] — QFEmirates level 7 (Bachelor), 690 students; AI champion [[People/Dr. Amna Al Kindi-Habsi|Dr. Amna Al Kindi-Habsi]]
- [[Programmes/MEd Educational Technology|MEd Educational Technology]] — QFEmirates level 9 (Master), 112 students; AI champion [[People/Dr. Tariq Al Junaibi-Awadhi|Dr. Tariq Al Junaibi-Awadhi]]

## AI adoption touchpoints
- Faculty cohorts involving this college: [[Cohorts/Cohort 3 — Health & Education|Cohort 3 — Health & Education]], [[Cohorts/Cohort 4 — Deans & Chairs|Cohort 4 — Deans & Chairs]], [[Cohorts/Cohort 5 — Adjunct Faculty|Cohort 5 — Adjunct Faculty]]
- Courses redesigned: [[Courses/EDU 220 Curriculum Design|EDU 220 Curriculum Design]]
- Deans Council review: [[Meetings/2026-03-11 Deans Council — AI Progress|2026-03-11 Deans Council — AI Progress]]
