---
synthetic: true
tags: [type/college]
dean: '[[People/Dr. Fatima Al Ketbi-Rashdan]]'
faculty: 96
students: 1690
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# College of Information Technology

Part of [[University/Nujoom Federal University|NFU]]. Dean: [[People/Dr. Fatima Al Ketbi-Rashdan|Dr. Fatima Al Ketbi-Rashdan]]. 96 faculty, 1,690 students.

## Programmes
- [[Programmes/BSc Computer Science|BSc Computer Science]] — QFEmirates level 7 (Bachelor), 820 students; AI champion [[People/Dr. Omar Al Blooshi-Tayer|Dr. Omar Al Blooshi-Tayer]]
- [[Programmes/MSc Artificial Intelligence|MSc Artificial Intelligence]] — QFEmirates level 9 (Master), 142 students; AI champion [[People/Dr. Latifa Al Shehhi-Ameri|Dr. Latifa Al Shehhi-Ameri]]

## AI adoption touchpoints
- Faculty cohorts involving this college: [[Cohorts/Cohort 1 — Engineering & IT|Cohort 1 — Engineering & IT]], [[Cohorts/Cohort 4 — Deans & Chairs|Cohort 4 — Deans & Chairs]], [[Cohorts/Cohort 5 — Adjunct Faculty|Cohort 5 — Adjunct Faculty]]
- Courses redesigned: [[Courses/CSC 201 Data Structures|CSC 201 Data Structures]], [[Courses/AI 501 Machine Learning|AI 501 Machine Learning]]
- Deans Council review: [[Meetings/2026-03-11 Deans Council — AI Progress|2026-03-11 Deans Council — AI Progress]]
