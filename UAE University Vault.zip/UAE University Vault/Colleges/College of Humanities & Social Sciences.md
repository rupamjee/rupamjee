---
synthetic: true
tags: [type/college]
dean: '[[People/Dr. Noura Al Dhaheri-Kaabi]]'
faculty: 112
students: 1580
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# College of Humanities & Social Sciences

Part of [[University/Nujoom Federal University|NFU]]. Dean: [[People/Dr. Noura Al Dhaheri-Kaabi|Dr. Noura Al Dhaheri-Kaabi]]. 112 faculty, 1,580 students.

## Programmes
- [[Programmes/BA Media & Communication|BA Media & Communication]] — QFEmirates level 7 (Bachelor), 620 students; AI champion [[People/Dr. Shamma Al Muhairi-Yammahi|Dr. Shamma Al Muhairi-Yammahi]]
- [[Programmes/MA Applied Linguistics|MA Applied Linguistics]] — QFEmirates level 9 (Master), 58 students; AI champion [[People/Dr. Rashid Al Shamisi-Ghafli|Dr. Rashid Al Shamisi-Ghafli]]

## AI adoption touchpoints
- Faculty cohorts involving this college: [[Cohorts/Cohort 2 — Business & Humanities|Cohort 2 — Business & Humanities]], [[Cohorts/Cohort 4 — Deans & Chairs|Cohort 4 — Deans & Chairs]], [[Cohorts/Cohort 5 — Adjunct Faculty|Cohort 5 — Adjunct Faculty]]
- Courses redesigned: [[Courses/MCM 150 Media Writing|MCM 150 Media Writing]], [[Courses/LNG 530 Corpus Linguistics|LNG 530 Corpus Linguistics]]
- Deans Council review: [[Meetings/2026-03-11 Deans Council — AI Progress|2026-03-11 Deans Council — AI Progress]]
