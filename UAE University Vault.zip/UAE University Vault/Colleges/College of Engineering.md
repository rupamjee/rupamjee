---
synthetic: true
tags: [type/college]
dean: '[[People/Dr. Khalid Al Mazrouei-Hashimi]]'
faculty: 128
students: 2140
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# College of Engineering

Part of [[University/Nujoom Federal University|NFU]]. Dean: [[People/Dr. Khalid Al Mazrouei-Hashimi|Dr. Khalid Al Mazrouei-Hashimi]]. 128 faculty, 2,140 students.

## Programmes
- [[Programmes/BSc Mechanical Engineering|BSc Mechanical Engineering]] — QFEmirates level 7 (Bachelor), 640 students; AI champion [[People/Dr. Ahmed Al Hammadi-Balushi|Dr. Ahmed Al Hammadi-Balushi]]
- [[Programmes/MSc Robotics & Autonomous Systems|MSc Robotics & Autonomous Systems]] — QFEmirates level 9 (Master), 96 students; AI champion [[People/Dr. Reem Al Falasi-Mansoori|Dr. Reem Al Falasi-Mansoori]]

## AI adoption touchpoints
- Faculty cohorts involving this college: [[Cohorts/Cohort 1 — Engineering & IT|Cohort 1 — Engineering & IT]], [[Cohorts/Cohort 4 — Deans & Chairs|Cohort 4 — Deans & Chairs]], [[Cohorts/Cohort 5 — Adjunct Faculty|Cohort 5 — Adjunct Faculty]]
- Courses redesigned: [[Courses/MATH 101 Calculus I|MATH 101 Calculus I]]
- Deans Council review: [[Meetings/2026-03-11 Deans Council — AI Progress|2026-03-11 Deans Council — AI Progress]]
