---
synthetic: true
tags: [type/incident, risk, ws/assessment]
date: 2025-12-18
severity: high
owner: '[[People/Ms. Salama Al Kaabi-Shamsi]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# INC-01 Fall 2025 integrity case surge

**Date:** 2025-12-18 · **Severity:** high · **Owner:** [[People/Ms. Salama Al Kaabi-Shamsi|Ms. Salama Al Kaabi-Shamsi]] · **Workstream:** [[Workstreams/WS2 Assessment & Academic Integrity|WS2 Assessment & Academic Integrity]]

141 cases in [[Terms/Fall 2025|Fall 2025]], 61% AI-related — the peak in [[Datasets/Academic Integrity Cases by Term|Academic Integrity Cases by Term]]. Concentrated in essay-based courses ([[Courses/MCM 150 Media Writing|MCM 150 Media Writing]], [[Courses/EDU 220 Curriculum Design|EDU 220 Curriculum Design]]). Response: [[Policies/POL-01 AI in Assessment Policy|POL-01 AI in Assessment Policy]] and course redesign ([[Datasets/Course Redesign Tracker|Course Redesign Tracker]]).
