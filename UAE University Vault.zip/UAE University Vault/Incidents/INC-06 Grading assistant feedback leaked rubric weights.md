---
synthetic: true
tags: [type/incident, risk, ws/assessment]
date: 2026-03-18
severity: low
owner: '[[People/Dr. Saeed Al Hosani-Mehairi]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# INC-06 Grading assistant feedback leaked rubric weights

**Date:** 2026-03-18 · **Severity:** low · **Owner:** [[People/Dr. Saeed Al Hosani-Mehairi|Dr. Saeed Al Hosani-Mehairi]] · **Workstream:** [[Workstreams/WS2 Assessment & Academic Integrity|WS2 Assessment & Academic Integrity]]

[[Pilots/PIL-04 Grading Assistant in BUS 205|PIL-04 Grading Assistant in BUS 205]] feedback text revealed hidden rubric weights to students before submission closed. No marks affected (assistant produces feedback only). Fix: rubric redacted from the system prompt.
