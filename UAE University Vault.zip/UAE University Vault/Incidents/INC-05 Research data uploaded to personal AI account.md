---
synthetic: true
tags: [type/incident, risk, ws/research-data]
date: 2026-04-02
severity: high
owner: '[[People/Dr. Ibrahim Al Nuaimi-Dhanhani]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# INC-05 Research data uploaded to personal AI account

**Date:** 2026-04-02 · **Severity:** high · **Owner:** [[People/Dr. Ibrahim Al Nuaimi-Dhanhani|Dr. Ibrahim Al Nuaimi-Dhanhani]] · **Workstream:** [[Workstreams/WS4 Research Data Governance|WS4 Research Data Governance]]

A research assistant in [[Colleges/College of Health Sciences|College of Health Sciences]] pasted de-identified but re-identifiable patient interview transcripts into a personal chatbot account. No confirmed exposure. Trigger for [[Policies/POL-03 Research Data Governance Framework|POL-03 Research Data Governance Framework]] and [[Risks/RSK-07 Shadow AI use in research groups|RSK-07 Shadow AI use in research groups]] ([[Concepts/Shadow AI|Shadow AI]], [[Regulatory Context/UAE PDPL (Federal Decree-Law 45 of 2021)|UAE PDPL (Federal Decree-Law 45 of 2021)]]).
