---
synthetic: true
tags: [type/incident, risk, ws/research-data]
date: 2026-02-11
severity: high
owner: '[[People/Mr. Faisal Al Suwaidi-Bastaki]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# INC-03 At-risk model flag-rate disparity

**Date:** 2026-02-11 · **Severity:** high · **Owner:** [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]] · **Workstream:** [[Workstreams/WS4 Research Data Governance|WS4 Research Data Governance]]

[[Pilots/PIL-05 Predictive At-Risk Model|PIL-05 Predictive At-Risk Model]] flagged 14.2% of Emirati vs 10.1% of non-Emirati students. Root cause: attendance-appeal feature correlated with nationality. After re-weighting: 11.9% vs 11.3%, AUC 0.81 → 0.79. Led to [[Decisions/DEC-06 Require model cards and parity thresholds|DEC-06 Require model cards and parity thresholds]] ([[Concepts/Algorithmic Fairness|Algorithmic Fairness]]).
