---
synthetic: true
tags: [type/incident, risk, ws/tutor]
date: 2025-11-05
severity: medium
owner: '[[People/Dr. Sara Al Marzooqi-Kindi]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# INC-02 Tutor hallucinated a theorem statement

**Date:** 2025-11-05 · **Severity:** medium · **Owner:** [[People/Dr. Sara Al Marzooqi-Kindi|Dr. Sara Al Marzooqi-Kindi]] · **Workstream:** [[Workstreams/WS3 Student AI Tutor Pilot|WS3 Student AI Tutor Pilot]]

[[Pilots/PIL-01 AI Tutor in MATH 101|PIL-01 AI Tutor in MATH 101]] produced an incorrect Mean Value Theorem condition to 4 students. One of 17 flagged [[Concepts/Hallucination|Hallucination]] events (0.17% of 9,840). Fix: [[Concepts/Retrieval-Augmented Generation|Retrieval-Augmented Generation]] restricted to the approved textbook; 'verify with instructor' banner added.
