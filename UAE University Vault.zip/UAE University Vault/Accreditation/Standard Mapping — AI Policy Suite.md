---
synthetic: true
tags: [type/accreditation, ws/governance]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Standard Mapping — AI Policy Suite

Each of the seven policies ([[Policies/POL-01 AI in Assessment Policy|POL-01 AI in Assessment Policy]], [[Policies/POL-02 Acceptable Use of Generative AI|POL-02 Acceptable Use of Generative AI]], [[Policies/POL-03 Research Data Governance Framework|POL-03 Research Data Governance Framework]], [[Policies/POL-04 Student Data Protection Standard|POL-04 Student Data Protection Standard]], [[Policies/POL-05 AI Tool Procurement Standard|POL-05 AI Tool Procurement Standard]], [[Policies/POL-06 Academic Integrity Policy (rev. 2026)|POL-06 Academic Integrity Policy (rev. 2026)]], [[Policies/POL-07 AI Competency in Faculty Promotion Criteria|POL-07 AI Competency in Faculty Promotion Criteria]]) mapped to CAA standard areas and to [[Regulatory Context/UAE AI Charter 2024|UAE AI Charter 2024]] principles. Prepared by [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]] and [[People/Dr. Noor Al Ameri-Hamli|Dr. Noor Al Ameri-Hamli]].
