---
synthetic: true
tags: [type/accreditation, ws/governance]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Self-Study Evidence Map (AI)

Which programme artefacts evidence which standard (built at [[Meetings/2026-04-29 Accreditation Evidence Mapping|2026-04-29 Accreditation Evidence Mapping]]). Governance → [[Policies/POL-02 Acceptable Use of Generative AI|POL-02 Acceptable Use of Generative AI]], Steering Committee minutes; Quality assurance → [[Datasets/Programme KPI Scorecard|Programme KPI Scorecard]]; Educational programme → [[Datasets/Course Redesign Tracker|Course Redesign Tracker]], [[Datasets/MATH 101 Tutor Pilot Outcomes|MATH 101 Tutor Pilot Outcomes]]; Faculty → [[Datasets/WS1 Cohort Completion & Readiness|WS1 Cohort Completion & Readiness]]; Students → [[Datasets/Student AI Tutor Survey|Student AI Tutor Survey]], [[Datasets/Academic Integrity Cases by Term|Academic Integrity Cases by Term]]; Technology resources → [[Datasets/DPIA Register|DPIA Register]], [[Policies/POL-05 AI Tool Procurement Standard|POL-05 AI Tool Procurement Standard]]; Research → [[Policies/POL-03 Research Data Governance Framework|POL-03 Research Data Governance Framework]]. Standard numbers to be confirmed against the published Standards.
