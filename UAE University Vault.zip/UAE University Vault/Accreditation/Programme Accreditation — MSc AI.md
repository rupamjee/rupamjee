---
synthetic: true
tags: [type/accreditation, ws/governance]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Programme Accreditation — MSc AI

Fictional programme-accreditation cycle for [[Programmes/MSc Artificial Intelligence|MSc Artificial Intelligence]] ([[Colleges/College of Information Technology|College of Information Technology]]). Distinctive evidence: [[Courses/AI 501 Machine Learning|AI 501 Machine Learning]] model-card and fairness labs built on [[Incidents/INC-03 At-risk model flag-rate disparity|INC-03 At-risk model flag-rate disparity]]. Champion [[People/Dr. Latifa Al Shehhi-Ameri|Dr. Latifa Al Shehhi-Ameri]]; QFEmirates level 9 ([[Regulatory Context/QFEmirates|QFEmirates]]).
