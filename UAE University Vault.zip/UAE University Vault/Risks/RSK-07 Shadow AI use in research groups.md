---
synthetic: true
tags: [type/risk, risk, ws/research-data]
owner: '[[People/Dr. Ibrahim Al Nuaimi-Dhanhani]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# RSK-07 Shadow AI use in research groups

**Owner:** [[People/Dr. Ibrahim Al Nuaimi-Dhanhani|Dr. Ibrahim Al Nuaimi-Dhanhani]] · **Workstream:** [[Workstreams/WS4 Research Data Governance|WS4 Research Data Governance]]

23 of 41 research groups used personal accounts for unpublished data ([[Meetings/2026-04-08 WS4 Research Data Governance Workshop|2026-04-08 WS4 Research Data Governance Workshop]]); [[Incidents/INC-05 Research data uploaded to personal AI account|INC-05 Research data uploaded to personal AI account]]. Control: [[Policies/POL-03 Research Data Governance Framework|POL-03 Research Data Governance Framework]], approved tools on [[Vendors/Qamar Cloud|Qamar Cloud]] ([[Concepts/Shadow AI|Shadow AI]]). Likelihood high → medium.
