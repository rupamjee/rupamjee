---
synthetic: true
tags: [type/risk, risk, ws/tutor]
owner: '[[People/Dr. Sara Al Marzooqi-Kindi]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# RSK-01 Student over-reliance on AI tutor

**Owner:** [[People/Dr. Sara Al Marzooqi-Kindi|Dr. Sara Al Marzooqi-Kindi]] · **Workstream:** [[Workstreams/WS3 Student AI Tutor Pilot|WS3 Student AI Tutor Pilot]]

63% of students still prefer a human for exam prep but 78% call the tutor helpful ([[Datasets/Student AI Tutor Survey|Student AI Tutor Survey]]); usage 2.3 sessions/week. Mitigation: 'verify with instructor' banner ([[Incidents/INC-02 Tutor hallucinated a theorem statement|INC-02 Tutor hallucinated a theorem statement]]), tutor disabled 48 h before exams. Likelihood medium, impact medium.
