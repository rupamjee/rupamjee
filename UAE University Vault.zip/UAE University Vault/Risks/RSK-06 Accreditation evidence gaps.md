---
synthetic: true
tags: [type/risk, risk, ws/governance]
owner: '[[People/Dr. Noor Al Ameri-Hamli]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# RSK-06 Accreditation evidence gaps

**Owner:** [[People/Dr. Noor Al Ameri-Hamli|Dr. Noor Al Ameri-Hamli]] · **Workstream:** [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]]

No pre-2025 faculty AI-competency baseline; learning-impact evidence only in MATH 101/CHEM 110 ([[Meetings/2026-06-17 Mock Site Visit Debrief|2026-06-17 Mock Site Visit Debrief]]). Mitigation: [[Datasets/Course Redesign Tracker|Course Redesign Tracker]] outcome tracking from [[Terms/Fall 2026|Fall 2026]]; [[Accreditation/Self-Study Evidence Map (AI)|Self-Study Evidence Map (AI)]]. Likelihood medium, impact high for [[Accreditation/CAA Licensure Renewal 2027|CAA Licensure Renewal 2027]].
