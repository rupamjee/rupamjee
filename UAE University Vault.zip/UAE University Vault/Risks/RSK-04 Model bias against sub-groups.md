---
synthetic: true
tags: [type/risk, risk, ws/research-data]
owner: '[[People/Mr. Faisal Al Suwaidi-Bastaki]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# RSK-04 Model bias against sub-groups

**Owner:** [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]] · **Workstream:** [[Workstreams/WS4 Research Data Governance|WS4 Research Data Governance]]

Realised once: [[Incidents/INC-03 At-risk model flag-rate disparity|INC-03 At-risk model flag-rate disparity]] (14.2% vs 10.1%). Control: [[Decisions/DEC-06 Require model cards and parity thresholds|DEC-06 Require model cards and parity thresholds]], [[KPIs/KPI-05 At-risk flag-rate parity|KPI-05 At-risk flag-rate parity]]. Residual likelihood low, impact high.
