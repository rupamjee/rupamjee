---
synthetic: true
tags: [type/risk, risk, ws/governance]
owner: '[[People/Dr. Sultan Al Mansouri-Kalbani]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# RSK-02 Vendor lock-in and data residency

**Owner:** [[People/Dr. Sultan Al Mansouri-Kalbani|Dr. Sultan Al Mansouri-Kalbani]] · **Workstream:** [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]]

Four vendors ([[Vendors/Falaj Learning Systems|Falaj Learning Systems]], [[Vendors/Sidra Analytics|Sidra Analytics]], [[Vendors/Tarhal AI|Tarhal AI]], [[Vendors/Qamar Cloud|Qamar Cloud]]). Mitigation: [[Policies/POL-05 AI Tool Procurement Standard|POL-05 AI Tool Procurement Standard]] exit clauses; UAE residency per [[Regulatory Context/UAE PDPL (Federal Decree-Law 45 of 2021)|UAE PDPL (Federal Decree-Law 45 of 2021)]]. Likelihood medium, impact high.
