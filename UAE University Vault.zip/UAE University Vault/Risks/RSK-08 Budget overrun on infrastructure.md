---
synthetic: true
tags: [type/risk, risk, ws/governance]
owner: '[[People/Dr. Sultan Al Mansouri-Kalbani]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# RSK-08 Budget overrun on infrastructure

**Owner:** [[People/Dr. Sultan Al Mansouri-Kalbani|Dr. Sultan Al Mansouri-Kalbani]] · **Workstream:** [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]]

Infrastructure 71% spent at month 10 vs 58% plan ([[Datasets/Programme Budget FY2025-26|Programme Budget FY2025-26]], [[Meetings/2026-07-08 Budget Mid-year Review|2026-07-08 Budget Mid-year Review]]). Control: [[Decisions/DEC-11 Cap infrastructure spend and reprioritise WS4|DEC-11 Cap infrastructure spend and reprioritise WS4]]; [[KPIs/KPI-10 Budget variance|KPI-10 Budget variance]]. Likelihood medium, impact medium.
