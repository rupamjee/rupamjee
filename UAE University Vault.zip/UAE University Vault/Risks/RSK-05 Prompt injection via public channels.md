---
synthetic: true
tags: [type/risk, risk, ws/automation]
owner: '[[People/Mr. Majid Al Ghafli-Sharqi]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# RSK-05 Prompt injection via public channels

**Owner:** [[People/Mr. Majid Al Ghafli-Sharqi|Mr. Majid Al Ghafli-Sharqi]] · **Workstream:** [[Workstreams/WS5 Administrative Automation|WS5 Administrative Automation]]

Realised once: [[Incidents/INC-04 Prompt injection attempt on registrar chatbot|INC-04 Prompt injection attempt on registrar chatbot]]. Controls: retrieval guard, [[Concepts/Human-in-the-Loop|Human-in-the-Loop]] on record lookups ([[Decisions/DEC-10 Resume Tarhal with human-in-the-loop for record lookups|DEC-10 Resume Tarhal with human-in-the-loop for record lookups]]). Taught in WS1 module 3 ([[Concepts/Prompt Injection|Prompt Injection]]). Likelihood medium, impact high.
