---
synthetic: true
tags: [type/risk, risk, ws/upskilling]
owner: '[[People/Dr. Hamad Al Shorafa-Neyadi]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# RSK-03 Faculty resistance and workload

**Owner:** [[People/Dr. Hamad Al Shorafa-Neyadi|Dr. Hamad Al Shorafa-Neyadi]] · **Workstream:** [[Workstreams/WS1 Faculty AI Upskilling|WS1 Faculty AI Upskilling]]

Adjunct completion 47/60 vs programme 85.5% ([[Datasets/WS1 Cohort Completion & Readiness|WS1 Cohort Completion & Readiness]]); 71% concerned about over-reliance ([[Datasets/Faculty AI Readiness Survey 2025|Faculty AI Readiness Survey 2025]]). Mitigation: [[Decisions/DEC-12 Pay adjuncts for cohort hours|DEC-12 Pay adjuncts for cohort hours]], [[Policies/POL-07 AI Competency in Faculty Promotion Criteria|POL-07 AI Competency in Faculty Promotion Criteria]]. Likelihood high, impact medium.
