---
synthetic: true
tags: [type/dataset, evidence, ws/tutor]
owner: '[[People/Dr. Sara Al Marzooqi-Kindi]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# MATH 101 Tutor Pilot Outcomes

[[Pilots/PIL-01 AI Tutor in MATH 101|PIL-01 AI Tutor in MATH 101]], [[Terms/Fall 2025|Fall 2025]], [[Courses/MATH 101 Calculus I|MATH 101 Calculus I]]. Section-level assignment (not student-level randomisation — see caveat at [[Meetings/2026-01-28 Tutor Pilot Results Review|2026-01-28 Tutor Pilot Results Review]]).

| Arm | Sections | Students | Pass % | DFW % | Tutor sessions / student / week |
|---|---|---|---|---|---|
| Treatment | 6 | 214 | 71.5 | 28.5 | 2.3 |
| Control | 6 | 208 | 63.9 | 36.1 | — |

Interaction log: 9,840 interactions; 17 flagged [[Concepts/Hallucination|Hallucination]] events (0.17%) — [[Incidents/INC-02 Tutor hallucinated a theorem statement|INC-02 Tutor hallucinated a theorem statement]]. Feeds [[KPIs/KPI-03 Gateway-course DFW rate|KPI-03 Gateway-course DFW rate]]; basis for [[Decisions/DEC-05 Extend AI tutor to CHEM 110|DEC-05 Extend AI tutor to CHEM 110]]. Vendor [[Vendors/Falaj Learning Systems|Falaj Learning Systems]]; engineer [[People/Mr. Daniel Okafor-Whitcombe|Mr. Daniel Okafor-Whitcombe]].
