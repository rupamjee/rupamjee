---
synthetic: true
tags: [type/dataset, evidence, ws/assessment]
owner: '[[People/Ms. Salama Al Kaabi-Shamsi]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Academic Integrity Cases by Term

Formal academic-misconduct cases opened per term; "AI-related" = allegation involves unauthorised GenAI use.

| Term | Cases | AI-related % | AI-related cases |
|---|---|---|---|
| Fall 2024 | 62 | 21 | 13 |
| Spring 2025 | 118 | 48 | 57 |
| [[Terms/Fall 2025|Fall 2025]] | 141 | 61 | 86 |
| [[Terms/Spring 2026|Spring 2026]] | 87 | 44 | 38 |

Peak [[Terms/Fall 2025|Fall 2025]] = [[Incidents/INC-01 Fall 2025 integrity case surge|INC-01 Fall 2025 integrity case surge]]. Drop in [[Terms/Spring 2026|Spring 2026]] follows [[Policies/POL-01 AI in Assessment Policy|POL-01 AI in Assessment Policy]] ([[Decisions/DEC-03 Approve AI in Assessment Policy|DEC-03 Approve AI in Assessment Policy]]). Reviewed at [[Meetings/2025-10-22 WS2 Integrity Data Review|2025-10-22 WS2 Integrity Data Review]], [[Meetings/2026-01-14 AI Steering Committee — Q2|2026-01-14 AI Steering Committee — Q2]], [[Meetings/2026-05-13 AI Steering Committee — Q3|2026-05-13 AI Steering Committee — Q3]]. Feeds [[KPIs/KPI-04 AI-related integrity cases|KPI-04 AI-related integrity cases]].
