---
synthetic: true
tags: [type/dataset, evidence, ws/governance]
owner: '[[People/Dr. Laila Al Zaabi-Marzooqi]]'
currency: AED
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Programme Budget FY2025-26

FY2025-26 (Sept–Aug), AED millions. Plan vs actual at month 10 ([[Meetings/2026-07-08 Budget Mid-year Review|2026-07-08 Budget Mid-year Review]]).

| Line | Plan (AED M) | Spent at M10 % |
|---|---|---|
| WS1 Faculty AI Upskilling | 1.20 | 74 |
| WS3 Student AI Tutor Pilot | 1.10 | 69 |
| WS6 AI Governance & Policy | 0.45 | 55 |
| Shared infrastructure (Qamar Cloud) | 1.60 | 71 |
| WS4 Research Data Governance | 0.50 | 38 |
| **Total** | **4.85** | **66** |

Straight-line plan at M10 = 83%; infrastructure was at 71% against a 58% phased plan → [[Risks/RSK-08 Budget overrun on infrastructure|RSK-08 Budget overrun on infrastructure]], [[Decisions/DEC-11 Cap infrastructure spend and reprioritise WS4|DEC-11 Cap infrastructure spend and reprioritise WS4]]. Feeds [[KPIs/KPI-10 Budget variance|KPI-10 Budget variance]]. Chartered by [[Decisions/DEC-01 Charter the AI Adoption Programme|DEC-01 Charter the AI Adoption Programme]].
