---
synthetic: true
tags: [type/dataset, evidence, ws/governance]
owner: '[[People/Mr. Faisal Al Suwaidi-Bastaki]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# DPIA Register

Register of [[Concepts/Data Protection Impact Assessment|Data Protection Impact Assessment]]s for AI systems, kept by [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]] under [[Policies/POL-04 Student Data Protection Standard|POL-04 Student Data Protection Standard]] and [[Regulatory Context/UAE PDPL (Federal Decree-Law 45 of 2021)|UAE PDPL (Federal Decree-Law 45 of 2021)]].

| System | Status | Decision date |
|---|---|---|
| AI tutor (Falaj) | Approved | 2025-10-02 |
| At-risk model (Sidra) | Approved with conditions | 2026-02-11 |
| Registrar chatbot (Tarhal) | Approved | 2025-11-20 |
| Admissions document triage | Pending | — |
| Grading assistant (BUS 205) | Approved | 2026-01-15 |
| Research literature assistant | Approved | 2025-12-04 |
| Proctoring analytics | Rejected | 2026-03-09 |
| Library discovery chatbot | Approved | 2026-04-22 |
| Wellbeing triage bot | Pending | — |

9 registered: 6 approved, 2 pending, 1 rejected ([[Decisions/DEC-09 Reject proctoring analytics DPIA|DEC-09 Reject proctoring analytics DPIA]]). Feeds [[KPIs/KPI-07 DPIA coverage of AI systems|KPI-07 DPIA coverage of AI systems]].
