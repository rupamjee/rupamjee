---
synthetic: true
tags: [type/dataset, evidence, ws/upskilling]
owner: '[[People/Dr. Hamad Al Shorafa-Neyadi]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# WS1 Cohort Completion & Readiness

Source of record for [[Workstreams/WS1 Faculty AI Upskilling|WS1 Faculty AI Upskilling]]. Readiness = mean of a 12-item self-assessment, 1–5. Badge = ≥28/40 on the end-of-cohort test.

| Cohort | Term | Enrolled | Completed | Completion % | Readiness pre | Readiness post | Badges |
|---|---|---|---|---|---|---|---|
| [[Cohorts/Cohort 1 — Engineering & IT|Cohort 1 — Engineering & IT]] | [[Terms/Fall 2025|Fall 2025]] | 48 | 41 | 85.4 | 3.1 | 4.2 | 39 |
| [[Cohorts/Cohort 2 — Business & Humanities|Cohort 2 — Business & Humanities]] | [[Terms/Fall 2025|Fall 2025]] | 52 | 44 | 84.6 | 2.8 | 4.0 | 41 |
| [[Cohorts/Cohort 3 — Health & Education|Cohort 3 — Health & Education]] | [[Terms/Spring 2026|Spring 2026]] | 45 | 40 | 88.9 | 2.9 | 4.1 | 38 |
| [[Cohorts/Cohort 4 — Deans & Chairs|Cohort 4 — Deans & Chairs]] | [[Terms/Spring 2026|Spring 2026]] | 30 | 29 | 96.7 | 3.4 | 4.5 | 29 |
| [[Cohorts/Cohort 5 — Adjunct Faculty|Cohort 5 — Adjunct Faculty]] | [[Terms/Summer 2026|Summer 2026]] | 60 | 47 | 78.3 | 2.6 | 3.9 | 44 |
| [[Cohorts/Cohort 6 — Open Enrolment|Cohort 6 — Open Enrolment]] | [[Terms/Fall 2026|Fall 2026]] | 55 | — | — | 3.0 | — | — |
| **Total (completed cohorts)** |  | **235** | **201** | **85.5** | **2.92** | **4.11** | **191** |

Faculty AI-literate share = 201 / 612 = **32.8%** → [[KPIs/KPI-01 Faculty AI-literate share|KPI-01 Faculty AI-literate share]]. Completion → [[KPIs/KPI-02 Cohort completion rate|KPI-02 Cohort completion rate]]. Cited in [[Meetings/2026-01-14 AI Steering Committee — Q2|2026-01-14 AI Steering Committee — Q2]], [[Meetings/2026-03-11 Deans Council — AI Progress|2026-03-11 Deans Council — AI Progress]], [[Meetings/2026-08-12 Cohort 5 Retrospective|2026-08-12 Cohort 5 Retrospective]], [[Meetings/2026-08-26 AI Steering Committee — Year-1 Review|2026-08-26 AI Steering Committee — Year-1 Review]].
