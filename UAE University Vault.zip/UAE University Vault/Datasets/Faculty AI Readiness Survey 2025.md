---
synthetic: true
tags: [type/dataset, evidence, ws/upskilling]
owner: '[[People/Dr. Hamad Al Shorafa-Neyadi]]'
n: 418
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Faculty AI Readiness Survey 2025

Baseline Sept 2025 (n=418, 68.3% of 612 faculty) and follow-up June 2026 (n=402). Percent agreeing.

| Item | Sept 2025 % | June 2026 % |
|---|---|---|
| Use GenAI weekly in teaching prep | 34 | 61 |
| Confident to detect misuse | 22 | 47 |
| Agree assessment needs redesign | 58 | 79 |
| Aware of AI acceptable-use policy | 19 | 88 |
| Concerned about student over-reliance | 71 | 66 |

Justified [[Decisions/DEC-02 Adopt five-module faculty AI curriculum|DEC-02 Adopt five-module faculty AI curriculum]]; policy-awareness row feeds [[KPIs/KPI-08 Policy awareness among faculty|KPI-08 Policy awareness among faculty]] and [[Policies/POL-02 Acceptable Use of Generative AI|POL-02 Acceptable Use of Generative AI]]. Concern row feeds [[Risks/RSK-03 Faculty resistance and workload|RSK-03 Faculty resistance and workload]].
