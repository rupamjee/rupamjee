---
synthetic: true
tags: [type/dataset, evidence, ws/tutor]
owner: '[[People/Dr. Sara Al Marzooqi-Kindi]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# CHEM 110 Tutor Pilot Wave 2

[[Pilots/PIL-02 AI Tutor in CHEM 110|PIL-02 AI Tutor in CHEM 110]], [[Terms/Spring 2026|Spring 2026]], [[Courses/CHEM 110 General Chemistry|CHEM 110 General Chemistry]]. Student-level randomisation within 4 large sections.

| Arm | Students | Pass % | DFW % |
|---|---|---|---|
| Treatment | 176 | 68.2 | 31.8 |
| Control | 181 | 62.4 | 37.6 |

Difference 5.8 pp, smaller than MATH 101's 7.6 pp ([[Datasets/MATH 101 Tutor Pilot Outcomes|MATH 101 Tutor Pilot Outcomes]]). Feeds [[KPIs/KPI-03 Gateway-course DFW rate|KPI-03 Gateway-course DFW rate]].
