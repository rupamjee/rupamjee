---
synthetic: true
tags: [type/dataset, evidence]
owner: '[[People/Mr. Rashed Al Dhanhani-Tunaiji]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# University Headcount & Emiratisation

AY2025-26 census for [[University/Nujoom Federal University|NFU]].

| College | Faculty | Students |
|---|---|---|
| [[Colleges/College of Engineering|College of Engineering]] | 128 | 2,140 |
| [[Colleges/College of Information Technology|College of Information Technology]] | 96 | 1,690 |
| [[Colleges/College of Business Administration|College of Business Administration]] | 104 | 2,010 |
| [[Colleges/College of Health Sciences|College of Health Sciences]] | 88 | 1,260 |
| [[Colleges/College of Humanities & Social Sciences|College of Humanities & Social Sciences]] | 112 | 1,580 |
| [[Colleges/College of Education|College of Education]] | 84 | 1,132 |
| **Total** | **612** | **9,812** |

Emirati share: students 68%, faculty 27% (target 30% — [[KPIs/KPI-09 Emirati faculty share|KPI-09 Emirati faculty share]], [[Regulatory Context/Emiratisation in Higher Education|Emiratisation in Higher Education]]). Professional staff 940.
