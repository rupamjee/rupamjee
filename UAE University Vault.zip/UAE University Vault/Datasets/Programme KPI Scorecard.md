---
synthetic: true
tags: [type/dataset, evidence, ws/governance, moc]
owner: '[[People/Dr. Laila Al Zaabi-Marzooqi]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Programme KPI Scorecard

Year-1 scorecard presented at [[Meetings/2026-08-26 AI Steering Committee — Year-1 Review|2026-08-26 AI Steering Committee — Year-1 Review]]. Each row links to its KPI note, which links to the dataset it is computed from.

| KPI | Baseline | Year-1 actual | Target | Status |
|---|---|---|---|---|
| [[KPIs/KPI-01 Faculty AI-literate share|KPI-01 Faculty AI-literate share]] | 0% | 32.8% | 40% by Dec 2026 | amber |
| [[KPIs/KPI-02 Cohort completion rate|KPI-02 Cohort completion rate]] | — | 85.5% | ≥85% | green |
| [[KPIs/KPI-03 Gateway-course DFW rate|KPI-03 Gateway-course DFW rate]] | 36.1% (MATH 101 control) | 28.5% | ≤30% | green |
| [[KPIs/KPI-04 AI-related integrity cases|KPI-04 AI-related integrity cases]] | 141 cases (Fall 2025) | 87 (Spring 2026) | ≤100 per term | green |
| [[KPIs/KPI-05 At-risk flag-rate parity|KPI-05 At-risk flag-rate parity]] | 4.1 pp gap | 0.6 pp | ≤2 pp | green |
| [[KPIs/KPI-06 Registrar query deflection|KPI-06 Registrar query deflection]] | 0% | 62% | ≥60% | green |
| [[KPIs/KPI-07 DPIA coverage of AI systems|KPI-07 DPIA coverage of AI systems]] | 0 of 9 | 7 of 9 decided | 100% | amber |
| [[KPIs/KPI-08 Policy awareness among faculty|KPI-08 Policy awareness among faculty]] | 19% | 88% | ≥90% | amber |
| [[KPIs/KPI-09 Emirati faculty share|KPI-09 Emirati faculty share]] | 27% | 27% | 30% by 2028 | red |
| [[KPIs/KPI-10 Budget variance|KPI-10 Budget variance]] | 0% | −17% vs straight-line (66% spent at M10) | ±10% | amber |
