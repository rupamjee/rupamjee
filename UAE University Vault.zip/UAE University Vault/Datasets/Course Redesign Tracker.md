---
synthetic: true
tags: [type/dataset, evidence, ws/assessment]
owner: '[[People/Ms. Salama Al Kaabi-Shamsi]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Course Redesign Tracker

Courses redesigned under [[Workstreams/WS2 Assessment & Academic Integrity|WS2 Assessment & Academic Integrity]] or hosting a [[Workstreams/WS3 Student AI Tutor Pilot|WS3 Student AI Tutor Pilot]].

| Course | Programme | Enrolment | DFW before % | DFW after % | Change |
|---|---|---|---|---|---|
| [[Courses/MATH 101 Calculus I|MATH 101 Calculus I]] | [[Programmes/BSc Mechanical Engineering|BSc Mechanical Engineering]] | 422 | 36.1 | 28.5 | AI tutor pilot (treatment sections) |
| [[Courses/CHEM 110 General Chemistry|CHEM 110 General Chemistry]] | [[Programmes/BSc Nursing|BSc Nursing]] | 357 | 37.6 | 31.8 | AI tutor pilot wave 2 |
| [[Courses/CSC 201 Data Structures|CSC 201 Data Structures]] | [[Programmes/BSc Computer Science|BSc Computer Science]] | 310 | 29.4 | tracking from Fall 2026 | Oral defence added to project assessment |
| [[Courses/BUS 205 Business Communication|BUS 205 Business Communication]] | [[Programmes/BBA Business Analytics|BBA Business Analytics]] | 288 | 12.2 | tracking from Fall 2026 | Grading-assistant pilot (feedback only, not marks) |
| [[Courses/NUR 310 Evidence-Based Practice|NUR 310 Evidence-Based Practice]] | [[Programmes/BSc Nursing|BSc Nursing]] | 190 | 9.8 | tracking from Fall 2026 | AI literature-appraisal assignment with disclosure statement |
| [[Courses/EDU 220 Curriculum Design|EDU 220 Curriculum Design]] | [[Programmes/BEd Primary Education|BEd Primary Education]] | 240 | 11.5 | tracking from Fall 2026 | Authentic assessment redesign; AI-use tiers |
| [[Courses/MCM 150 Media Writing|MCM 150 Media Writing]] | [[Programmes/BA Media & Communication|BA Media & Communication]] | 275 | 14.9 | tracking from Fall 2026 | Process portfolio replaces single essay |
| [[Courses/AI 501 Machine Learning|AI 501 Machine Learning]] | [[Programmes/MSc Artificial Intelligence|MSc Artificial Intelligence]] | 96 | 6.3 | tracking from Fall 2026 | Model-card assignment; fairness audit lab |
| [[Courses/MGT 610 Digital Strategy|MGT 610 Digital Strategy]] | [[Programmes/MBA Digital Transformation|MBA Digital Transformation]] | 140 | 4.1 | tracking from Fall 2026 | GenAI case clinic; disclosure required |
| [[Courses/LNG 530 Corpus Linguistics|LNG 530 Corpus Linguistics]] | [[Programmes/MA Applied Linguistics|MA Applied Linguistics]] | 42 | 3.0 | tracking from Fall 2026 | LLM-as-research-tool ethics module |

Only two courses have outcome data — the gap named in [[Accreditation/Mock Site Visit Findings|Mock Site Visit Findings]] and [[Risks/RSK-06 Accreditation evidence gaps|RSK-06 Accreditation evidence gaps]].
