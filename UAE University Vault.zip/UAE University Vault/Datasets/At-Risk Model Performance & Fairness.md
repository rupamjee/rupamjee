---
synthetic: true
tags: [type/dataset, evidence, ws/research-data]
owner: '[[People/Ms. Hind Al Mehairbi-Yahyaee]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# At-Risk Model Performance & Fairness

[[Pilots/PIL-05 Predictive At-Risk Model|PIL-05 Predictive At-Risk Model]] ([[Vendors/Sidra Analytics|Sidra Analytics]]), scored on 9,812 students, [[Terms/Spring 2026|Spring 2026]].

| Version | AUC | Recall | Flagged | Flag rate % | Flag rate Emirati % | Flag rate non-Emirati % | Gap (pp) |
|---|---|---|---|---|---|---|---|
| v1 (Jan 2026) | 0.81 | 0.72 | 1,140 | 11.6 | 14.2 | 10.1 | 4.1 |
| v2 re-weighted (Mar 2026) | 0.79 | 0.7 | 1,128 | 11.5 | 11.9 | 11.3 | 0.6 |

v1 gap triggered [[Incidents/INC-03 At-risk model flag-rate disparity|INC-03 At-risk model flag-rate disparity]] and [[Decisions/DEC-06 Require model cards and parity thresholds|DEC-06 Require model cards and parity thresholds]] (≤2 pp). Feeds [[KPIs/KPI-05 At-risk flag-rate parity|KPI-05 At-risk flag-rate parity]]. Concepts: [[Concepts/Algorithmic Fairness|Algorithmic Fairness]], [[Concepts/Model Card|Model Card]], [[Concepts/Explainability|Explainability]].
