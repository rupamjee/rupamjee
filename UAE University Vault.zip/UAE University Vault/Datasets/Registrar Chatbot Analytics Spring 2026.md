---
synthetic: true
tags: [type/dataset, evidence, ws/automation]
owner: '[[People/Ms. Aisha Al Otaiba-Mazrui]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Registrar Chatbot Analytics Spring 2026

[[Pilots/PIL-03 Registrar Service Chatbot|PIL-03 Registrar Service Chatbot]] ([[Vendors/Tarhal AI|Tarhal AI]]), [[Terms/Spring 2026|Spring 2026]].

| Metric | Value |
|---|---|
| Queries | 38,400 |
| Deflected (no human needed) % | 62 |
| CSAT (1–5) | 4.1 |
| Injection attempts logged | 1 |
| Top intents | transcript requests, add/drop deadlines, fee statements, attendance appeals |

Injection row = [[Incidents/INC-04 Prompt injection attempt on registrar chatbot|INC-04 Prompt injection attempt on registrar chatbot]]. Feeds [[KPIs/KPI-06 Registrar query deflection|KPI-06 Registrar query deflection]]; reviewed [[Meetings/2026-06-03 WS5 Automation Roadmap|2026-06-03 WS5 Automation Roadmap]].
