---
synthetic: true
tags: [type/dataset, evidence, ws/tutor]
owner: '[[People/Dr. Sara Al Marzooqi-Kindi]]'
n: 387
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Student AI Tutor Survey

Students in tutor treatment sections, [[Terms/Fall 2025|Fall 2025]] + [[Terms/Spring 2026|Spring 2026]], n=387.

| Item | % agree |
|---|---|
| The tutor helped me understand the material | 78 |
| I trust the tutor's answers without checking | 54 |
| I prefer a human tutor for exam preparation | 63 |

Presented at [[Meetings/2026-03-25 Student Council AI Forum|2026-03-25 Student Council AI Forum]] by [[People/Mr. Saif Al Shamsi-Kaabi|Mr. Saif Al Shamsi-Kaabi]]. Feeds [[Risks/RSK-01 Student over-reliance on AI tutor|RSK-01 Student over-reliance on AI tutor]].
