---
synthetic: true
tags: [type/cohort, ws/upskilling]
term: Spring 2026
enrolled: 30
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Cohort 4 — Deans & Chairs

Part of [[Workstreams/WS1 Faculty AI Upskilling|WS1 Faculty AI Upskilling]]. Term [[Terms/Spring 2026|Spring 2026]]. Audience: Academic leadership. Facilitated by [[People/Dr. Sara Al Marzooqi-Kindi|Dr. Sara Al Marzooqi-Kindi]] and [[People/Dr. Hamad Al Shorafa-Neyadi|Dr. Hamad Al Shorafa-Neyadi]].

| Enrolled | Completed | Completion % | Readiness pre → post | Badges |
|---|---|---|---|---|
| 30 | 29 | 96.7 | 3.4 → 4.5 | 29 |

Source of record: [[Datasets/WS1 Cohort Completion & Readiness|WS1 Cohort Completion & Readiness]]. Attendees included all six deans; follow-up at [[Meetings/2026-03-11 Deans Council — AI Progress|2026-03-11 Deans Council — AI Progress]].
