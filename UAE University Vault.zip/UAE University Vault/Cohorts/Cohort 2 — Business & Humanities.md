---
synthetic: true
tags: [type/cohort, ws/upskilling]
term: Fall 2025
enrolled: 52
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Cohort 2 — Business & Humanities

Part of [[Workstreams/WS1 Faculty AI Upskilling|WS1 Faculty AI Upskilling]]. Term [[Terms/Fall 2025|Fall 2025]]. Audience: CBA + CHSS faculty. Facilitated by [[People/Dr. Sara Al Marzooqi-Kindi|Dr. Sara Al Marzooqi-Kindi]] and [[People/Dr. Hamad Al Shorafa-Neyadi|Dr. Hamad Al Shorafa-Neyadi]].

| Enrolled | Completed | Completion % | Readiness pre → post | Badges |
|---|---|---|---|---|
| 52 | 44 | 84.6 | 2.8 → 4.0 | 41 |

Source of record: [[Datasets/WS1 Cohort Completion & Readiness|WS1 Cohort Completion & Readiness]].
