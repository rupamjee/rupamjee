---
synthetic: true
tags: [type/cohort, ws/upskilling]
term: Fall 2026
enrolled: 55
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Cohort 6 — Open Enrolment

Part of [[Workstreams/WS1 Faculty AI Upskilling|WS1 Faculty AI Upskilling]]. Term [[Terms/Fall 2026|Fall 2026]]. Audience: All colleges (in progress). Facilitated by [[People/Dr. Sara Al Marzooqi-Kindi|Dr. Sara Al Marzooqi-Kindi]] and [[People/Dr. Hamad Al Shorafa-Neyadi|Dr. Hamad Al Shorafa-Neyadi]].

Enrolled 55; baseline readiness 3.0. Completion due Dec 2026.

Source of record: [[Datasets/WS1 Cohort Completion & Readiness|WS1 Cohort Completion & Readiness]]. Opened by [[Decisions/DEC-13 Approve Year-2 plan and Cohort 6|DEC-13 Approve Year-2 plan and Cohort 6]]; first paid-adjunct cohort under [[Decisions/DEC-12 Pay adjuncts for cohort hours|DEC-12 Pay adjuncts for cohort hours]].
