---
synthetic: true
tags: [type/cohort, ws/upskilling]
term: Spring 2026
enrolled: 45
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Cohort 3 — Health & Education

Part of [[Workstreams/WS1 Faculty AI Upskilling|WS1 Faculty AI Upskilling]]. Term [[Terms/Spring 2026|Spring 2026]]. Audience: CHS + CED faculty. Facilitated by [[People/Dr. Sara Al Marzooqi-Kindi|Dr. Sara Al Marzooqi-Kindi]] and [[People/Dr. Hamad Al Shorafa-Neyadi|Dr. Hamad Al Shorafa-Neyadi]].

| Enrolled | Completed | Completion % | Readiness pre → post | Badges |
|---|---|---|---|---|
| 45 | 40 | 88.9 | 2.9 → 4.1 | 38 |

Source of record: [[Datasets/WS1 Cohort Completion & Readiness|WS1 Cohort Completion & Readiness]].
