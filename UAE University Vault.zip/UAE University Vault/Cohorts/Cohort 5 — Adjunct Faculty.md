---
synthetic: true
tags: [type/cohort, ws/upskilling]
term: Summer 2026
enrolled: 60
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Cohort 5 — Adjunct Faculty

Part of [[Workstreams/WS1 Faculty AI Upskilling|WS1 Faculty AI Upskilling]]. Term [[Terms/Summer 2026|Summer 2026]]. Audience: Adjuncts, all colleges. Facilitated by [[People/Dr. Sara Al Marzooqi-Kindi|Dr. Sara Al Marzooqi-Kindi]] and [[People/Dr. Hamad Al Shorafa-Neyadi|Dr. Hamad Al Shorafa-Neyadi]].

| Enrolled | Completed | Completion % | Readiness pre → post | Badges |
|---|---|---|---|---|
| 60 | 47 | 78.3 | 2.6 → 3.9 | 44 |

Source of record: [[Datasets/WS1 Cohort Completion & Readiness|WS1 Cohort Completion & Readiness]]. Retrospective: [[Meetings/2026-08-12 Cohort 5 Retrospective|2026-08-12 Cohort 5 Retrospective]] → [[Decisions/DEC-12 Pay adjuncts for cohort hours|DEC-12 Pay adjuncts for cohort hours]].
