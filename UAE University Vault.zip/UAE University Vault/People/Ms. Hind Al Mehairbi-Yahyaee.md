---
synthetic: true
tags: [type/person, role/leadership]
title: Student Success Analytics Lead
unit: Student Affairs
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Ms. Hind Al Mehairbi-Yahyaee

Student Success Analytics Lead, Student Affairs. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Concepts**: [[Concepts/Learning Analytics|Learning Analytics]]
- **Datasets**: [[Datasets/At-Risk Model Performance & Fairness|At-Risk Model Performance & Fairness]]
- **Meetings**: [[Meetings/2026-01-28 Tutor Pilot Results Review|2026-01-28 Tutor Pilot Results Review]], [[Meetings/2026-02-11 Fairness Review — At-Risk Model|2026-02-11 Fairness Review — At-Risk Model]]
- **Pilots**: [[Pilots/PIL-05 Predictive At-Risk Model|PIL-05 Predictive At-Risk Model]]
