---
synthetic: true
tags: [type/person, role/leadership]
title: Data Protection Officer
unit: Legal & Compliance
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Mr. Faisal Al Suwaidi-Bastaki

Data Protection Officer, Legal & Compliance. Fictional person at [[University/Nujoom Federal University|NFU]].

Owns the [[Datasets/DPIA Register|DPIA Register]] and the policy suite; the bridge between [[Workstreams/WS4 Research Data Governance|WS4 Research Data Governance]], [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] and every pilot.

## Appears in
- **Accreditation**: [[Accreditation/Standard Mapping — AI Policy Suite|Standard Mapping — AI Policy Suite]]
- **Datasets**: [[Datasets/DPIA Register|DPIA Register]]
- **Decisions**: [[Decisions/DEC-04 Approve Acceptable Use of Generative AI|DEC-04 Approve Acceptable Use of Generative AI]], [[Decisions/DEC-06 Require model cards and parity thresholds|DEC-06 Require model cards and parity thresholds]], [[Decisions/DEC-09 Reject proctoring analytics DPIA|DEC-09 Reject proctoring analytics DPIA]], [[Decisions/DEC-15 Publish annual AI transparency report|DEC-15 Publish annual AI transparency report]]
- **Incidents**: [[Incidents/INC-03 At-risk model flag-rate disparity|INC-03 At-risk model flag-rate disparity]]
- **Meetings**: [[Meetings/2025-09-03 AI Steering Committee — Inaugural|2025-09-03 AI Steering Committee — Inaugural]], [[Meetings/2025-10-01 DPIA Review — AI Tutor|2025-10-01 DPIA Review — AI Tutor]], [[Meetings/2025-12-10 WS6 Policy Drafting Workshop|2025-12-10 WS6 Policy Drafting Workshop]], [[Meetings/2026-01-14 AI Steering Committee — Q2|2026-01-14 AI Steering Committee — Q2]], [[Meetings/2026-02-11 Fairness Review — At-Risk Model|2026-02-11 Fairness Review — At-Risk Model]], [[Meetings/2026-02-25 Registrar Bot Incident Post-mortem|2026-02-25 Registrar Bot Incident Post-mortem]], [[Meetings/2026-04-08 WS4 Research Data Governance Workshop|2026-04-08 WS4 Research Data Governance Workshop]], [[Meetings/2026-04-29 Accreditation Evidence Mapping|2026-04-29 Accreditation Evidence Mapping]], [[Meetings/2026-05-13 AI Steering Committee — Q3|2026-05-13 AI Steering Committee — Q3]], [[Meetings/2026-06-03 WS5 Automation Roadmap|2026-06-03 WS5 Automation Roadmap]], [[Meetings/2026-08-26 AI Steering Committee — Year-1 Review|2026-08-26 AI Steering Committee — Year-1 Review]]
- **Policies**: [[Policies/POL-02 Acceptable Use of Generative AI|POL-02 Acceptable Use of Generative AI]], [[Policies/POL-04 Student Data Protection Standard|POL-04 Student Data Protection Standard]]
- **Risks**: [[Risks/RSK-04 Model bias against sub-groups|RSK-04 Model bias against sub-groups]]
- **University**: [[University/Nujoom Federal University|Nujoom Federal University]]
- **Workstreams**: [[Workstreams/NFU AI Adoption Programme 2025–27|NFU AI Adoption Programme 2025–27]], [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]]
