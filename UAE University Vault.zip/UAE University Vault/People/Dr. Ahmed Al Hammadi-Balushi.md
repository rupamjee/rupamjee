---
synthetic: true
tags: [type/person, role/champion]
title: AI Faculty Champion, BSc Mechanical Engineering
unit: College of Engineering
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Ahmed Al Hammadi-Balushi

AI Faculty Champion, BSc Mechanical Engineering, College of Engineering. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Colleges**: [[Colleges/College of Engineering|College of Engineering]]
- **Courses**: [[Courses/MATH 101 Calculus I|MATH 101 Calculus I]]
- **Meetings**: [[Meetings/2025-09-17 WS1 Curriculum Design Sprint|2025-09-17 WS1 Curriculum Design Sprint]], [[Meetings/2025-11-12 Tutor Pilot Mid-term Check|2025-11-12 Tutor Pilot Mid-term Check]], [[Meetings/2026-01-28 Tutor Pilot Results Review|2026-01-28 Tutor Pilot Results Review]]
- **Programmes**: [[Programmes/BSc Mechanical Engineering|BSc Mechanical Engineering]]
