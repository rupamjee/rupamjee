---
synthetic: true
tags: [type/person, role/dean]
title: Dean, College of Engineering
unit: College of Engineering
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Khalid Al Mazrouei-Hashimi

Dean, College of Engineering, College of Engineering. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Colleges**: [[Colleges/College of Engineering|College of Engineering]]
- **Meetings**: [[Meetings/2026-03-11 Deans Council — AI Progress|2026-03-11 Deans Council — AI Progress]]
- **University**: [[University/Nujoom Federal University|Nujoom Federal University]]
