---
synthetic: true
tags: [type/person, role/leadership]
title: President, Student Council 2025–26
unit: Student Council
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Mr. Saif Al Shamsi-Kaabi

President, Student Council 2025–26, Student Council. Fictional person at [[University/Nujoom Federal University|NFU]].

Student voice on assessment policy and AI transparency; presented [[Datasets/Student AI Tutor Survey|Student AI Tutor Survey]].

## Appears in
- **Concepts**: [[Concepts/Academic Integrity in the GenAI Era|Academic Integrity in the GenAI Era]]
- **Datasets**: [[Datasets/Student AI Tutor Survey|Student AI Tutor Survey]]
- **Meetings**: [[Meetings/2025-10-22 WS2 Integrity Data Review|2025-10-22 WS2 Integrity Data Review]], [[Meetings/2026-03-25 Student Council AI Forum|2026-03-25 Student Council AI Forum]]
- **Policies**: [[Policies/POL-06 Academic Integrity Policy (rev. 2026)|POL-06 Academic Integrity Policy (rev. 2026)]]
