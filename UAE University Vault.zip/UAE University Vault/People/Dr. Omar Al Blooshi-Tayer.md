---
synthetic: true
tags: [type/person, role/champion]
title: AI Faculty Champion, BSc Computer Science
unit: College of Information Technology
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Omar Al Blooshi-Tayer

AI Faculty Champion, BSc Computer Science, College of Information Technology. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Colleges**: [[Colleges/College of Information Technology|College of Information Technology]]
- **Courses**: [[Courses/CSC 201 Data Structures|CSC 201 Data Structures]]
- **Meetings**: [[Meetings/2025-09-17 WS1 Curriculum Design Sprint|2025-09-17 WS1 Curriculum Design Sprint]]
- **Programmes**: [[Programmes/BSc Computer Science|BSc Computer Science]]
