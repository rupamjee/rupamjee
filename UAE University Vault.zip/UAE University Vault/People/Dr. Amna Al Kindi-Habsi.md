---
synthetic: true
tags: [type/person, role/champion]
title: AI Faculty Champion, BEd Primary Education
unit: College of Education
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Amna Al Kindi-Habsi

AI Faculty Champion, BEd Primary Education, College of Education. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Colleges**: [[Colleges/College of Education|College of Education]]
- **Courses**: [[Courses/EDU 220 Curriculum Design|EDU 220 Curriculum Design]]
- **Programmes**: [[Programmes/BEd Primary Education|BEd Primary Education]]
