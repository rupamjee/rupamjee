---
synthetic: true
tags: [type/person, role/leadership]
title: Head of Information Security
unit: IT Services
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Mr. Majid Al Ghafli-Sharqi

Head of Information Security, IT Services. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Incidents**: [[Incidents/INC-04 Prompt injection attempt on registrar chatbot|INC-04 Prompt injection attempt on registrar chatbot]]
- **Meetings**: [[Meetings/2025-10-01 DPIA Review — AI Tutor|2025-10-01 DPIA Review — AI Tutor]], [[Meetings/2026-02-25 Registrar Bot Incident Post-mortem|2026-02-25 Registrar Bot Incident Post-mortem]], [[Meetings/2026-04-08 WS4 Research Data Governance Workshop|2026-04-08 WS4 Research Data Governance Workshop]]
- **Risks**: [[Risks/RSK-05 Prompt injection via public channels|RSK-05 Prompt injection via public channels]]
