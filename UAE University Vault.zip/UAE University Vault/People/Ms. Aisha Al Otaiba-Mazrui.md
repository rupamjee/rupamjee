---
synthetic: true
tags: [type/person, role/leadership]
title: Registrar
unit: Registrar's Office
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Ms. Aisha Al Otaiba-Mazrui

Registrar, Registrar's Office. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Datasets**: [[Datasets/Registrar Chatbot Analytics Spring 2026|Registrar Chatbot Analytics Spring 2026]]
- **Decisions**: [[Decisions/DEC-10 Resume Tarhal with human-in-the-loop for record lookups|DEC-10 Resume Tarhal with human-in-the-loop for record lookups]]
- **Meetings**: [[Meetings/2026-02-25 Registrar Bot Incident Post-mortem|2026-02-25 Registrar Bot Incident Post-mortem]], [[Meetings/2026-06-03 WS5 Automation Roadmap|2026-06-03 WS5 Automation Roadmap]], [[Meetings/2026-08-26 AI Steering Committee — Year-1 Review|2026-08-26 AI Steering Committee — Year-1 Review]]
- **Pilots**: [[Pilots/PIL-03 Registrar Service Chatbot|PIL-03 Registrar Service Chatbot]]
- **Workstreams**: [[Workstreams/NFU AI Adoption Programme 2025–27|NFU AI Adoption Programme 2025–27]], [[Workstreams/WS5 Administrative Automation|WS5 Administrative Automation]]
