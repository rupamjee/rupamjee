---
synthetic: true
tags: [type/person, role/leadership]
title: Learning Designer, CTL
unit: CTL
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Sara Al Marzooqi-Kindi

Learning Designer, CTL, CTL. Fictional person at [[University/Nujoom Federal University|NFU]].

Designed the WS1 curriculum and runs the tutor pilots; works with [[People/Mr. Daniel Okafor-Whitcombe|Mr. Daniel Okafor-Whitcombe]] and [[Vendors/Falaj Learning Systems|Falaj Learning Systems]].

## Appears in
- **Cohorts**: [[Cohorts/Cohort 1 — Engineering & IT|Cohort 1 — Engineering & IT]], [[Cohorts/Cohort 2 — Business & Humanities|Cohort 2 — Business & Humanities]], [[Cohorts/Cohort 3 — Health & Education|Cohort 3 — Health & Education]], [[Cohorts/Cohort 4 — Deans & Chairs|Cohort 4 — Deans & Chairs]], [[Cohorts/Cohort 5 — Adjunct Faculty|Cohort 5 — Adjunct Faculty]], [[Cohorts/Cohort 6 — Open Enrolment|Cohort 6 — Open Enrolment]]
- **Datasets**: [[Datasets/CHEM 110 Tutor Pilot Wave 2|CHEM 110 Tutor Pilot Wave 2]], [[Datasets/MATH 101 Tutor Pilot Outcomes|MATH 101 Tutor Pilot Outcomes]], [[Datasets/Student AI Tutor Survey|Student AI Tutor Survey]]
- **Decisions**: [[Decisions/DEC-02 Adopt five-module faculty AI curriculum|DEC-02 Adopt five-module faculty AI curriculum]], [[Decisions/DEC-05 Extend AI tutor to CHEM 110|DEC-05 Extend AI tutor to CHEM 110]]
- **Incidents**: [[Incidents/INC-02 Tutor hallucinated a theorem statement|INC-02 Tutor hallucinated a theorem statement]]
- **Meetings**: [[Meetings/2025-09-17 WS1 Curriculum Design Sprint|2025-09-17 WS1 Curriculum Design Sprint]], [[Meetings/2025-10-01 DPIA Review — AI Tutor|2025-10-01 DPIA Review — AI Tutor]], [[Meetings/2025-11-12 Tutor Pilot Mid-term Check|2025-11-12 Tutor Pilot Mid-term Check]], [[Meetings/2026-01-28 Tutor Pilot Results Review|2026-01-28 Tutor Pilot Results Review]], [[Meetings/2026-03-25 Student Council AI Forum|2026-03-25 Student Council AI Forum]], [[Meetings/2026-08-12 Cohort 5 Retrospective|2026-08-12 Cohort 5 Retrospective]]
- **Pilots**: [[Pilots/PIL-01 AI Tutor in MATH 101|PIL-01 AI Tutor in MATH 101]]
- **Risks**: [[Risks/RSK-01 Student over-reliance on AI tutor|RSK-01 Student over-reliance on AI tutor]]
- **Workstreams**: [[Workstreams/NFU AI Adoption Programme 2025–27|NFU AI Adoption Programme 2025–27]], [[Workstreams/WS3 Student AI Tutor Pilot|WS3 Student AI Tutor Pilot]]
