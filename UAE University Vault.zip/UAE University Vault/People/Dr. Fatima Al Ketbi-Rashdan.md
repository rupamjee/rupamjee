---
synthetic: true
tags: [type/person, role/dean]
title: Dean, College of Information Technology
unit: College of Information Technology
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Fatima Al Ketbi-Rashdan

Dean, College of Information Technology, College of Information Technology. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Colleges**: [[Colleges/College of Information Technology|College of Information Technology]]
- **Meetings**: [[Meetings/2026-03-11 Deans Council — AI Progress|2026-03-11 Deans Council — AI Progress]]
- **University**: [[University/Nujoom Federal University|Nujoom Federal University]]
