---
synthetic: true
tags: [type/person, role/external]
title: External Advisor, AI Governance (consultant)
unit: External
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Jonathan Mbeki-Hartley

External Advisor, AI Governance (consultant), External. Fictional person at [[University/Nujoom Federal University|NFU]].

External consultant on governance design; recommended the three-tier assessment scheme at [[Meetings/2025-12-10 WS6 Policy Drafting Workshop|2025-12-10 WS6 Policy Drafting Workshop]].

## Appears in
- **Meetings**: [[Meetings/2025-12-10 WS6 Policy Drafting Workshop|2025-12-10 WS6 Policy Drafting Workshop]]
- **Workstreams**: [[Workstreams/NFU AI Adoption Programme 2025–27|NFU AI Adoption Programme 2025–27]]
