---
synthetic: true
tags: [type/person, role/champion]
title: AI Faculty Champion, MA Applied Linguistics
unit: College of Humanities & Social Sciences
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Rashid Al Shamisi-Ghafli

AI Faculty Champion, MA Applied Linguistics, College of Humanities & Social Sciences. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Colleges**: [[Colleges/College of Humanities & Social Sciences|College of Humanities & Social Sciences]]
- **Courses**: [[Courses/LNG 530 Corpus Linguistics|LNG 530 Corpus Linguistics]]
- **Meetings**: [[Meetings/2026-08-12 Cohort 5 Retrospective|2026-08-12 Cohort 5 Retrospective]]
- **Programmes**: [[Programmes/MA Applied Linguistics|MA Applied Linguistics]]
