---
synthetic: true
tags: [type/person, role/leadership]
title: Vice Chancellor
unit: Office of the Vice Chancellor
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Prof. Abdulla Al Rumaithi-Ghurair

Vice Chancellor, Office of the Vice Chancellor. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Meetings**: [[Meetings/2025-09-03 AI Steering Committee — Inaugural|2025-09-03 AI Steering Committee — Inaugural]], [[Meetings/2026-01-14 AI Steering Committee — Q2|2026-01-14 AI Steering Committee — Q2]], [[Meetings/2026-05-13 AI Steering Committee — Q3|2026-05-13 AI Steering Committee — Q3]], [[Meetings/2026-07-08 Budget Mid-year Review|2026-07-08 Budget Mid-year Review]], [[Meetings/2026-08-26 AI Steering Committee — Year-1 Review|2026-08-26 AI Steering Committee — Year-1 Review]]
- **University**: [[University/Nujoom Federal University|Nujoom Federal University]]
