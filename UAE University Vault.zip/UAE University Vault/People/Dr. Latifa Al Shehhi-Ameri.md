---
synthetic: true
tags: [type/person, role/champion]
title: AI Faculty Champion, MSc Artificial Intelligence
unit: College of Information Technology
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Latifa Al Shehhi-Ameri

AI Faculty Champion, MSc Artificial Intelligence, College of Information Technology. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Accreditation**: [[Accreditation/Programme Accreditation — MSc AI|Programme Accreditation — MSc AI]]
- **Colleges**: [[Colleges/College of Information Technology|College of Information Technology]]
- **Courses**: [[Courses/AI 501 Machine Learning|AI 501 Machine Learning]]
- **Meetings**: [[Meetings/2025-09-17 WS1 Curriculum Design Sprint|2025-09-17 WS1 Curriculum Design Sprint]], [[Meetings/2026-04-08 WS4 Research Data Governance Workshop|2026-04-08 WS4 Research Data Governance Workshop]]
- **Programmes**: [[Programmes/MSc Artificial Intelligence|MSc Artificial Intelligence]]
