---
synthetic: true
tags: [type/person, role/leadership]
title: Head of Assessment & Academic Integrity
unit: CTL
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Ms. Salama Al Kaabi-Shamsi

Head of Assessment & Academic Integrity, CTL. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Datasets**: [[Datasets/Academic Integrity Cases by Term|Academic Integrity Cases by Term]], [[Datasets/Course Redesign Tracker|Course Redesign Tracker]]
- **Decisions**: [[Decisions/DEC-03 Approve AI in Assessment Policy|DEC-03 Approve AI in Assessment Policy]]
- **Incidents**: [[Incidents/INC-01 Fall 2025 integrity case surge|INC-01 Fall 2025 integrity case surge]]
- **Meetings**: [[Meetings/2025-10-22 WS2 Integrity Data Review|2025-10-22 WS2 Integrity Data Review]], [[Meetings/2025-12-10 WS6 Policy Drafting Workshop|2025-12-10 WS6 Policy Drafting Workshop]], [[Meetings/2026-01-14 AI Steering Committee — Q2|2026-01-14 AI Steering Committee — Q2]], [[Meetings/2026-04-29 Accreditation Evidence Mapping|2026-04-29 Accreditation Evidence Mapping]], [[Meetings/2026-08-26 AI Steering Committee — Year-1 Review|2026-08-26 AI Steering Committee — Year-1 Review]]
- **Policies**: [[Policies/POL-01 AI in Assessment Policy|POL-01 AI in Assessment Policy]], [[Policies/POL-06 Academic Integrity Policy (rev. 2026)|POL-06 Academic Integrity Policy (rev. 2026)]]
- **Workstreams**: [[Workstreams/NFU AI Adoption Programme 2025–27|NFU AI Adoption Programme 2025–27]], [[Workstreams/WS2 Assessment & Academic Integrity|WS2 Assessment & Academic Integrity]]
