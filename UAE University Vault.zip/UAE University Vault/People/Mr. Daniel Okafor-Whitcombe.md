---
synthetic: true
tags: [type/person, role/leadership]
title: Learning Analytics Engineer
unit: IT Services
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Mr. Daniel Okafor-Whitcombe

Learning Analytics Engineer, IT Services. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Concepts**: [[Concepts/Learning Analytics|Learning Analytics]]
- **Datasets**: [[Datasets/MATH 101 Tutor Pilot Outcomes|MATH 101 Tutor Pilot Outcomes]]
- **Meetings**: [[Meetings/2025-11-12 Tutor Pilot Mid-term Check|2025-11-12 Tutor Pilot Mid-term Check]], [[Meetings/2026-01-28 Tutor Pilot Results Review|2026-01-28 Tutor Pilot Results Review]], [[Meetings/2026-02-11 Fairness Review — At-Risk Model|2026-02-11 Fairness Review — At-Risk Model]]
- **Pilots**: [[Pilots/PIL-01 AI Tutor in MATH 101|PIL-01 AI Tutor in MATH 101]]
