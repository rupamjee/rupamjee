---
synthetic: true
tags: [type/person, role/leadership]
title: Director, Centre for Teaching & Learning
unit: CTL
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Hamad Al Shorafa-Neyadi

Director, Centre for Teaching & Learning, CTL. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Cohorts**: [[Cohorts/Cohort 1 — Engineering & IT|Cohort 1 — Engineering & IT]], [[Cohorts/Cohort 2 — Business & Humanities|Cohort 2 — Business & Humanities]], [[Cohorts/Cohort 3 — Health & Education|Cohort 3 — Health & Education]], [[Cohorts/Cohort 4 — Deans & Chairs|Cohort 4 — Deans & Chairs]], [[Cohorts/Cohort 5 — Adjunct Faculty|Cohort 5 — Adjunct Faculty]], [[Cohorts/Cohort 6 — Open Enrolment|Cohort 6 — Open Enrolment]]
- **Datasets**: [[Datasets/Faculty AI Readiness Survey 2025|Faculty AI Readiness Survey 2025]], [[Datasets/WS1 Cohort Completion & Readiness|WS1 Cohort Completion & Readiness]]
- **Decisions**: [[Decisions/DEC-02 Adopt five-module faculty AI curriculum|DEC-02 Adopt five-module faculty AI curriculum]]
- **Meetings**: [[Meetings/2025-09-17 WS1 Curriculum Design Sprint|2025-09-17 WS1 Curriculum Design Sprint]], [[Meetings/2025-10-22 WS2 Integrity Data Review|2025-10-22 WS2 Integrity Data Review]], [[Meetings/2026-01-14 AI Steering Committee — Q2|2026-01-14 AI Steering Committee — Q2]], [[Meetings/2026-03-25 Student Council AI Forum|2026-03-25 Student Council AI Forum]], [[Meetings/2026-08-12 Cohort 5 Retrospective|2026-08-12 Cohort 5 Retrospective]], [[Meetings/2026-08-26 AI Steering Committee — Year-1 Review|2026-08-26 AI Steering Committee — Year-1 Review]]
- **Risks**: [[Risks/RSK-03 Faculty resistance and workload|RSK-03 Faculty resistance and workload]]
- **Workstreams**: [[Workstreams/NFU AI Adoption Programme 2025–27|NFU AI Adoption Programme 2025–27]], [[Workstreams/WS1 Faculty AI Upskilling|WS1 Faculty AI Upskilling]]
