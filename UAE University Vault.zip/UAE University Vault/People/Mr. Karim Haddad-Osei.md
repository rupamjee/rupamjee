---
synthetic: true
tags: [type/person, role/external]
title: Account Director, Sidra Analytics
unit: Vendor
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Mr. Karim Haddad-Osei

Account Director, Sidra Analytics, Vendor. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Meetings**: [[Meetings/2026-02-11 Fairness Review — At-Risk Model|2026-02-11 Fairness Review — At-Risk Model]]
- **Vendors**: [[Vendors/Sidra Analytics|Sidra Analytics]]
