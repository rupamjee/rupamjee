---
synthetic: true
tags: [type/person, role/leadership]
title: Chief Information Officer
unit: IT Services
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Sultan Al Mansouri-Kalbani

Chief Information Officer, IT Services. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Decisions**: [[Decisions/DEC-07 Pause Tarhal contract pending remediation|DEC-07 Pause Tarhal contract pending remediation]], [[Decisions/DEC-11 Cap infrastructure spend and reprioritise WS4|DEC-11 Cap infrastructure spend and reprioritise WS4]]
- **Meetings**: [[Meetings/2025-09-03 AI Steering Committee — Inaugural|2025-09-03 AI Steering Committee — Inaugural]], [[Meetings/2026-01-14 AI Steering Committee — Q2|2026-01-14 AI Steering Committee — Q2]], [[Meetings/2026-02-25 Registrar Bot Incident Post-mortem|2026-02-25 Registrar Bot Incident Post-mortem]], [[Meetings/2026-05-13 AI Steering Committee — Q3|2026-05-13 AI Steering Committee — Q3]], [[Meetings/2026-06-03 WS5 Automation Roadmap|2026-06-03 WS5 Automation Roadmap]], [[Meetings/2026-07-08 Budget Mid-year Review|2026-07-08 Budget Mid-year Review]], [[Meetings/2026-08-26 AI Steering Committee — Year-1 Review|2026-08-26 AI Steering Committee — Year-1 Review]]
- **Policies**: [[Policies/POL-05 AI Tool Procurement Standard|POL-05 AI Tool Procurement Standard]]
- **Risks**: [[Risks/RSK-02 Vendor lock-in and data residency|RSK-02 Vendor lock-in and data residency]], [[Risks/RSK-08 Budget overrun on infrastructure|RSK-08 Budget overrun on infrastructure]]
- **University**: [[University/Nujoom Federal University|Nujoom Federal University]]
