---
synthetic: true
tags: [type/person, role/champion]
title: AI Faculty Champion, MSc Robotics & Autonomous Systems
unit: College of Engineering
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Reem Al Falasi-Mansoori

AI Faculty Champion, MSc Robotics & Autonomous Systems, College of Engineering. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Colleges**: [[Colleges/College of Engineering|College of Engineering]]
- **Meetings**: [[Meetings/2025-09-17 WS1 Curriculum Design Sprint|2025-09-17 WS1 Curriculum Design Sprint]]
- **Programmes**: [[Programmes/MSc Robotics & Autonomous Systems|MSc Robotics & Autonomous Systems]]
