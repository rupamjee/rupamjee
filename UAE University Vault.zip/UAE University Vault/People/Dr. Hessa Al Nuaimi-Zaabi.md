---
synthetic: true
tags: [type/person, role/dean]
title: Dean, College of Business Administration
unit: College of Business Administration
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Hessa Al Nuaimi-Zaabi

Dean, College of Business Administration, College of Business Administration. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Colleges**: [[Colleges/College of Business Administration|College of Business Administration]]
- **Decisions**: [[Decisions/DEC-14 Add AI competency to promotion criteria|DEC-14 Add AI competency to promotion criteria]]
- **Meetings**: [[Meetings/2026-03-11 Deans Council — AI Progress|2026-03-11 Deans Council — AI Progress]]
- **Policies**: [[Policies/POL-07 AI Competency in Faculty Promotion Criteria|POL-07 AI Competency in Faculty Promotion Criteria]]
- **University**: [[University/Nujoom Federal University|Nujoom Federal University]]
