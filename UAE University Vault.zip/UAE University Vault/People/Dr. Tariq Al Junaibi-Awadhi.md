---
synthetic: true
tags: [type/person, role/champion]
title: AI Faculty Champion, MEd Educational Technology
unit: College of Education
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Tariq Al Junaibi-Awadhi

AI Faculty Champion, MEd Educational Technology, College of Education. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Colleges**: [[Colleges/College of Education|College of Education]]
- **Programmes**: [[Programmes/MEd Educational Technology|MEd Educational Technology]]
