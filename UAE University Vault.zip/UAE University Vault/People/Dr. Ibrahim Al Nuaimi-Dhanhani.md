---
synthetic: true
tags: [type/person, role/leadership]
title: Director, Research & Graduate Studies
unit: Research Office
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Ibrahim Al Nuaimi-Dhanhani

Director, Research & Graduate Studies, Research Office. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Decisions**: [[Decisions/DEC-08 Adopt Research Data Governance Framework|DEC-08 Adopt Research Data Governance Framework]]
- **Incidents**: [[Incidents/INC-05 Research data uploaded to personal AI account|INC-05 Research data uploaded to personal AI account]]
- **Meetings**: [[Meetings/2026-04-08 WS4 Research Data Governance Workshop|2026-04-08 WS4 Research Data Governance Workshop]], [[Meetings/2026-05-13 AI Steering Committee — Q3|2026-05-13 AI Steering Committee — Q3]], [[Meetings/2026-08-26 AI Steering Committee — Year-1 Review|2026-08-26 AI Steering Committee — Year-1 Review]]
- **Policies**: [[Policies/POL-03 Research Data Governance Framework|POL-03 Research Data Governance Framework]]
- **Risks**: [[Risks/RSK-07 Shadow AI use in research groups|RSK-07 Shadow AI use in research groups]]
- **Workstreams**: [[Workstreams/NFU AI Adoption Programme 2025–27|NFU AI Adoption Programme 2025–27]], [[Workstreams/WS4 Research Data Governance|WS4 Research Data Governance]]
