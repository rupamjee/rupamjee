---
synthetic: true
tags: [type/person, role/leadership]
title: Programme Manager, AI Adoption PMO
unit: Provost's Office
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Ms. Priyanka Raman-Iyer

Programme Manager, AI Adoption PMO, Provost's Office. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Meetings**: [[Meetings/2026-06-03 WS5 Automation Roadmap|2026-06-03 WS5 Automation Roadmap]], [[Meetings/2026-07-08 Budget Mid-year Review|2026-07-08 Budget Mid-year Review]]
- **Workstreams**: [[Workstreams/NFU AI Adoption Programme 2025–27|NFU AI Adoption Programme 2025–27]]
