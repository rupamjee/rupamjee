---
synthetic: true
tags: [type/person, role/dean]
title: Dean, College of Humanities & Social Sciences
unit: College of Humanities & Social Sciences
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Noura Al Dhaheri-Kaabi

Dean, College of Humanities & Social Sciences, College of Humanities & Social Sciences. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Colleges**: [[Colleges/College of Humanities & Social Sciences|College of Humanities & Social Sciences]]
- **Meetings**: [[Meetings/2026-03-11 Deans Council — AI Progress|2026-03-11 Deans Council — AI Progress]]
- **University**: [[University/Nujoom Federal University|Nujoom Federal University]]
