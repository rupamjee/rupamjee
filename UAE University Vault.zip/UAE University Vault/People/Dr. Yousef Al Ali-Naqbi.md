---
synthetic: true
tags: [type/person, role/champion]
title: AI Faculty Champion, MSc Public Health Informatics
unit: College of Health Sciences
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Yousef Al Ali-Naqbi

AI Faculty Champion, MSc Public Health Informatics, College of Health Sciences. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Colleges**: [[Colleges/College of Health Sciences|College of Health Sciences]]
- **Programmes**: [[Programmes/MSc Public Health Informatics|MSc Public Health Informatics]]
