---
synthetic: true
tags: [type/person, role/champion]
title: AI Faculty Champion, BSc Nursing
unit: College of Health Sciences
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Mariam Al Kuwaiti-Rumaithi

AI Faculty Champion, BSc Nursing, College of Health Sciences. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Colleges**: [[Colleges/College of Health Sciences|College of Health Sciences]]
- **Courses**: [[Courses/CHEM 110 General Chemistry|CHEM 110 General Chemistry]], [[Courses/NUR 310 Evidence-Based Practice|NUR 310 Evidence-Based Practice]]
- **Pilots**: [[Pilots/PIL-02 AI Tutor in CHEM 110|PIL-02 AI Tutor in CHEM 110]]
- **Programmes**: [[Programmes/BSc Nursing|BSc Nursing]]
