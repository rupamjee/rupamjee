---
synthetic: true
tags: [type/person, role/leadership]
title: Director, Student Counselling & Wellbeing
unit: Student Affairs
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Elena Vasquez-Moreau

Director, Student Counselling & Wellbeing, Student Affairs. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Concepts**: [[Concepts/Human-in-the-Loop|Human-in-the-Loop]]
- **Meetings**: [[Meetings/2026-02-11 Fairness Review — At-Risk Model|2026-02-11 Fairness Review — At-Risk Model]], [[Meetings/2026-03-25 Student Council AI Forum|2026-03-25 Student Council AI Forum]]
- **Pilots**: [[Pilots/PIL-05 Predictive At-Risk Model|PIL-05 Predictive At-Risk Model]]
