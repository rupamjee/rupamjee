---
synthetic: true
tags: [type/person, role/leadership]
title: Provost & Chief Academic Officer
unit: Provost's Office
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Prof. Maitha Al Hosani-Falahi

Provost & Chief Academic Officer, Provost's Office. Fictional person at [[University/Nujoom Federal University|NFU]].

Chairs the AI Steering Committee with [[People/Prof. Abdulla Al Rumaithi-Ghurair|Prof. Abdulla Al Rumaithi-Ghurair]]; sponsor of [[Workstreams/WS1 Faculty AI Upskilling|WS1 Faculty AI Upskilling]] and [[Workstreams/WS2 Assessment & Academic Integrity|WS2 Assessment & Academic Integrity]].

## Appears in
- **Decisions**: [[Decisions/DEC-01 Charter the AI Adoption Programme|DEC-01 Charter the AI Adoption Programme]], [[Decisions/DEC-14 Add AI competency to promotion criteria|DEC-14 Add AI competency to promotion criteria]]
- **Meetings**: [[Meetings/2025-09-03 AI Steering Committee — Inaugural|2025-09-03 AI Steering Committee — Inaugural]], [[Meetings/2025-12-10 WS6 Policy Drafting Workshop|2025-12-10 WS6 Policy Drafting Workshop]], [[Meetings/2026-01-14 AI Steering Committee — Q2|2026-01-14 AI Steering Committee — Q2]], [[Meetings/2026-01-28 Tutor Pilot Results Review|2026-01-28 Tutor Pilot Results Review]], [[Meetings/2026-03-11 Deans Council — AI Progress|2026-03-11 Deans Council — AI Progress]], [[Meetings/2026-05-13 AI Steering Committee — Q3|2026-05-13 AI Steering Committee — Q3]], [[Meetings/2026-06-17 Mock Site Visit Debrief|2026-06-17 Mock Site Visit Debrief]], [[Meetings/2026-08-26 AI Steering Committee — Year-1 Review|2026-08-26 AI Steering Committee — Year-1 Review]]
- **Policies**: [[Policies/POL-07 AI Competency in Faculty Promotion Criteria|POL-07 AI Competency in Faculty Promotion Criteria]]
- **University**: [[University/Nujoom Federal University|Nujoom Federal University]]
