---
synthetic: true
tags: [type/person, role/leadership]
title: Director, AI Adoption Programme (PMO)
unit: Provost's Office
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Laila Al Zaabi-Marzooqi

Director, AI Adoption Programme (PMO), Provost's Office. Fictional person at [[University/Nujoom Federal University|NFU]].

Runs the PMO with [[People/Ms. Priyanka Raman-Iyer|Ms. Priyanka Raman-Iyer]]; reports to [[People/Prof. Maitha Al Hosani-Falahi|Prof. Maitha Al Hosani-Falahi]]; presents the [[Datasets/Programme KPI Scorecard|Programme KPI Scorecard]] to the Steering Committee.

## Appears in
- **Accreditation**: [[Accreditation/Mock Site Visit Findings|Mock Site Visit Findings]]
- **Datasets**: [[Datasets/Programme Budget FY2025-26|Programme Budget FY2025-26]], [[Datasets/Programme KPI Scorecard|Programme KPI Scorecard]]
- **Decisions**: [[Decisions/DEC-01 Charter the AI Adoption Programme|DEC-01 Charter the AI Adoption Programme]], [[Decisions/DEC-13 Approve Year-2 plan and Cohort 6|DEC-13 Approve Year-2 plan and Cohort 6]]
- **Meetings**: [[Meetings/2025-09-03 AI Steering Committee — Inaugural|2025-09-03 AI Steering Committee — Inaugural]], [[Meetings/2025-09-17 WS1 Curriculum Design Sprint|2025-09-17 WS1 Curriculum Design Sprint]], [[Meetings/2026-01-14 AI Steering Committee — Q2|2026-01-14 AI Steering Committee — Q2]], [[Meetings/2026-03-11 Deans Council — AI Progress|2026-03-11 Deans Council — AI Progress]], [[Meetings/2026-04-29 Accreditation Evidence Mapping|2026-04-29 Accreditation Evidence Mapping]], [[Meetings/2026-05-13 AI Steering Committee — Q3|2026-05-13 AI Steering Committee — Q3]], [[Meetings/2026-06-17 Mock Site Visit Debrief|2026-06-17 Mock Site Visit Debrief]], [[Meetings/2026-07-08 Budget Mid-year Review|2026-07-08 Budget Mid-year Review]], [[Meetings/2026-08-26 AI Steering Committee — Year-1 Review|2026-08-26 AI Steering Committee — Year-1 Review]]
- **University**: [[University/Nujoom Federal University|Nujoom Federal University]]
- **Workstreams**: [[Workstreams/NFU AI Adoption Programme 2025–27|NFU AI Adoption Programme 2025–27]]
