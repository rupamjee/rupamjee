---
synthetic: true
tags: [type/person, role/leadership]
title: University Librarian
unit: Library
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Ms. Moza Al Qubaisi-Hameli

University Librarian, Library. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Meetings**: [[Meetings/2025-12-10 WS6 Policy Drafting Workshop|2025-12-10 WS6 Policy Drafting Workshop]], [[Meetings/2026-04-08 WS4 Research Data Governance Workshop|2026-04-08 WS4 Research Data Governance Workshop]]
- **Pilots**: [[Pilots/PIL-06 Research Literature Assistant|PIL-06 Research Literature Assistant]]
