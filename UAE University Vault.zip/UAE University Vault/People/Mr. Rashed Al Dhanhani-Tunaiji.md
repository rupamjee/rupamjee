---
synthetic: true
tags: [type/person, role/leadership]
title: Director, HR & Emiratisation
unit: Human Resources
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Mr. Rashed Al Dhanhani-Tunaiji

Director, HR & Emiratisation, Human Resources. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Datasets**: [[Datasets/University Headcount & Emiratisation|University Headcount & Emiratisation]]
- **Decisions**: [[Decisions/DEC-12 Pay adjuncts for cohort hours|DEC-12 Pay adjuncts for cohort hours]]
- **Meetings**: [[Meetings/2026-08-12 Cohort 5 Retrospective|2026-08-12 Cohort 5 Retrospective]]
- **Policies**: [[Policies/POL-07 AI Competency in Faculty Promotion Criteria|POL-07 AI Competency in Faculty Promotion Criteria]]
- **Regulatory Context**: [[Regulatory Context/Emiratisation in Higher Education|Emiratisation in Higher Education]]
