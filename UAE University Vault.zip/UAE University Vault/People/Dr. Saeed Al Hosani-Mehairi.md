---
synthetic: true
tags: [type/person, role/champion]
title: AI Faculty Champion, BBA Business Analytics
unit: College of Business Administration
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Saeed Al Hosani-Mehairi

AI Faculty Champion, BBA Business Analytics, College of Business Administration. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Colleges**: [[Colleges/College of Business Administration|College of Business Administration]]
- **Courses**: [[Courses/BUS 205 Business Communication|BUS 205 Business Communication]]
- **Incidents**: [[Incidents/INC-06 Grading assistant feedback leaked rubric weights|INC-06 Grading assistant feedback leaked rubric weights]]
- **Meetings**: [[Meetings/2026-04-08 WS4 Research Data Governance Workshop|2026-04-08 WS4 Research Data Governance Workshop]]
- **Pilots**: [[Pilots/PIL-04 Grading Assistant in BUS 205|PIL-04 Grading Assistant in BUS 205]]
- **Programmes**: [[Programmes/BBA Business Analytics|BBA Business Analytics]]
