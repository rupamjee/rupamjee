---
synthetic: true
tags: [type/person, role/leadership]
title: Director, Institutional Effectiveness & Accreditation
unit: IE&A
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Noor Al Ameri-Hamli

Director, Institutional Effectiveness & Accreditation, IE&A. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Accreditation**: [[Accreditation/CAA Licensure Renewal 2027|CAA Licensure Renewal 2027]], [[Accreditation/Standard Mapping — AI Policy Suite|Standard Mapping — AI Policy Suite]]
- **Meetings**: [[Meetings/2025-09-03 AI Steering Committee — Inaugural|2025-09-03 AI Steering Committee — Inaugural]], [[Meetings/2025-10-22 WS2 Integrity Data Review|2025-10-22 WS2 Integrity Data Review]], [[Meetings/2026-04-29 Accreditation Evidence Mapping|2026-04-29 Accreditation Evidence Mapping]], [[Meetings/2026-05-13 AI Steering Committee — Q3|2026-05-13 AI Steering Committee — Q3]], [[Meetings/2026-06-17 Mock Site Visit Debrief|2026-06-17 Mock Site Visit Debrief]], [[Meetings/2026-08-26 AI Steering Committee — Year-1 Review|2026-08-26 AI Steering Committee — Year-1 Review]]
- **Risks**: [[Risks/RSK-06 Accreditation evidence gaps|RSK-06 Accreditation evidence gaps]]
- **University**: [[University/Nujoom Federal University|Nujoom Federal University]]
