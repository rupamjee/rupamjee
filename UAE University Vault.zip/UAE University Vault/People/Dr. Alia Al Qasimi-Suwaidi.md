---
synthetic: true
tags: [type/person, role/champion]
title: AI Faculty Champion, MBA Digital Transformation
unit: College of Business Administration
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Dr. Alia Al Qasimi-Suwaidi

AI Faculty Champion, MBA Digital Transformation, College of Business Administration. Fictional person at [[University/Nujoom Federal University|NFU]].



## Appears in
- **Colleges**: [[Colleges/College of Business Administration|College of Business Administration]]
- **Courses**: [[Courses/MGT 610 Digital Strategy|MGT 610 Digital Strategy]]
- **Programmes**: [[Programmes/MBA Digital Transformation|MBA Digital Transformation]]
