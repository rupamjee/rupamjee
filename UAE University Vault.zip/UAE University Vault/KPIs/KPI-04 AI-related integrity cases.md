---
synthetic: true
tags: [type/kpi, ws/assessment]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# KPI-04 AI-related integrity cases

**Workstream:** [[Workstreams/WS2 Assessment & Academic Integrity|WS2 Assessment & Academic Integrity]] · On the [[Datasets/Programme KPI Scorecard|Programme KPI Scorecard]].

AI-related misconduct cases per term: 13 → 57 → 86 → 38. Total cases 141 → 87 after [[Policies/POL-01 AI in Assessment Policy|POL-01 AI in Assessment Policy]]. Source [[Datasets/Academic Integrity Cases by Term|Academic Integrity Cases by Term]].
