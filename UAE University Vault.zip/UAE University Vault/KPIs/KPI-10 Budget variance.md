---
synthetic: true
tags: [type/kpi, ws/governance]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# KPI-10 Budget variance

**Workstream:** [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] · On the [[Datasets/Programme KPI Scorecard|Programme KPI Scorecard]].

Spend vs phased plan. Portfolio 66% spent at M10; infrastructure 71% vs 58% plan → [[Decisions/DEC-11 Cap infrastructure spend and reprioritise WS4|DEC-11 Cap infrastructure spend and reprioritise WS4]]. Source [[Datasets/Programme Budget FY2025-26|Programme Budget FY2025-26]].
