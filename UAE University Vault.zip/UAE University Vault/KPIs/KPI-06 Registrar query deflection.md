---
synthetic: true
tags: [type/kpi, ws/automation]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# KPI-06 Registrar query deflection

**Workstream:** [[Workstreams/WS5 Administrative Automation|WS5 Administrative Automation]] · On the [[Datasets/Programme KPI Scorecard|Programme KPI Scorecard]].

Registrar queries resolved without a human: **62%** of 38,400 ([[Datasets/Registrar Chatbot Analytics Spring 2026|Registrar Chatbot Analytics Spring 2026]]). Target ≥60%. Record-lookup intents now human-approved ([[Decisions/DEC-10 Resume Tarhal with human-in-the-loop for record lookups|DEC-10 Resume Tarhal with human-in-the-loop for record lookups]]).
