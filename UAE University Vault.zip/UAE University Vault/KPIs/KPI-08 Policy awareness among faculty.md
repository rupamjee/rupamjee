---
synthetic: true
tags: [type/kpi, ws/governance]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# KPI-08 Policy awareness among faculty

**Workstream:** [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] · On the [[Datasets/Programme KPI Scorecard|Programme KPI Scorecard]].

Faculty aware of [[Policies/POL-02 Acceptable Use of Generative AI|POL-02 Acceptable Use of Generative AI]]: 19% (Sept 2025) → 88% (June 2026). Source [[Datasets/Faculty AI Readiness Survey 2025|Faculty AI Readiness Survey 2025]]. Target ≥90%.
