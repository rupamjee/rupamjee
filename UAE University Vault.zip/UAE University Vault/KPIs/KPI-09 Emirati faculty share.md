---
synthetic: true
tags: [type/kpi, ws/upskilling]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# KPI-09 Emirati faculty share

**Workstream:** [[Workstreams/WS1 Faculty AI Upskilling|WS1 Faculty AI Upskilling]] · On the [[Datasets/Programme KPI Scorecard|Programme KPI Scorecard]].

Emirati share of faculty 27% vs 30% target; WS1 badges are being used as a development pathway ([[Decisions/DEC-12 Pay adjuncts for cohort hours|DEC-12 Pay adjuncts for cohort hours]] funded from Emiratisation budget). Source [[Datasets/University Headcount & Emiratisation|University Headcount & Emiratisation]]; context [[Regulatory Context/Emiratisation in Higher Education|Emiratisation in Higher Education]].
