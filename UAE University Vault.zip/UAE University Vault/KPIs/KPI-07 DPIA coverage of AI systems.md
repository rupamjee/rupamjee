---
synthetic: true
tags: [type/kpi, ws/governance]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# KPI-07 DPIA coverage of AI systems

**Workstream:** [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] · On the [[Datasets/Programme KPI Scorecard|Programme KPI Scorecard]].

AI systems with a decided DPIA ÷ systems in the register = 7 ÷ 9. Two pending (admissions triage, wellbeing bot). Source [[Datasets/DPIA Register|DPIA Register]].
