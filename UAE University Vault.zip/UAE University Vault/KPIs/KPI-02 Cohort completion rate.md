---
synthetic: true
tags: [type/kpi, ws/upskilling]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# KPI-02 Cohort completion rate

**Workstream:** [[Workstreams/WS1 Faculty AI Upskilling|WS1 Faculty AI Upskilling]] · On the [[Datasets/Programme KPI Scorecard|Programme KPI Scorecard]].

Completed ÷ enrolled across closed cohorts = 201 ÷ 235 = **85.5%**. Lowest cohort: adjuncts 78.3% → [[Decisions/DEC-12 Pay adjuncts for cohort hours|DEC-12 Pay adjuncts for cohort hours]]. Source [[Datasets/WS1 Cohort Completion & Readiness|WS1 Cohort Completion & Readiness]].
