---
synthetic: true
tags: [type/kpi, ws/research-data]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# KPI-05 At-risk flag-rate parity

**Workstream:** [[Workstreams/WS4 Research Data Governance|WS4 Research Data Governance]] · On the [[Datasets/Programme KPI Scorecard|Programme KPI Scorecard]].

Absolute difference in at-risk flag rate between nationality groups: 4.1 pp (v1) → 0.6 pp (v2). Threshold ≤2 pp per [[Decisions/DEC-06 Require model cards and parity thresholds|DEC-06 Require model cards and parity thresholds]]. Source [[Datasets/At-Risk Model Performance & Fairness|At-Risk Model Performance & Fairness]].
