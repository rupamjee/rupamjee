---
synthetic: true
tags: [type/kpi, ws/upskilling]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# KPI-01 Faculty AI-literate share

**Workstream:** [[Workstreams/WS1 Faculty AI Upskilling|WS1 Faculty AI Upskilling]] · On the [[Datasets/Programme KPI Scorecard|Programme KPI Scorecard]].

Faculty who completed a WS1 cohort ÷ total faculty = 201 ÷ 612 = **32.8%**. Target 40% by Dec 2026 (needs 44 more completions; Cohort 6 has 55 enrolled). Source [[Datasets/WS1 Cohort Completion & Readiness|WS1 Cohort Completion & Readiness]], [[Datasets/University Headcount & Emiratisation|University Headcount & Emiratisation]].
