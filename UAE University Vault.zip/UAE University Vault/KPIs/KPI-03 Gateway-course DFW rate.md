---
synthetic: true
tags: [type/kpi, ws/tutor]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# KPI-03 Gateway-course DFW rate

**Workstream:** [[Workstreams/WS3 Student AI Tutor Pilot|WS3 Student AI Tutor Pilot]] · On the [[Datasets/Programme KPI Scorecard|Programme KPI Scorecard]].

Share of D/F/Withdraw grades in gateway courses. MATH 101: 36.1% control vs 28.5% treatment ([[Datasets/MATH 101 Tutor Pilot Outcomes|MATH 101 Tutor Pilot Outcomes]]); CHEM 110: 37.6% vs 31.8% ([[Datasets/CHEM 110 Tutor Pilot Wave 2|CHEM 110 Tutor Pilot Wave 2]]). Target ≤30% in piloted courses.
