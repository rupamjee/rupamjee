---
synthetic: true
tags: [meta, moc]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Graph Reading Guide

Settings → Graph view → **Groups**: add one group per folder (`path:People`, `path:Meetings`, …). Then look for:

- **Hubs.** [[People/Dr. Laila Al Zaabi-Marzooqi|Dr. Laila Al Zaabi-Marzooqi]], [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]] and [[People/Prof. Maitha Al Hosani-Falahi|Prof. Maitha Al Hosani-Falahi]] sit on almost every cluster. [[Datasets/Programme KPI Scorecard|Programme KPI Scorecard]] and [[Workstreams/NFU AI Adoption Programme 2025–27|the programme hub]] are the structural hubs.
- **Bridges.** [[Concepts/Prompt Injection|Prompt Injection]] joins WS1 (teaching) to WS5 (an incident). [[Incidents/INC-03 At-risk model flag-rate disparity|INC-03 At-risk model flag-rate disparity]] joins WS4 governance to a taught course ([[Courses/AI 501 Machine Learning|AI 501 Machine Learning]]) and to a vendor. [[People/Mr. Rashed Al Dhanhani-Tunaiji|Mr. Rashed Al Dhanhani-Tunaiji]] joins WS1 to [[Regulatory Context/Emiratisation in Higher Education|Emiratisation in Higher Education]].
- **Chains.** Dataset → Meeting → Decision → Policy/Pilot → KPI. Every decision note names its meeting and its evidence, so the chain is always two hops.
- **Periphery.** [[Regulatory Context/QFEmirates|QFEmirates]] touches all 12 programmes but few events — a real framework sitting under the fiction. [[Vendors/Qamar Cloud|Qamar Cloud]] is infrastructure: many inbound links, no meetings of its own.
- **Time.** Open `path:Meetings` only and sort by name: filenames start with ISO dates so the graph reads left-to-right when arranged by hand, or use [[Timeline]].

Useful filters: `tag:#type/decision`, `tag:#risk`, `tag:#ws/tutor`, `-path:People` (structure without the people), `path:Datasets OR path:KPIs` (the evidence layer only).
