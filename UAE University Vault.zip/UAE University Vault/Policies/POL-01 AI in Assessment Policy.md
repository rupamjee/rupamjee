---
synthetic: true
tags: [type/policy, ws/governance]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# POL-01 AI in Assessment Policy

Part of the [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] suite. Three tiers per assessment (AI not permitted / permitted with disclosure / AI required); mandatory disclosure statement; instructors declare tier in the syllabus. Approved [[Decisions/DEC-03 Approve AI in Assessment Policy|DEC-03 Approve AI in Assessment Policy]] at [[Meetings/2026-01-14 AI Steering Committee — Q2|2026-01-14 AI Steering Committee — Q2]]; drafted [[Meetings/2025-12-10 WS6 Policy Drafting Workshop|2025-12-10 WS6 Policy Drafting Workshop]] on input from [[Meetings/2025-10-22 WS2 Integrity Data Review|2025-10-22 WS2 Integrity Data Review]]. Effect: 141 → 87 cases ([[Datasets/Academic Integrity Cases by Term|Academic Integrity Cases by Term]]). Owner [[People/Ms. Salama Al Kaabi-Shamsi|Ms. Salama Al Kaabi-Shamsi]]. Concepts: [[Concepts/Authentic Assessment|Authentic Assessment]], [[Concepts/Academic Integrity in the GenAI Era|Academic Integrity in the GenAI Era]].

Accreditation mapping: [[Accreditation/Standard Mapping — AI Policy Suite|Standard Mapping — AI Policy Suite]].
