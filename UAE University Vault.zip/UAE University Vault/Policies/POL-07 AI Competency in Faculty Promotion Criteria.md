---
synthetic: true
tags: [type/policy, ws/governance]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# POL-07 AI Competency in Faculty Promotion Criteria

Part of the [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] suite. Proposed by [[People/Dr. Hessa Al Nuaimi-Zaabi|Dr. Hessa Al Nuaimi-Zaabi]] at [[Meetings/2026-03-11 Deans Council — AI Progress|2026-03-11 Deans Council — AI Progress]]; [[Decisions/DEC-14 Add AI competency to promotion criteria|DEC-14 Add AI competency to promotion criteria]] (proposed). Evidence = WS1 badge or equivalent. Owner [[People/Prof. Maitha Al Hosani-Falahi|Prof. Maitha Al Hosani-Falahi]]; HR [[People/Mr. Rashed Al Dhanhani-Tunaiji|Mr. Rashed Al Dhanhani-Tunaiji]]. Links [[KPIs/KPI-01 Faculty AI-literate share|KPI-01 Faculty AI-literate share]].

Accreditation mapping: [[Accreditation/Standard Mapping — AI Policy Suite|Standard Mapping — AI Policy Suite]].
