---
synthetic: true
tags: [type/policy, ws/governance]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# POL-02 Acceptable Use of Generative AI

Part of the [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] suite. Staff and student rules: approved tools list, no personal data of others in non-approved tools, cite AI assistance. Approved [[Decisions/DEC-04 Approve Acceptable Use of Generative AI|DEC-04 Approve Acceptable Use of Generative AI]]. Awareness moved 19% → 88% in [[Datasets/Faculty AI Readiness Survey 2025|Faculty AI Readiness Survey 2025]] follow-up ([[KPIs/KPI-08 Policy awareness among faculty|KPI-08 Policy awareness among faculty]]). Owner [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]]. Anchors [[Regulatory Context/UAE AI Charter 2024|UAE AI Charter 2024]], [[Regulatory Context/UAE PDPL (Federal Decree-Law 45 of 2021)|UAE PDPL (Federal Decree-Law 45 of 2021)]]. Taught in module 3 of [[Workstreams/WS1 Faculty AI Upskilling|WS1 Faculty AI Upskilling]].

Accreditation mapping: [[Accreditation/Standard Mapping — AI Policy Suite|Standard Mapping — AI Policy Suite]].
