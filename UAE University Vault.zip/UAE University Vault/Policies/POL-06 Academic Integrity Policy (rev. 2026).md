---
synthetic: true
tags: [type/policy, ws/governance]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# POL-06 Academic Integrity Policy (rev. 2026)

Part of the [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] suite. Revision aligning misconduct definitions with [[Policies/POL-01 AI in Assessment Policy|POL-01 AI in Assessment Policy]] tiers; detection-tool output alone is not evidence. Owner [[People/Ms. Salama Al Kaabi-Shamsi|Ms. Salama Al Kaabi-Shamsi]]; Student Council consulted ([[People/Mr. Saif Al Shamsi-Kaabi|Mr. Saif Al Shamsi-Kaabi]]). Cases: [[Datasets/Academic Integrity Cases by Term|Academic Integrity Cases by Term]].

Accreditation mapping: [[Accreditation/Standard Mapping — AI Policy Suite|Standard Mapping — AI Policy Suite]].
