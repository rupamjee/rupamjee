---
synthetic: true
tags: [type/policy, ws/governance]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# POL-03 Research Data Governance Framework

Part of the [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] suite. Five data tiers; tiers 3–5 (identifiable, sensitive, restricted) only in approved tools on [[Vendors/Qamar Cloud|Qamar Cloud]]; DPIA before any model touches tier ≥3. Adopted [[Decisions/DEC-08 Adopt Research Data Governance Framework|DEC-08 Adopt Research Data Governance Framework]]; drafted at [[Meetings/2026-04-08 WS4 Research Data Governance Workshop|2026-04-08 WS4 Research Data Governance Workshop]] after [[Incidents/INC-05 Research data uploaded to personal AI account|INC-05 Research data uploaded to personal AI account]]. Owner [[People/Dr. Ibrahim Al Nuaimi-Dhanhani|Dr. Ibrahim Al Nuaimi-Dhanhani]]. Concepts [[Concepts/Data Minimisation|Data Minimisation]], [[Concepts/Shadow AI|Shadow AI]].

Accreditation mapping: [[Accreditation/Standard Mapping — AI Policy Suite|Standard Mapping — AI Policy Suite]].
