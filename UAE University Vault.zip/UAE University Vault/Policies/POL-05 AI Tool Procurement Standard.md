---
synthetic: true
tags: [type/policy, ws/governance]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# POL-05 AI Tool Procurement Standard

Part of the [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] suite. UAE data residency, no training on NFU data, model card on request, exit/portability clause. Owner [[People/Dr. Sultan Al Mansouri-Kalbani|Dr. Sultan Al Mansouri-Kalbani]]. Applied to [[Vendors/Falaj Learning Systems|Falaj Learning Systems]], [[Vendors/Sidra Analytics|Sidra Analytics]], [[Vendors/Tarhal AI|Tarhal AI]], [[Vendors/Qamar Cloud|Qamar Cloud]]. Mitigates [[Risks/RSK-02 Vendor lock-in and data residency|RSK-02 Vendor lock-in and data residency]].

Accreditation mapping: [[Accreditation/Standard Mapping — AI Policy Suite|Standard Mapping — AI Policy Suite]].
