---
synthetic: true
tags: [type/programme, qfe/level-7]
college: '[[Colleges/College of Business Administration]]'
qfemirates_level: 7
students: 710
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# BBA Business Analytics

Bachelor programme in [[Colleges/College of Business Administration|College of Business Administration]], 710 students, [[Regulatory Context/QFEmirates|QFEmirates]] level 7. AI faculty champion: [[People/Dr. Saeed Al Hosani-Mehairi|Dr. Saeed Al Hosani-Mehairi]].

## Courses touched by the programme
- [[Courses/BUS 205 Business Communication|BUS 205 Business Communication]] — Grading-assistant pilot (feedback only, not marks)

## Accreditation
Programme evidence feeds [[Accreditation/Self-Study Evidence Map (AI)|Self-Study Evidence Map (AI)]].
