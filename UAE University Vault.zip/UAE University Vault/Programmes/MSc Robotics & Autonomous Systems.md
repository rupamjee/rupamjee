---
synthetic: true
tags: [type/programme, qfe/level-9]
college: '[[Colleges/College of Engineering]]'
qfemirates_level: 9
students: 96
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# MSc Robotics & Autonomous Systems

Master programme in [[Colleges/College of Engineering|College of Engineering]], 96 students, [[Regulatory Context/QFEmirates|QFEmirates]] level 9. AI faculty champion: [[People/Dr. Reem Al Falasi-Mansoori|Dr. Reem Al Falasi-Mansoori]].

## Courses touched by the programme
- none yet (candidate for Year 2)

## Accreditation
Programme evidence feeds [[Accreditation/Self-Study Evidence Map (AI)|Self-Study Evidence Map (AI)]].
