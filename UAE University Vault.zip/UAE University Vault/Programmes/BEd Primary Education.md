---
synthetic: true
tags: [type/programme, qfe/level-7]
college: '[[Colleges/College of Education]]'
qfemirates_level: 7
students: 690
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# BEd Primary Education

Bachelor programme in [[Colleges/College of Education|College of Education]], 690 students, [[Regulatory Context/QFEmirates|QFEmirates]] level 7. AI faculty champion: [[People/Dr. Amna Al Kindi-Habsi|Dr. Amna Al Kindi-Habsi]].

## Courses touched by the programme
- [[Courses/EDU 220 Curriculum Design|EDU 220 Curriculum Design]] — Authentic assessment redesign; AI-use tiers

## Accreditation
Programme evidence feeds [[Accreditation/Self-Study Evidence Map (AI)|Self-Study Evidence Map (AI)]].
