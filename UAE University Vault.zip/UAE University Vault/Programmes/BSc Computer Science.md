---
synthetic: true
tags: [type/programme, qfe/level-7]
college: '[[Colleges/College of Information Technology]]'
qfemirates_level: 7
students: 820
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# BSc Computer Science

Bachelor programme in [[Colleges/College of Information Technology|College of Information Technology]], 820 students, [[Regulatory Context/QFEmirates|QFEmirates]] level 7. AI faculty champion: [[People/Dr. Omar Al Blooshi-Tayer|Dr. Omar Al Blooshi-Tayer]].

## Courses touched by the programme
- [[Courses/CSC 201 Data Structures|CSC 201 Data Structures]] — Oral defence added to project assessment

## Accreditation
Programme evidence feeds [[Accreditation/Self-Study Evidence Map (AI)|Self-Study Evidence Map (AI)]].
