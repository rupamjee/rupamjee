---
synthetic: true
tags: [type/programme, qfe/level-7]
college: '[[Colleges/College of Engineering]]'
qfemirates_level: 7
students: 640
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# BSc Mechanical Engineering

Bachelor programme in [[Colleges/College of Engineering|College of Engineering]], 640 students, [[Regulatory Context/QFEmirates|QFEmirates]] level 7. AI faculty champion: [[People/Dr. Ahmed Al Hammadi-Balushi|Dr. Ahmed Al Hammadi-Balushi]].

## Courses touched by the programme
- [[Courses/MATH 101 Calculus I|MATH 101 Calculus I]] — AI tutor pilot (treatment sections)

## Accreditation
Programme evidence feeds [[Accreditation/Self-Study Evidence Map (AI)|Self-Study Evidence Map (AI)]].
