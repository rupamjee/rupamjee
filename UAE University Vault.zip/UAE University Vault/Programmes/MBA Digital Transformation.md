---
synthetic: true
tags: [type/programme, qfe/level-9]
college: '[[Colleges/College of Business Administration]]'
qfemirates_level: 9
students: 188
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# MBA Digital Transformation

Master programme in [[Colleges/College of Business Administration|College of Business Administration]], 188 students, [[Regulatory Context/QFEmirates|QFEmirates]] level 9. AI faculty champion: [[People/Dr. Alia Al Qasimi-Suwaidi|Dr. Alia Al Qasimi-Suwaidi]].

## Courses touched by the programme
- [[Courses/MGT 610 Digital Strategy|MGT 610 Digital Strategy]] — GenAI case clinic; disclosure required

## Accreditation
Programme evidence feeds [[Accreditation/Self-Study Evidence Map (AI)|Self-Study Evidence Map (AI)]].
