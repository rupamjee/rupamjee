---
synthetic: true
tags: [type/programme, qfe/level-9]
college: '[[Colleges/College of Health Sciences]]'
qfemirates_level: 9
students: 74
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# MSc Public Health Informatics

Master programme in [[Colleges/College of Health Sciences|College of Health Sciences]], 74 students, [[Regulatory Context/QFEmirates|QFEmirates]] level 9. AI faculty champion: [[People/Dr. Yousef Al Ali-Naqbi|Dr. Yousef Al Ali-Naqbi]].

## Courses touched by the programme
- none yet (candidate for Year 2)

## Accreditation
Programme evidence feeds [[Accreditation/Self-Study Evidence Map (AI)|Self-Study Evidence Map (AI)]].
