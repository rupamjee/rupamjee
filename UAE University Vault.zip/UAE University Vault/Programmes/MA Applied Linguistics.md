---
synthetic: true
tags: [type/programme, qfe/level-9]
college: '[[Colleges/College of Humanities & Social Sciences]]'
qfemirates_level: 9
students: 58
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# MA Applied Linguistics

Master programme in [[Colleges/College of Humanities & Social Sciences|College of Humanities & Social Sciences]], 58 students, [[Regulatory Context/QFEmirates|QFEmirates]] level 9. AI faculty champion: [[People/Dr. Rashid Al Shamisi-Ghafli|Dr. Rashid Al Shamisi-Ghafli]].

## Courses touched by the programme
- [[Courses/LNG 530 Corpus Linguistics|LNG 530 Corpus Linguistics]] — LLM-as-research-tool ethics module

## Accreditation
Programme evidence feeds [[Accreditation/Self-Study Evidence Map (AI)|Self-Study Evidence Map (AI)]].
