---
synthetic: true
tags: [type/programme, qfe/level-9]
college: '[[Colleges/College of Education]]'
qfemirates_level: 9
students: 112
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# MEd Educational Technology

Master programme in [[Colleges/College of Education|College of Education]], 112 students, [[Regulatory Context/QFEmirates|QFEmirates]] level 9. AI faculty champion: [[People/Dr. Tariq Al Junaibi-Awadhi|Dr. Tariq Al Junaibi-Awadhi]].

## Courses touched by the programme
- none yet (candidate for Year 2)

## Accreditation
Programme evidence feeds [[Accreditation/Self-Study Evidence Map (AI)|Self-Study Evidence Map (AI)]].
