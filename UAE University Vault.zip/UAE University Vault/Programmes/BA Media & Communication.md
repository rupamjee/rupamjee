---
synthetic: true
tags: [type/programme, qfe/level-7]
college: '[[Colleges/College of Humanities & Social Sciences]]'
qfemirates_level: 7
students: 620
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# BA Media & Communication

Bachelor programme in [[Colleges/College of Humanities & Social Sciences|College of Humanities & Social Sciences]], 620 students, [[Regulatory Context/QFEmirates|QFEmirates]] level 7. AI faculty champion: [[People/Dr. Shamma Al Muhairi-Yammahi|Dr. Shamma Al Muhairi-Yammahi]].

## Courses touched by the programme
- [[Courses/MCM 150 Media Writing|MCM 150 Media Writing]] — Process portfolio replaces single essay

## Accreditation
Programme evidence feeds [[Accreditation/Self-Study Evidence Map (AI)|Self-Study Evidence Map (AI)]].
