---
synthetic: true
tags: [type/programme, qfe/level-9]
college: '[[Colleges/College of Information Technology]]'
qfemirates_level: 9
students: 142
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# MSc Artificial Intelligence

Master programme in [[Colleges/College of Information Technology|College of Information Technology]], 142 students, [[Regulatory Context/QFEmirates|QFEmirates]] level 9. AI faculty champion: [[People/Dr. Latifa Al Shehhi-Ameri|Dr. Latifa Al Shehhi-Ameri]].

## Courses touched by the programme
- [[Courses/AI 501 Machine Learning|AI 501 Machine Learning]] — Model-card assignment; fairness audit lab

## Accreditation
Programme evidence feeds [[Accreditation/Self-Study Evidence Map (AI)|Self-Study Evidence Map (AI)]]. Separate programme accreditation: [[Accreditation/Programme Accreditation — MSc AI|Programme Accreditation — MSc AI]]
