---
synthetic: true
tags: [type/programme, qfe/level-7]
college: '[[Colleges/College of Health Sciences]]'
qfemirates_level: 7
students: 540
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# BSc Nursing

Bachelor programme in [[Colleges/College of Health Sciences|College of Health Sciences]], 540 students, [[Regulatory Context/QFEmirates|QFEmirates]] level 7. AI faculty champion: [[People/Dr. Mariam Al Kuwaiti-Rumaithi|Dr. Mariam Al Kuwaiti-Rumaithi]].

## Courses touched by the programme
- [[Courses/CHEM 110 General Chemistry|CHEM 110 General Chemistry]] — AI tutor pilot wave 2
- [[Courses/NUR 310 Evidence-Based Practice|NUR 310 Evidence-Based Practice]] — AI literature-appraisal assignment with disclosure statement

## Accreditation
Programme evidence feeds [[Accreditation/Self-Study Evidence Map (AI)|Self-Study Evidence Map (AI)]].
