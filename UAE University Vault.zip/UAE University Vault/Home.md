---
synthetic: true
tags: [moc, home]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Nujoom Federal University — AI Adoption Knowledge Vault

A fully synthetic wiki for a fictional UAE federal university running a two-year AI adoption programme. Built to be read in Obsidian's **graph view**: colour groups by folder and start with [[Graph Reading Guide]].

## Start here
- [[University/Nujoom Federal University|Nujoom Federal University]] — the institution
- [[Workstreams/NFU AI Adoption Programme 2025–27|NFU AI Adoption Programme 2025–27]] — the programme hub, six workstreams
- [[Datasets/Programme KPI Scorecard|Programme KPI Scorecard]] — ten KPIs, each traceable to a dataset
- [[Timeline]] — every dated event in order
- [[Regulatory Sources]] — the real UAE frameworks referenced, with links

## Clusters
| Folder | Notes | What |
|---|---|---|
| University / Colleges / Programmes / Courses | 29 | Academic structure; QFEmirates levels; redesigned courses |
| People | 41 | Leadership, deans, 12 faculty champions, students, externals, vendors |
| Workstreams / Pilots / Cohorts | 19 | What the programme actually did |
| Policies / Regulatory Context / Accreditation | 19 | Rules — fictional policies, real frameworks, CAA cycle |
| Meetings / Decisions / Incidents / Risks | 49 | The narrative: what was decided, what went wrong |
| Datasets / KPIs | 23 | Every number in the vault lives in a Dataset; KPIs compute from them |
| Concepts / Vendors / Terms | 24 | Vocabulary, suppliers, academic calendar |

Total notes: 210.

## Five stories to follow in the graph
1. **Integrity surge → policy → drop.** [[Datasets/Academic Integrity Cases by Term|Academic Integrity Cases by Term]] → [[Incidents/INC-01 Fall 2025 integrity case surge|INC-01 Fall 2025 integrity case surge]] → [[Meetings/2025-12-10 WS6 Policy Drafting Workshop|2025-12-10 WS6 Policy Drafting Workshop]] → [[Decisions/DEC-03 Approve AI in Assessment Policy|DEC-03 Approve AI in Assessment Policy]] → [[Policies/POL-01 AI in Assessment Policy|POL-01 AI in Assessment Policy]] → [[KPIs/KPI-04 AI-related integrity cases|KPI-04 AI-related integrity cases]].
2. **Tutor pilot → evidence → extension.** [[Pilots/PIL-01 AI Tutor in MATH 101|PIL-01 AI Tutor in MATH 101]] → [[Datasets/MATH 101 Tutor Pilot Outcomes|MATH 101 Tutor Pilot Outcomes]] → [[Meetings/2026-01-28 Tutor Pilot Results Review|2026-01-28 Tutor Pilot Results Review]] → [[Decisions/DEC-05 Extend AI tutor to CHEM 110|DEC-05 Extend AI tutor to CHEM 110]] → [[Pilots/PIL-02 AI Tutor in CHEM 110|PIL-02 AI Tutor in CHEM 110]].
3. **Fairness incident → governance rule.** [[Incidents/INC-03 At-risk model flag-rate disparity|INC-03 At-risk model flag-rate disparity]] → [[Decisions/DEC-06 Require model cards and parity thresholds|DEC-06 Require model cards and parity thresholds]] → [[Concepts/Model Card|Model Card]] → [[Courses/AI 501 Machine Learning|AI 501 Machine Learning]] (incident becomes teaching material).
4. **Injection → pause → human-in-the-loop.** [[Incidents/INC-04 Prompt injection attempt on registrar chatbot|INC-04 Prompt injection attempt on registrar chatbot]] → [[Decisions/DEC-07 Pause Tarhal contract pending remediation|DEC-07 Pause Tarhal contract pending remediation]] → [[Decisions/DEC-10 Resume Tarhal with human-in-the-loop for record lookups|DEC-10 Resume Tarhal with human-in-the-loop for record lookups]].
5. **Adjunct completion → pay decision → Emiratisation budget.** [[Cohorts/Cohort 5 — Adjunct Faculty|Cohort 5 — Adjunct Faculty]] → [[Meetings/2026-08-12 Cohort 5 Retrospective|2026-08-12 Cohort 5 Retrospective]] → [[Decisions/DEC-12 Pay adjuncts for cohort hours|DEC-12 Pay adjuncts for cohort hours]] → [[KPIs/KPI-09 Emirati faculty share|KPI-09 Emirati faculty share]].

See [[Vault Conventions]] and [[Tag Index]].
