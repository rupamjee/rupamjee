---
synthetic: true
tags: [type/course, ws/assessment]
programme: '[[Programmes/BA Media & Communication]]'
enrolment: 275
dfw_before: 14.9
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# MCM 150 Media Writing

Course in [[Programmes/BA Media & Communication|BA Media & Communication]]; 275 students per year. DFW 14.9% (outcome tracking from [[Terms/Fall 2026|Fall 2026]]). Change: Process portfolio replaces single essay. Tracked in [[Datasets/Course Redesign Tracker|Course Redesign Tracker]]. Champion: [[People/Dr. Shamma Al Muhairi-Yammahi|Dr. Shamma Al Muhairi-Yammahi]].
Context: [[Incidents/INC-01 Fall 2025 integrity case surge|INC-01 Fall 2025 integrity case surge]] · Policy: [[Policies/POL-01 AI in Assessment Policy|POL-01 AI in Assessment Policy]]
