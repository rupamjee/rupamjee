---
synthetic: true
tags: [type/course, ws/assessment]
programme: '[[Programmes/MSc Artificial Intelligence]]'
enrolment: 96
dfw_before: 6.3
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# AI 501 Machine Learning

Course in [[Programmes/MSc Artificial Intelligence|MSc Artificial Intelligence]]; 96 students per year. DFW 6.3% (outcome tracking from [[Terms/Fall 2026|Fall 2026]]). Change: Model-card assignment; fairness audit lab. Tracked in [[Datasets/Course Redesign Tracker|Course Redesign Tracker]]. Champion: [[People/Dr. Latifa Al Shehhi-Ameri|Dr. Latifa Al Shehhi-Ameri]].
Concepts taught: [[Concepts/Model Card|Model Card]], [[Concepts/Algorithmic Fairness|Algorithmic Fairness]], [[Concepts/Explainability|Explainability]] — uses the anonymised [[Incidents/INC-03 At-risk model flag-rate disparity|INC-03 At-risk model flag-rate disparity]] as a case.
