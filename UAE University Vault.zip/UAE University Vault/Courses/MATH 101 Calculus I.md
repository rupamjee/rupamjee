---
synthetic: true
tags: [type/course, ws/assessment]
programme: '[[Programmes/BSc Mechanical Engineering]]'
enrolment: 422
dfw_before: 36.1
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# MATH 101 Calculus I

Course in [[Programmes/BSc Mechanical Engineering|BSc Mechanical Engineering]]; 422 students per year. DFW 36.1% → 28.5%. Change: AI tutor pilot (treatment sections). Tracked in [[Datasets/Course Redesign Tracker|Course Redesign Tracker]]. Champion: [[People/Dr. Ahmed Al Hammadi-Balushi|Dr. Ahmed Al Hammadi-Balushi]].
Pilot: [[Pilots/PIL-01 AI Tutor in MATH 101|PIL-01 AI Tutor in MATH 101]] · Data: [[Datasets/MATH 101 Tutor Pilot Outcomes|MATH 101 Tutor Pilot Outcomes]] · Incident: [[Incidents/INC-02 Tutor hallucinated a theorem statement|INC-02 Tutor hallucinated a theorem statement]]
