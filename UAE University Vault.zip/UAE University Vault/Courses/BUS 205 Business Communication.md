---
synthetic: true
tags: [type/course, ws/assessment]
programme: '[[Programmes/BBA Business Analytics]]'
enrolment: 288
dfw_before: 12.2
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# BUS 205 Business Communication

Course in [[Programmes/BBA Business Analytics|BBA Business Analytics]]; 288 students per year. DFW 12.2% (outcome tracking from [[Terms/Fall 2026|Fall 2026]]). Change: Grading-assistant pilot (feedback only, not marks). Tracked in [[Datasets/Course Redesign Tracker|Course Redesign Tracker]]. Champion: [[People/Dr. Saeed Al Hosani-Mehairi|Dr. Saeed Al Hosani-Mehairi]].
Pilot: [[Pilots/PIL-04 Grading Assistant in BUS 205|PIL-04 Grading Assistant in BUS 205]] · Incident: [[Incidents/INC-06 Grading assistant feedback leaked rubric weights|INC-06 Grading assistant feedback leaked rubric weights]]
