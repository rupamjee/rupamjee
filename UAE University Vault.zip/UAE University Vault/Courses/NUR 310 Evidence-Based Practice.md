---
synthetic: true
tags: [type/course, ws/assessment]
programme: '[[Programmes/BSc Nursing]]'
enrolment: 190
dfw_before: 9.8
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# NUR 310 Evidence-Based Practice

Course in [[Programmes/BSc Nursing|BSc Nursing]]; 190 students per year. DFW 9.8% (outcome tracking from [[Terms/Fall 2026|Fall 2026]]). Change: AI literature-appraisal assignment with disclosure statement. Tracked in [[Datasets/Course Redesign Tracker|Course Redesign Tracker]]. Champion: [[People/Dr. Mariam Al Kuwaiti-Rumaithi|Dr. Mariam Al Kuwaiti-Rumaithi]].
