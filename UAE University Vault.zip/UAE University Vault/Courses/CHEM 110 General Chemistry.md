---
synthetic: true
tags: [type/course, ws/assessment]
programme: '[[Programmes/BSc Nursing]]'
enrolment: 357
dfw_before: 37.6
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# CHEM 110 General Chemistry

Course in [[Programmes/BSc Nursing|BSc Nursing]]; 357 students per year. DFW 37.6% → 31.8%. Change: AI tutor pilot wave 2. Tracked in [[Datasets/Course Redesign Tracker|Course Redesign Tracker]]. Champion: [[People/Dr. Mariam Al Kuwaiti-Rumaithi|Dr. Mariam Al Kuwaiti-Rumaithi]].
Pilot: [[Pilots/PIL-02 AI Tutor in CHEM 110|PIL-02 AI Tutor in CHEM 110]] · Data: [[Datasets/CHEM 110 Tutor Pilot Wave 2|CHEM 110 Tutor Pilot Wave 2]]
