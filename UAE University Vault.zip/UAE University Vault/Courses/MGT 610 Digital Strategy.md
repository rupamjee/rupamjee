---
synthetic: true
tags: [type/course, ws/assessment]
programme: '[[Programmes/MBA Digital Transformation]]'
enrolment: 140
dfw_before: 4.1
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# MGT 610 Digital Strategy

Course in [[Programmes/MBA Digital Transformation|MBA Digital Transformation]]; 140 students per year. DFW 4.1% (outcome tracking from [[Terms/Fall 2026|Fall 2026]]). Change: GenAI case clinic; disclosure required. Tracked in [[Datasets/Course Redesign Tracker|Course Redesign Tracker]]. Champion: [[People/Dr. Alia Al Qasimi-Suwaidi|Dr. Alia Al Qasimi-Suwaidi]].
