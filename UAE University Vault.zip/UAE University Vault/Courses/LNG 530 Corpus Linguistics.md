---
synthetic: true
tags: [type/course, ws/assessment]
programme: '[[Programmes/MA Applied Linguistics]]'
enrolment: 42
dfw_before: 3.0
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# LNG 530 Corpus Linguistics

Course in [[Programmes/MA Applied Linguistics|MA Applied Linguistics]]; 42 students per year. DFW 3.0% (outcome tracking from [[Terms/Fall 2026|Fall 2026]]). Change: LLM-as-research-tool ethics module. Tracked in [[Datasets/Course Redesign Tracker|Course Redesign Tracker]]. Champion: [[People/Dr. Rashid Al Shamisi-Ghafli|Dr. Rashid Al Shamisi-Ghafli]].
