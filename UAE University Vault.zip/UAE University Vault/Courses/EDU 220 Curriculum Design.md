---
synthetic: true
tags: [type/course, ws/assessment]
programme: '[[Programmes/BEd Primary Education]]'
enrolment: 240
dfw_before: 11.5
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# EDU 220 Curriculum Design

Course in [[Programmes/BEd Primary Education|BEd Primary Education]]; 240 students per year. DFW 11.5% (outcome tracking from [[Terms/Fall 2026|Fall 2026]]). Change: Authentic assessment redesign; AI-use tiers. Tracked in [[Datasets/Course Redesign Tracker|Course Redesign Tracker]]. Champion: [[People/Dr. Amna Al Kindi-Habsi|Dr. Amna Al Kindi-Habsi]].
Context: [[Incidents/INC-01 Fall 2025 integrity case surge|INC-01 Fall 2025 integrity case surge]] · Policy: [[Policies/POL-01 AI in Assessment Policy|POL-01 AI in Assessment Policy]]
