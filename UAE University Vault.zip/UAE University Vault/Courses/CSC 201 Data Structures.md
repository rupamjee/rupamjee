---
synthetic: true
tags: [type/course, ws/assessment]
programme: '[[Programmes/BSc Computer Science]]'
enrolment: 310
dfw_before: 29.4
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# CSC 201 Data Structures

Course in [[Programmes/BSc Computer Science|BSc Computer Science]]; 310 students per year. DFW 29.4% (outcome tracking from [[Terms/Fall 2026|Fall 2026]]). Change: Oral defence added to project assessment. Tracked in [[Datasets/Course Redesign Tracker|Course Redesign Tracker]]. Champion: [[People/Dr. Omar Al Blooshi-Tayer|Dr. Omar Al Blooshi-Tayer]].
