---
synthetic: true
tags: [type/university]
founded: 2004
students: 9812
faculty: 612
staff: 940
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Nujoom Federal University (NFU)

Fictional federal university, founded 2004, campuses in Abu Dhabi and Al Ain. 9,812 students (68% Emirati), 612 faculty (27% Emirati, target 30%), 940 professional staff — see [[Datasets/University Headcount & Emiratisation|University Headcount & Emiratisation]].

## Colleges
- [[Colleges/College of Engineering|College of Engineering]] — dean [[People/Dr. Khalid Al Mazrouei-Hashimi|Dr. Khalid Al Mazrouei-Hashimi]], 128 faculty, 2,140 students
- [[Colleges/College of Information Technology|College of Information Technology]] — dean [[People/Dr. Fatima Al Ketbi-Rashdan|Dr. Fatima Al Ketbi-Rashdan]], 96 faculty, 1,690 students
- [[Colleges/College of Business Administration|College of Business Administration]] — dean [[People/Dr. Hessa Al Nuaimi-Zaabi|Dr. Hessa Al Nuaimi-Zaabi]], 104 faculty, 2,010 students
- [[Colleges/College of Health Sciences|College of Health Sciences]] — dean [[People/Prof. Marwan Al Shamsi-Darmaki|Prof. Marwan Al Shamsi-Darmaki]], 88 faculty, 1,260 students
- [[Colleges/College of Humanities & Social Sciences|College of Humanities & Social Sciences]] — dean [[People/Dr. Noura Al Dhaheri-Kaabi|Dr. Noura Al Dhaheri-Kaabi]], 112 faculty, 1,580 students
- [[Colleges/College of Education|College of Education]] — dean [[People/Dr. Salem Al Marri-Qubaisi|Dr. Salem Al Marri-Qubaisi]], 84 faculty, 1,132 students

## Leadership
- Vice Chancellor [[People/Prof. Abdulla Al Rumaithi-Ghurair|Prof. Abdulla Al Rumaithi-Ghurair]] · Provost [[People/Prof. Maitha Al Hosani-Falahi|Prof. Maitha Al Hosani-Falahi]] · CIO [[People/Dr. Sultan Al Mansouri-Kalbani|Dr. Sultan Al Mansouri-Kalbani]] · Programme Director [[People/Dr. Laila Al Zaabi-Marzooqi|Dr. Laila Al Zaabi-Marzooqi]] · DPO [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]] · Accreditation [[People/Dr. Noor Al Ameri-Hamli|Dr. Noor Al Ameri-Hamli]]

## The programme
[[Workstreams/NFU AI Adoption Programme 2025–27|NFU AI Adoption Programme 2025–27]] — six workstreams, chartered [[Meetings/2025-09-03 AI Steering Committee — Inaugural|2025-09-03 AI Steering Committee — Inaugural]], reviewed at [[Meetings/2026-08-26 AI Steering Committee — Year-1 Review|2026-08-26 AI Steering Committee — Year-1 Review]].

## Regulatory anchors
[[Regulatory Context/CAA Standards 2019|CAA Standards 2019]] · [[Regulatory Context/QFEmirates|QFEmirates]] · [[Regulatory Context/UAE PDPL (Federal Decree-Law 45 of 2021)|UAE PDPL (Federal Decree-Law 45 of 2021)]] · [[Regulatory Context/UAE National AI Strategy 2031|UAE National AI Strategy 2031]] · [[Regulatory Context/UAE AI Charter 2024|UAE AI Charter 2024]] · [[Regulatory Context/MoHESR and CAA Oversight|MoHESR and CAA Oversight]] · [[Regulatory Context/Emiratisation in Higher Education|Emiratisation in Higher Education]]
