---
synthetic: true
tags: [meta]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Tag Index

| Tag family | Values | Use |
|---|---|---|
| `type/*` | university, college, programme, course, person, workstream, pilot, cohort, policy, meeting, decision, incident, risk, dataset, kpi, concept, regulatory, accreditation, vendor, term | one per note, matches folder |
| `ws/*` | upskilling, assessment, tutor, research-data, automation, governance | workstream membership (WS1–WS6) |
| `status/*` | active, closed, proposed | decisions |
| `role/*` | leadership, dean, champion, external | people |
| `qfe/level-n` | 7, 9 | programmes ([[Regulatory Context/QFEmirates|QFEmirates]]) |
| `risk` | — | incidents and risks |
| `evidence` | — | datasets |
| `real-world` | — | regulatory notes and [[Regulatory Sources]] |
| `moc` | — | hubs: [[Home]], [[Graph Reading Guide]], [[Timeline]], [[Datasets/Programme KPI Scorecard|Programme KPI Scorecard]], [[Workstreams/NFU AI Adoption Programme 2025–27|programme hub]] |
