---
synthetic: true
tags: [type/decision, ws/research-data, status/active]
date: 2026-02-11
owner: '[[People/Mr. Faisal Al Suwaidi-Bastaki]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# DEC-06 Require model cards and parity thresholds

**Made at:** [[Meetings/2026-02-11 Fairness Review — At-Risk Model|2026-02-11 Fairness Review — At-Risk Model]] · **Owner:** [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]] · **Workstream:** [[Workstreams/WS4 Research Data Governance|WS4 Research Data Governance]] · **Evidence:** [[Datasets/At-Risk Model Performance & Fairness|At-Risk Model Performance & Fairness]] · **Status:** active

Any predictive model touching students needs a [[Concepts/Model Card|Model Card]] and flag-rate parity within 2 percentage points across nationality and gender. Re-weighted model: 11.9% vs 11.3%.
