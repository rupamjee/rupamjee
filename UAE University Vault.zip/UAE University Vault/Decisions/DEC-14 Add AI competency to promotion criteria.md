---
synthetic: true
tags: [type/decision, ws/upskilling, status/proposed]
date: 2026-08-26
owner: '[[People/Prof. Maitha Al Hosani-Falahi]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# DEC-14 Add AI competency to promotion criteria

**Made at:** [[Meetings/2026-08-26 AI Steering Committee — Year-1 Review|2026-08-26 AI Steering Committee — Year-1 Review]] · **Owner:** [[People/Prof. Maitha Al Hosani-Falahi|Prof. Maitha Al Hosani-Falahi]] · **Workstream:** [[Workstreams/WS1 Faculty AI Upskilling|WS1 Faculty AI Upskilling]] · **Evidence:** [[Policies/POL-07 AI Competency in Faculty Promotion Criteria|POL-07 AI Competency in Faculty Promotion Criteria]] · **Status:** proposed

Badge or equivalent evidence required for promotion dossiers from AY2027–28. Proposed by [[People/Dr. Hessa Al Nuaimi-Zaabi|Dr. Hessa Al Nuaimi-Zaabi]] at [[Meetings/2026-03-11 Deans Council — AI Progress|2026-03-11 Deans Council — AI Progress]].
