---
synthetic: true
tags: [type/decision, ws/upskilling, status/closed]
date: 2025-09-17
owner: '[[People/Dr. Hamad Al Shorafa-Neyadi]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# DEC-02 Adopt five-module faculty AI curriculum

**Made at:** [[Meetings/2025-09-17 WS1 Curriculum Design Sprint|2025-09-17 WS1 Curriculum Design Sprint]] · **Owner:** [[People/Dr. Hamad Al Shorafa-Neyadi|Dr. Hamad Al Shorafa-Neyadi]] · **Workstream:** [[Workstreams/WS1 Faculty AI Upskilling|WS1 Faculty AI Upskilling]] · **Evidence:** [[Datasets/Faculty AI Readiness Survey 2025|Faculty AI Readiness Survey 2025]] · **Status:** closed

Curriculum authored by [[People/Dr. Sara Al Marzooqi-Kindi|Dr. Sara Al Marzooqi-Kindi]] with champions; badge at 28/40. Justified by [[Datasets/Faculty AI Readiness Survey 2025|Faculty AI Readiness Survey 2025]]: only 34% used GenAI weekly and 19% knew any policy.
