---
synthetic: true
tags: [type/decision, ws/governance, status/active]
date: 2026-07-08
owner: '[[People/Dr. Sultan Al Mansouri-Kalbani]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# DEC-11 Cap infrastructure spend and reprioritise WS4

**Made at:** [[Meetings/2026-07-08 Budget Mid-year Review|2026-07-08 Budget Mid-year Review]] · **Owner:** [[People/Dr. Sultan Al Mansouri-Kalbani|Dr. Sultan Al Mansouri-Kalbani]] · **Workstream:** [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] · **Evidence:** [[Datasets/Programme Budget FY2025-26|Programme Budget FY2025-26]] · **Status:** active

Infrastructure line capped at AED 1.60 M; unspent WS4 funds moved to research-tool licences on [[Vendors/Qamar Cloud|Qamar Cloud]].
