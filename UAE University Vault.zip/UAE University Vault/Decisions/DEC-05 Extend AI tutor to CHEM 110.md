---
synthetic: true
tags: [type/decision, ws/tutor, status/active]
date: 2026-01-28
owner: '[[People/Dr. Sara Al Marzooqi-Kindi]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# DEC-05 Extend AI tutor to CHEM 110

**Made at:** [[Meetings/2026-01-28 Tutor Pilot Results Review|2026-01-28 Tutor Pilot Results Review]] · **Owner:** [[People/Dr. Sara Al Marzooqi-Kindi|Dr. Sara Al Marzooqi-Kindi]] · **Workstream:** [[Workstreams/WS3 Student AI Tutor Pilot|WS3 Student AI Tutor Pilot]] · **Evidence:** [[Datasets/MATH 101 Tutor Pilot Outcomes|MATH 101 Tutor Pilot Outcomes]] · **Status:** active

Wave 2 in Spring 2026 with student-level randomisation where timetable allows. See [[Pilots/PIL-02 AI Tutor in CHEM 110|PIL-02 AI Tutor in CHEM 110]].
