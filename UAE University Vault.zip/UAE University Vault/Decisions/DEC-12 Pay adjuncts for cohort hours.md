---
synthetic: true
tags: [type/decision, ws/upskilling, status/active]
date: 2026-08-12
owner: '[[People/Mr. Rashed Al Dhanhani-Tunaiji]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# DEC-12 Pay adjuncts for cohort hours

**Made at:** [[Meetings/2026-08-12 Cohort 5 Retrospective|2026-08-12 Cohort 5 Retrospective]] · **Owner:** [[People/Mr. Rashed Al Dhanhani-Tunaiji|Mr. Rashed Al Dhanhani-Tunaiji]] · **Workstream:** [[Workstreams/WS1 Faculty AI Upskilling|WS1 Faculty AI Upskilling]] · **Evidence:** [[Datasets/WS1 Cohort Completion & Readiness|WS1 Cohort Completion & Readiness]] · **Status:** active

20 paid hours per adjunct participant from Cohort 6 onward. Expected to lift completion above the 85.5% programme average.
