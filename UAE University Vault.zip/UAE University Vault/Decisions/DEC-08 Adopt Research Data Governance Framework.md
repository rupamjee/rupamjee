---
synthetic: true
tags: [type/decision, ws/research-data, status/active]
date: 2026-05-13
owner: '[[People/Dr. Ibrahim Al Nuaimi-Dhanhani]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# DEC-08 Adopt Research Data Governance Framework

**Made at:** [[Meetings/2026-05-13 AI Steering Committee — Q3|2026-05-13 AI Steering Committee — Q3]] · **Owner:** [[People/Dr. Ibrahim Al Nuaimi-Dhanhani|Dr. Ibrahim Al Nuaimi-Dhanhani]] · **Workstream:** [[Workstreams/WS4 Research Data Governance|WS4 Research Data Governance]] · **Evidence:** [[Policies/POL-03 Research Data Governance Framework|POL-03 Research Data Governance Framework]] · **Status:** active

Five data tiers; tiers 3–5 only in approved tools on [[Vendors/Qamar Cloud|Qamar Cloud]]. Addresses [[Risks/RSK-07 Shadow AI use in research groups|RSK-07 Shadow AI use in research groups]].
