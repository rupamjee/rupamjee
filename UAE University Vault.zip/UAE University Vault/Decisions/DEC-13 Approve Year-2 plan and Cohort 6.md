---
synthetic: true
tags: [type/decision, ws/governance, status/active]
date: 2026-08-26
owner: '[[People/Dr. Laila Al Zaabi-Marzooqi]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# DEC-13 Approve Year-2 plan and Cohort 6

**Made at:** [[Meetings/2026-08-26 AI Steering Committee — Year-1 Review|2026-08-26 AI Steering Committee — Year-1 Review]] · **Owner:** [[People/Dr. Laila Al Zaabi-Marzooqi|Dr. Laila Al Zaabi-Marzooqi]] · **Workstream:** [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] · **Evidence:** [[Datasets/Programme KPI Scorecard|Programme KPI Scorecard]] · **Status:** active

Cohort 6 (55 enrolled) opens [[Terms/Fall 2026|Fall 2026]]; target 40% faculty AI-literate by Dec 2026 ([[KPIs/KPI-01 Faculty AI-literate share|KPI-01 Faculty AI-literate share]]).
