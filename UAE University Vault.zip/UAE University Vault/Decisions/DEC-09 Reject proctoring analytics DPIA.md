---
synthetic: true
tags: [type/decision, ws/governance, status/closed]
date: 2026-05-13
owner: '[[People/Mr. Faisal Al Suwaidi-Bastaki]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# DEC-09 Reject proctoring analytics DPIA

**Made at:** [[Meetings/2026-05-13 AI Steering Committee — Q3|2026-05-13 AI Steering Committee — Q3]] · **Owner:** [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]] · **Workstream:** [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] · **Evidence:** [[Datasets/DPIA Register|DPIA Register]] · **Status:** closed

Biometric processing judged disproportionate; assessment redesign ([[Concepts/Authentic Assessment|Authentic Assessment]]) preferred over surveillance.
