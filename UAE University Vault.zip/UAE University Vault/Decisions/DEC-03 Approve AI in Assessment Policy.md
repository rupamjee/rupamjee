---
synthetic: true
tags: [type/decision, ws/assessment, status/active]
date: 2026-01-14
owner: '[[People/Ms. Salama Al Kaabi-Shamsi]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# DEC-03 Approve AI in Assessment Policy

**Made at:** [[Meetings/2026-01-14 AI Steering Committee — Q2|2026-01-14 AI Steering Committee — Q2]] · **Owner:** [[People/Ms. Salama Al Kaabi-Shamsi|Ms. Salama Al Kaabi-Shamsi]] · **Workstream:** [[Workstreams/WS2 Assessment & Academic Integrity|WS2 Assessment & Academic Integrity]] · **Evidence:** [[Datasets/Academic Integrity Cases by Term|Academic Integrity Cases by Term]] · **Status:** active

Three tiers of permitted AI use per assessment; disclosure statement mandatory. Result tracked in [[KPIs/KPI-04 AI-related integrity cases|KPI-04 AI-related integrity cases]].
