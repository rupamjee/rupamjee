---
synthetic: true
tags: [type/decision, ws/governance, status/active]
date: 2026-01-14
owner: '[[People/Mr. Faisal Al Suwaidi-Bastaki]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# DEC-04 Approve Acceptable Use of Generative AI

**Made at:** [[Meetings/2026-01-14 AI Steering Committee — Q2|2026-01-14 AI Steering Committee — Q2]] · **Owner:** [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]] · **Workstream:** [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] · **Evidence:** [[Regulatory Context/UAE AI Charter 2024|UAE AI Charter 2024]] · **Status:** active

Applies to staff and students; forbids entering personal data of others into non-approved tools ([[Concepts/Data Minimisation|Data Minimisation]], [[Regulatory Context/UAE PDPL (Federal Decree-Law 45 of 2021)|UAE PDPL (Federal Decree-Law 45 of 2021)]]).
