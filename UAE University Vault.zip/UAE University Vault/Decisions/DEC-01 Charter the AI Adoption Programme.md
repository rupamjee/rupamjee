---
synthetic: true
tags: [type/decision, ws/governance, status/closed]
date: 2025-09-03
owner: '[[People/Prof. Maitha Al Hosani-Falahi]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# DEC-01 Charter the AI Adoption Programme

**Made at:** [[Meetings/2025-09-03 AI Steering Committee — Inaugural|2025-09-03 AI Steering Committee — Inaugural]] · **Owner:** [[People/Prof. Maitha Al Hosani-Falahi|Prof. Maitha Al Hosani-Falahi]] · **Workstream:** [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] · **Evidence:** [[Datasets/Programme Budget FY2025-26|Programme Budget FY2025-26]] · **Status:** closed

Six workstreams, AED 4.85 M, PMO under [[People/Dr. Laila Al Zaabi-Marzooqi|Dr. Laila Al Zaabi-Marzooqi]]. Reports to the AI Steering Committee quarterly.
