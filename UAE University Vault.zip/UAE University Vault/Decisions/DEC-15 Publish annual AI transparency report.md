---
synthetic: true
tags: [type/decision, ws/governance, status/proposed]
date: 2026-08-26
owner: '[[People/Mr. Faisal Al Suwaidi-Bastaki]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# DEC-15 Publish annual AI transparency report

**Made at:** [[Meetings/2026-08-26 AI Steering Committee — Year-1 Review|2026-08-26 AI Steering Committee — Year-1 Review]] · **Owner:** [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]] · **Workstream:** [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] · **Evidence:** [[Regulatory Context/UAE AI Charter 2024|UAE AI Charter 2024]] · **Status:** proposed

Public list of AI systems in use, DPIA status and incidents — responds to the Student Council request at [[Meetings/2026-03-25 Student Council AI Forum|2026-03-25 Student Council AI Forum]].
