---
synthetic: true
tags: [type/decision, ws/automation, status/closed]
date: 2026-02-25
owner: '[[People/Dr. Sultan Al Mansouri-Kalbani]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# DEC-07 Pause Tarhal contract pending remediation

**Made at:** [[Meetings/2026-02-25 Registrar Bot Incident Post-mortem|2026-02-25 Registrar Bot Incident Post-mortem]] · **Owner:** [[People/Dr. Sultan Al Mansouri-Kalbani|Dr. Sultan Al Mansouri-Kalbani]] · **Workstream:** [[Workstreams/WS5 Administrative Automation|WS5 Administrative Automation]] · **Evidence:** [[Incidents/INC-04 Prompt injection attempt on registrar chatbot|INC-04 Prompt injection attempt on registrar chatbot]] · **Status:** closed

Record-lookup intents disabled; FAQ intents kept live. Superseded by [[Decisions/DEC-10 Resume Tarhal with human-in-the-loop for record lookups|DEC-10 Resume Tarhal with human-in-the-loop for record lookups]].
