---
synthetic: true
tags: [type/decision, ws/automation, status/active]
date: 2026-06-03
owner: '[[People/Ms. Aisha Al Otaiba-Mazrui]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# DEC-10 Resume Tarhal with human-in-the-loop for record lookups

**Made at:** [[Meetings/2026-06-03 WS5 Automation Roadmap|2026-06-03 WS5 Automation Roadmap]] · **Owner:** [[People/Ms. Aisha Al Otaiba-Mazrui|Ms. Aisha Al Otaiba-Mazrui]] · **Workstream:** [[Workstreams/WS5 Administrative Automation|WS5 Administrative Automation]] · **Evidence:** [[Datasets/Registrar Chatbot Analytics Spring 2026|Registrar Chatbot Analytics Spring 2026]] · **Status:** active

Record lookups route to a registrar officer for approval ([[Concepts/Human-in-the-Loop|Human-in-the-Loop]]); FAQ deflection continues at 62%.
