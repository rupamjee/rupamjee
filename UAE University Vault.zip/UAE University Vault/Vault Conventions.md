---
synthetic: true
tags: [meta]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Vault Conventions

- **One folder per note type.** Filenames = entity names. Meetings start with an ISO date; decisions `DEC-nn`, incidents `INC-nn`, risks `RSK-nn`, policies `POL-nn`, pilots `PIL-nn`, KPIs `KPI-nn`.
- **Numbers live in Datasets.** Any figure elsewhere is a citation with a link back. The generator computes totals from the row data, so tables reconcile (e.g. 235 enrolled → 201 completed = 85.5%).
- **Decisions are two-hop traceable.** Each names the meeting that made it and the evidence (dataset, incident or policy) that justified it.
- **People notes are backlink summaries.** Their "Appears in" sections are generated from the rest of the vault; edit the source notes, not the person note.
- **Real vs fictional.** `synthetic: true` on every note. `Regulatory Context/` notes additionally carry `real-world` and a callout naming the real framework.
- **Frontmatter properties** (`date`, `owner`, `status`, `severity`, `qfemirates_level`, `enrolled`) are consistent so Dataview/Bases queries work, e.g. `TABLE date, owner FROM "Decisions" WHERE status = "active"`.
