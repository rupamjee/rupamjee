---
synthetic: true
tags: [meta, real-world]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Regulatory Sources

The only non-fictional layer of this vault. Each note in `Regulatory Context/` describes a real UAE framework and carries the URLs it was checked against on 2026-09-05. Standard numbers, article numbers and targets are **not** reproduced from memory here — verify against the primary document before quoting in a deliverable.

- [[Regulatory Context/CAA Standards 2019|CAA Standards 2019]]
- [[Regulatory Context/QFEmirates|QFEmirates]]
- [[Regulatory Context/UAE PDPL (Federal Decree-Law 45 of 2021)|UAE PDPL (Federal Decree-Law 45 of 2021)]]
- [[Regulatory Context/UAE National AI Strategy 2031|UAE National AI Strategy 2031]]
- [[Regulatory Context/UAE AI Charter 2024|UAE AI Charter 2024]]
- [[Regulatory Context/Emiratisation in Higher Education|Emiratisation in Higher Education]]
- [[Regulatory Context/MoHESR and CAA Oversight|MoHESR and CAA Oversight]]

Rule used throughout the vault: real frameworks are named and linked; every figure attached to them (e.g. NFU's Emirati faculty share) is fictional and lives in a `Datasets/` note.
