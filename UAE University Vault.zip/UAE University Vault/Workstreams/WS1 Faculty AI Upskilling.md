---
synthetic: true
tags: [type/workstream, ws/upskilling]
lead: '[[People/Dr. Hamad Al Shorafa-Neyadi]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# WS1 Faculty AI Upskilling

Part of [[Workstreams/NFU AI Adoption Programme 2025–27|NFU AI Adoption Programme 2025–27]]. Lead: [[People/Dr. Hamad Al Shorafa-Neyadi|Dr. Hamad Al Shorafa-Neyadi]]. Objective: Six faculty cohorts to certified AI-literate status; 40% of faculty by Dec 2026.

## Cohorts
- [[Cohorts/Cohort 1 — Engineering & IT|Cohort 1 — Engineering & IT]] — [[Terms/Fall 2025|Fall 2025]], CEN + CIT faculty: 48 enrolled, 41 completed, readiness 3.1 → 4.2, 39 badges
- [[Cohorts/Cohort 2 — Business & Humanities|Cohort 2 — Business & Humanities]] — [[Terms/Fall 2025|Fall 2025]], CBA + CHSS faculty: 52 enrolled, 44 completed, readiness 2.8 → 4.0, 41 badges
- [[Cohorts/Cohort 3 — Health & Education|Cohort 3 — Health & Education]] — [[Terms/Spring 2026|Spring 2026]], CHS + CED faculty: 45 enrolled, 40 completed, readiness 2.9 → 4.1, 38 badges
- [[Cohorts/Cohort 4 — Deans & Chairs|Cohort 4 — Deans & Chairs]] — [[Terms/Spring 2026|Spring 2026]], Academic leadership: 30 enrolled, 29 completed, readiness 3.4 → 4.5, 29 badges
- [[Cohorts/Cohort 5 — Adjunct Faculty|Cohort 5 — Adjunct Faculty]] — [[Terms/Summer 2026|Summer 2026]], Adjuncts, all colleges: 60 enrolled, 47 completed, readiness 2.6 → 3.9, 44 badges
- [[Cohorts/Cohort 6 — Open Enrolment|Cohort 6 — Open Enrolment]] — [[Terms/Fall 2026|Fall 2026]], All colleges (in progress): 55 enrolled, in progress

Totals (completed cohorts): 235 enrolled, 201 completed (85.5%), 191 badges; weighted readiness 2.92 → 4.11 on a 1–5 scale. Source [[Datasets/WS1 Cohort Completion & Readiness|WS1 Cohort Completion & Readiness]]. Baseline [[Datasets/Faculty AI Readiness Survey 2025|Faculty AI Readiness Survey 2025]].

Curriculum: [[Decisions/DEC-02 Adopt five-module faculty AI curriculum|DEC-02 Adopt five-module faculty AI curriculum]] · Champions: one per programme — see [[Programmes/BSc Mechanical Engineering|BSc Mechanical Engineering]] and siblings. Meetings: [[Meetings/2025-09-17 WS1 Curriculum Design Sprint|2025-09-17 WS1 Curriculum Design Sprint]], [[Meetings/2026-03-11 Deans Council — AI Progress|2026-03-11 Deans Council — AI Progress]], [[Meetings/2026-08-12 Cohort 5 Retrospective|2026-08-12 Cohort 5 Retrospective]]. KPIs: [[KPIs/KPI-01 Faculty AI-literate share|KPI-01 Faculty AI-literate share]], [[KPIs/KPI-02 Cohort completion rate|KPI-02 Cohort completion rate]]. Risk: [[Risks/RSK-03 Faculty resistance and workload|RSK-03 Faculty resistance and workload]].
