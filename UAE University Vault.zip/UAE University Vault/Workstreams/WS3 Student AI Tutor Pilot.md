---
synthetic: true
tags: [type/workstream, ws/tutor]
lead: '[[People/Dr. Sara Al Marzooqi-Kindi]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# WS3 Student AI Tutor Pilot

Part of [[Workstreams/NFU AI Adoption Programme 2025–27|NFU AI Adoption Programme 2025–27]]. Lead: [[People/Dr. Sara Al Marzooqi-Kindi|Dr. Sara Al Marzooqi-Kindi]]. Objective: Controlled pilot of an AI tutor in high-DFW gateway courses.

## Pilots
- [[Pilots/PIL-01 AI Tutor in MATH 101|PIL-01 AI Tutor in MATH 101]] — [[Datasets/MATH 101 Tutor Pilot Outcomes|MATH 101 Tutor Pilot Outcomes]]: pass 71.5% vs 63.9%
- [[Pilots/PIL-02 AI Tutor in CHEM 110|PIL-02 AI Tutor in CHEM 110]] — [[Datasets/CHEM 110 Tutor Pilot Wave 2|CHEM 110 Tutor Pilot Wave 2]]: pass 68.2% vs 62.4%
Vendor [[Vendors/Falaj Learning Systems|Falaj Learning Systems]]; DPIA approved [[Meetings/2025-10-01 DPIA Review — AI Tutor|2025-10-01 DPIA Review — AI Tutor]]. Student voice: [[Datasets/Student AI Tutor Survey|Student AI Tutor Survey]], [[Meetings/2026-03-25 Student Council AI Forum|2026-03-25 Student Council AI Forum]]. Incident: [[Incidents/INC-02 Tutor hallucinated a theorem statement|INC-02 Tutor hallucinated a theorem statement]]. Risk: [[Risks/RSK-01 Student over-reliance on AI tutor|RSK-01 Student over-reliance on AI tutor]]. KPI: [[KPIs/KPI-03 Gateway-course DFW rate|KPI-03 Gateway-course DFW rate]]. Concepts: [[Concepts/Retrieval-Augmented Generation|Retrieval-Augmented Generation]], [[Concepts/Hallucination|Hallucination]], [[Concepts/Learning Analytics|Learning Analytics]].
