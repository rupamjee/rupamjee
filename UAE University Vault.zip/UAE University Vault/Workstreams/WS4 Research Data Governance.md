---
synthetic: true
tags: [type/workstream, ws/research-data]
lead: '[[People/Dr. Ibrahim Al Nuaimi-Dhanhani]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# WS4 Research Data Governance

Part of [[Workstreams/NFU AI Adoption Programme 2025–27|NFU AI Adoption Programme 2025–27]]. Lead: [[People/Dr. Ibrahim Al Nuaimi-Dhanhani|Dr. Ibrahim Al Nuaimi-Dhanhani]]. Objective: DPIA, data classification and model-use rules for research groups.

## Scope
[[Policies/POL-03 Research Data Governance Framework|POL-03 Research Data Governance Framework]] (five data tiers) adopted by [[Decisions/DEC-08 Adopt Research Data Governance Framework|DEC-08 Adopt Research Data Governance Framework]]. DPIA practice: [[Datasets/DPIA Register|DPIA Register]], [[Concepts/Data Protection Impact Assessment|Data Protection Impact Assessment]]. Model governance: [[Pilots/PIL-05 Predictive At-Risk Model|PIL-05 Predictive At-Risk Model]], [[Incidents/INC-03 At-risk model flag-rate disparity|INC-03 At-risk model flag-rate disparity]], [[Decisions/DEC-06 Require model cards and parity thresholds|DEC-06 Require model cards and parity thresholds]]. Shadow AI: [[Incidents/INC-05 Research data uploaded to personal AI account|INC-05 Research data uploaded to personal AI account]], [[Risks/RSK-07 Shadow AI use in research groups|RSK-07 Shadow AI use in research groups]]. Meetings: [[Meetings/2025-10-01 DPIA Review — AI Tutor|2025-10-01 DPIA Review — AI Tutor]], [[Meetings/2026-02-11 Fairness Review — At-Risk Model|2026-02-11 Fairness Review — At-Risk Model]], [[Meetings/2026-04-08 WS4 Research Data Governance Workshop|2026-04-08 WS4 Research Data Governance Workshop]]. KPIs: [[KPIs/KPI-05 At-risk flag-rate parity|KPI-05 At-risk flag-rate parity]], [[KPIs/KPI-07 DPIA coverage of AI systems|KPI-07 DPIA coverage of AI systems]].
