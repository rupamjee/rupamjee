---
synthetic: true
tags: [type/programme, moc]
start: 2025-09-03
end: 2027-08-31
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# NFU AI Adoption Programme 2025–27

University-wide AI adoption programme of [[University/Nujoom Federal University|Nujoom Federal University]]. Chartered by [[Decisions/DEC-01 Charter the AI Adoption Programme|DEC-01 Charter the AI Adoption Programme]] at [[Meetings/2025-09-03 AI Steering Committee — Inaugural|2025-09-03 AI Steering Committee — Inaugural]]; budget AED 4.85 M ([[Datasets/Programme Budget FY2025-26|Programme Budget FY2025-26]]); PMO led by [[People/Dr. Laila Al Zaabi-Marzooqi|Dr. Laila Al Zaabi-Marzooqi]] with [[People/Ms. Priyanka Raman-Iyer|Ms. Priyanka Raman-Iyer]].

| Workstream | Lead | Objective |
|---|---|---|
| [[Workstreams/WS1 Faculty AI Upskilling|WS1 Faculty AI Upskilling]] | [[People/Dr. Hamad Al Shorafa-Neyadi|Dr. Hamad Al Shorafa-Neyadi]] | Six faculty cohorts to certified AI-literate status; 40% of faculty by Dec 2026. |
| [[Workstreams/WS2 Assessment & Academic Integrity|WS2 Assessment & Academic Integrity]] | [[People/Ms. Salama Al Kaabi-Shamsi|Ms. Salama Al Kaabi-Shamsi]] | Redesign assessment for a GenAI world; replace detection-first with design-first. |
| [[Workstreams/WS3 Student AI Tutor Pilot|WS3 Student AI Tutor Pilot]] | [[People/Dr. Sara Al Marzooqi-Kindi|Dr. Sara Al Marzooqi-Kindi]] | Controlled pilot of an AI tutor in high-DFW gateway courses. |
| [[Workstreams/WS4 Research Data Governance|WS4 Research Data Governance]] | [[People/Dr. Ibrahim Al Nuaimi-Dhanhani|Dr. Ibrahim Al Nuaimi-Dhanhani]] | DPIA, data classification and model-use rules for research groups. |
| [[Workstreams/WS5 Administrative Automation|WS5 Administrative Automation]] | [[People/Ms. Aisha Al Otaiba-Mazrui|Ms. Aisha Al Otaiba-Mazrui]] | Registrar chatbot and admissions document triage. |
| [[Workstreams/WS6 AI Governance & Policy|WS6 AI Governance & Policy]] | [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]] | Policy suite, AI Steering Committee, alignment to PDPL and UAE AI Charter. |

## Year-1 headline results ([[Datasets/Programme KPI Scorecard|Programme KPI Scorecard]])
- Faculty AI-literate: 201 of 612 = **32.8%** (target 40%) — [[KPIs/KPI-01 Faculty AI-literate share|KPI-01 Faculty AI-literate share]]
- MATH 101 DFW: 36.1% control → 28.5% treatment — [[KPIs/KPI-03 Gateway-course DFW rate|KPI-03 Gateway-course DFW rate]]
- Integrity cases: 141 ([[Terms/Fall 2025|Fall 2025]]) → 87 ([[Terms/Spring 2026|Spring 2026]]) — [[KPIs/KPI-04 AI-related integrity cases|KPI-04 AI-related integrity cases]]
- DPIAs: 6 approved, 2 pending, 1 rejected of 9 — [[KPIs/KPI-07 DPIA coverage of AI systems|KPI-07 DPIA coverage of AI systems]]

## Governance
AI Steering Committee meets quarterly: [[Meetings/2025-09-03 AI Steering Committee — Inaugural|2025-09-03 AI Steering Committee — Inaugural]] → [[Meetings/2026-01-14 AI Steering Committee — Q2|2026-01-14 AI Steering Committee — Q2]] → [[Meetings/2026-05-13 AI Steering Committee — Q3|2026-05-13 AI Steering Committee — Q3]] → [[Meetings/2026-08-26 AI Steering Committee — Year-1 Review|2026-08-26 AI Steering Committee — Year-1 Review]]. External advisor: [[People/Dr. Jonathan Mbeki-Hartley|Dr. Jonathan Mbeki-Hartley]]. Accreditation link: [[Accreditation/CAA Licensure Renewal 2027|CAA Licensure Renewal 2027]].
