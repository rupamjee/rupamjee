---
synthetic: true
tags: [type/workstream, ws/automation]
lead: '[[People/Ms. Aisha Al Otaiba-Mazrui]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# WS5 Administrative Automation

Part of [[Workstreams/NFU AI Adoption Programme 2025–27|NFU AI Adoption Programme 2025–27]]. Lead: [[People/Ms. Aisha Al Otaiba-Mazrui|Ms. Aisha Al Otaiba-Mazrui]]. Objective: Registrar chatbot and admissions document triage.

## Systems
- [[Pilots/PIL-03 Registrar Service Chatbot|PIL-03 Registrar Service Chatbot]] ([[Vendors/Tarhal AI|Tarhal AI]]) — [[Datasets/Registrar Chatbot Analytics Spring 2026|Registrar Chatbot Analytics Spring 2026]]: 38,400 queries, 62% deflection, CSAT 4.1
- Admissions document triage — DPIA pending ([[Datasets/DPIA Register|DPIA Register]])
Incident: [[Incidents/INC-04 Prompt injection attempt on registrar chatbot|INC-04 Prompt injection attempt on registrar chatbot]] → [[Decisions/DEC-07 Pause Tarhal contract pending remediation|DEC-07 Pause Tarhal contract pending remediation]] → [[Decisions/DEC-10 Resume Tarhal with human-in-the-loop for record lookups|DEC-10 Resume Tarhal with human-in-the-loop for record lookups]]. Meetings: [[Meetings/2026-02-25 Registrar Bot Incident Post-mortem|2026-02-25 Registrar Bot Incident Post-mortem]], [[Meetings/2026-06-03 WS5 Automation Roadmap|2026-06-03 WS5 Automation Roadmap]]. KPI: [[KPIs/KPI-06 Registrar query deflection|KPI-06 Registrar query deflection]]. Risk: [[Risks/RSK-05 Prompt injection via public channels|RSK-05 Prompt injection via public channels]].
