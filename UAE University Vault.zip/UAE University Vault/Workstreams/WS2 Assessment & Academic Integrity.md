---
synthetic: true
tags: [type/workstream, ws/assessment]
lead: '[[People/Ms. Salama Al Kaabi-Shamsi]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# WS2 Assessment & Academic Integrity

Part of [[Workstreams/NFU AI Adoption Programme 2025–27|NFU AI Adoption Programme 2025–27]]. Lead: [[People/Ms. Salama Al Kaabi-Shamsi|Ms. Salama Al Kaabi-Shamsi]]. Objective: Redesign assessment for a GenAI world; replace detection-first with design-first.

## Evidence
[[Datasets/Academic Integrity Cases by Term|Academic Integrity Cases by Term]] — cases by term: Fall 2024 62 (21% AI) → Spring 2025 118 (48% AI) → Fall 2025 141 (61% AI) → Spring 2026 87 (44% AI).

## Response
[[Policies/POL-01 AI in Assessment Policy|POL-01 AI in Assessment Policy]] (three tiers, disclosure statement) via [[Decisions/DEC-03 Approve AI in Assessment Policy|DEC-03 Approve AI in Assessment Policy]]; [[Policies/POL-06 Academic Integrity Policy (rev. 2026)|POL-06 Academic Integrity Policy (rev. 2026)]]; course redesign tracked in [[Datasets/Course Redesign Tracker|Course Redesign Tracker]]. Concepts: [[Concepts/Authentic Assessment|Authentic Assessment]], [[Concepts/Constructive Alignment|Constructive Alignment]], [[Concepts/Academic Integrity in the GenAI Era|Academic Integrity in the GenAI Era]]. Incidents: [[Incidents/INC-01 Fall 2025 integrity case surge|INC-01 Fall 2025 integrity case surge]], [[Incidents/INC-06 Grading assistant feedback leaked rubric weights|INC-06 Grading assistant feedback leaked rubric weights]]. KPI: [[KPIs/KPI-04 AI-related integrity cases|KPI-04 AI-related integrity cases]]. Proctoring analytics rejected: [[Decisions/DEC-09 Reject proctoring analytics DPIA|DEC-09 Reject proctoring analytics DPIA]].
