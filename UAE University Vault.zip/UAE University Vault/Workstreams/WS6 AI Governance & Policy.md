---
synthetic: true
tags: [type/workstream, ws/governance]
lead: '[[People/Mr. Faisal Al Suwaidi-Bastaki]]'
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# WS6 AI Governance & Policy

Part of [[Workstreams/NFU AI Adoption Programme 2025–27|NFU AI Adoption Programme 2025–27]]. Lead: [[People/Mr. Faisal Al Suwaidi-Bastaki|Mr. Faisal Al Suwaidi-Bastaki]]. Objective: Policy suite, AI Steering Committee, alignment to PDPL and UAE AI Charter.

## Policy suite
- [[Policies/POL-01 AI in Assessment Policy|POL-01 AI in Assessment Policy]]
- [[Policies/POL-02 Acceptable Use of Generative AI|POL-02 Acceptable Use of Generative AI]]
- [[Policies/POL-03 Research Data Governance Framework|POL-03 Research Data Governance Framework]]
- [[Policies/POL-04 Student Data Protection Standard|POL-04 Student Data Protection Standard]]
- [[Policies/POL-05 AI Tool Procurement Standard|POL-05 AI Tool Procurement Standard]]
- [[Policies/POL-06 Academic Integrity Policy (rev. 2026)|POL-06 Academic Integrity Policy (rev. 2026)]]
- [[Policies/POL-07 AI Competency in Faculty Promotion Criteria|POL-07 AI Competency in Faculty Promotion Criteria]]

Anchors: [[Regulatory Context/UAE AI Charter 2024|UAE AI Charter 2024]], [[Regulatory Context/UAE PDPL (Federal Decree-Law 45 of 2021)|UAE PDPL (Federal Decree-Law 45 of 2021)]], [[Regulatory Context/CAA Standards 2019|CAA Standards 2019]]. Steering Committee: [[Meetings/2025-09-03 AI Steering Committee — Inaugural|2025-09-03 AI Steering Committee — Inaugural]], [[Meetings/2026-01-14 AI Steering Committee — Q2|2026-01-14 AI Steering Committee — Q2]], [[Meetings/2026-05-13 AI Steering Committee — Q3|2026-05-13 AI Steering Committee — Q3]], [[Meetings/2026-08-26 AI Steering Committee — Year-1 Review|2026-08-26 AI Steering Committee — Year-1 Review]]. Accreditation: [[Accreditation/Standard Mapping — AI Policy Suite|Standard Mapping — AI Policy Suite]]. Budget: [[Datasets/Programme Budget FY2025-26|Programme Budget FY2025-26]], [[KPIs/KPI-10 Budget variance|KPI-10 Budget variance]]. Transparency: [[Decisions/DEC-15 Publish annual AI transparency report|DEC-15 Publish annual AI transparency report]]. Awareness KPI: [[KPIs/KPI-08 Policy awareness among faculty|KPI-08 Policy awareness among faculty]].
