---
synthetic: true
tags: [meta, moc]
---

> [!note] Synthetic scenario
> Nujoom Federal University, its people, figures and events are invented for demonstration. Notes in `Regulatory Context/` describe real UAE frameworks and carry their own sources; everything else is fiction.

# Timeline

Every dated item in the vault, oldest first.

| Date | Type | Item |
|---|---|---|
| 2025-08-25 | Term start | [[Terms/Fall 2025|Fall 2025]] |
| 2025-09-03 | Decision | [[Decisions/DEC-01 Charter the AI Adoption Programme|DEC-01 Charter the AI Adoption Programme]] |
| 2025-09-03 | Meeting | [[Meetings/2025-09-03 AI Steering Committee — Inaugural|2025-09-03 AI Steering Committee — Inaugural]] |
| 2025-09-17 | Decision | [[Decisions/DEC-02 Adopt five-module faculty AI curriculum|DEC-02 Adopt five-module faculty AI curriculum]] |
| 2025-09-17 | Meeting | [[Meetings/2025-09-17 WS1 Curriculum Design Sprint|2025-09-17 WS1 Curriculum Design Sprint]] |
| 2025-10-01 | Meeting | [[Meetings/2025-10-01 DPIA Review — AI Tutor|2025-10-01 DPIA Review — AI Tutor]] |
| 2025-10-02 | DPIA decision | AI tutor (Falaj) — Approved ([[Datasets/DPIA Register|DPIA Register]]) |
| 2025-10-22 | Meeting | [[Meetings/2025-10-22 WS2 Integrity Data Review|2025-10-22 WS2 Integrity Data Review]] |
| 2025-11-05 | Incident | [[Incidents/INC-02 Tutor hallucinated a theorem statement|INC-02 Tutor hallucinated a theorem statement]] |
| 2025-11-12 | Meeting | [[Meetings/2025-11-12 Tutor Pilot Mid-term Check|2025-11-12 Tutor Pilot Mid-term Check]] |
| 2025-11-20 | DPIA decision | Registrar chatbot (Tarhal) — Approved ([[Datasets/DPIA Register|DPIA Register]]) |
| 2025-12-04 | DPIA decision | Research literature assistant — Approved ([[Datasets/DPIA Register|DPIA Register]]) |
| 2025-12-10 | Meeting | [[Meetings/2025-12-10 WS6 Policy Drafting Workshop|2025-12-10 WS6 Policy Drafting Workshop]] |
| 2025-12-18 | Incident | [[Incidents/INC-01 Fall 2025 integrity case surge|INC-01 Fall 2025 integrity case surge]] |
| 2026-01-12 | Term start | [[Terms/Spring 2026|Spring 2026]] |
| 2026-01-14 | Decision | [[Decisions/DEC-03 Approve AI in Assessment Policy|DEC-03 Approve AI in Assessment Policy]] |
| 2026-01-14 | Decision | [[Decisions/DEC-04 Approve Acceptable Use of Generative AI|DEC-04 Approve Acceptable Use of Generative AI]] |
| 2026-01-14 | Meeting | [[Meetings/2026-01-14 AI Steering Committee — Q2|2026-01-14 AI Steering Committee — Q2]] |
| 2026-01-15 | DPIA decision | Grading assistant (BUS 205) — Approved ([[Datasets/DPIA Register|DPIA Register]]) |
| 2026-01-28 | Decision | [[Decisions/DEC-05 Extend AI tutor to CHEM 110|DEC-05 Extend AI tutor to CHEM 110]] |
| 2026-01-28 | Meeting | [[Meetings/2026-01-28 Tutor Pilot Results Review|2026-01-28 Tutor Pilot Results Review]] |
| 2026-02-11 | DPIA decision | At-risk model (Sidra) — Approved with conditions ([[Datasets/DPIA Register|DPIA Register]]) |
| 2026-02-11 | Decision | [[Decisions/DEC-06 Require model cards and parity thresholds|DEC-06 Require model cards and parity thresholds]] |
| 2026-02-11 | Incident | [[Incidents/INC-03 At-risk model flag-rate disparity|INC-03 At-risk model flag-rate disparity]] |
| 2026-02-11 | Meeting | [[Meetings/2026-02-11 Fairness Review — At-Risk Model|2026-02-11 Fairness Review — At-Risk Model]] |
| 2026-02-19 | Incident | [[Incidents/INC-04 Prompt injection attempt on registrar chatbot|INC-04 Prompt injection attempt on registrar chatbot]] |
| 2026-02-25 | Decision | [[Decisions/DEC-07 Pause Tarhal contract pending remediation|DEC-07 Pause Tarhal contract pending remediation]] |
| 2026-02-25 | Meeting | [[Meetings/2026-02-25 Registrar Bot Incident Post-mortem|2026-02-25 Registrar Bot Incident Post-mortem]] |
| 2026-03-09 | DPIA decision | Proctoring analytics — Rejected ([[Datasets/DPIA Register|DPIA Register]]) |
| 2026-03-11 | Meeting | [[Meetings/2026-03-11 Deans Council — AI Progress|2026-03-11 Deans Council — AI Progress]] |
| 2026-03-18 | Incident | [[Incidents/INC-06 Grading assistant feedback leaked rubric weights|INC-06 Grading assistant feedback leaked rubric weights]] |
| 2026-03-25 | Meeting | [[Meetings/2026-03-25 Student Council AI Forum|2026-03-25 Student Council AI Forum]] |
| 2026-04-02 | Incident | [[Incidents/INC-05 Research data uploaded to personal AI account|INC-05 Research data uploaded to personal AI account]] |
| 2026-04-08 | Meeting | [[Meetings/2026-04-08 WS4 Research Data Governance Workshop|2026-04-08 WS4 Research Data Governance Workshop]] |
| 2026-04-22 | DPIA decision | Library discovery chatbot — Approved ([[Datasets/DPIA Register|DPIA Register]]) |
| 2026-04-29 | Meeting | [[Meetings/2026-04-29 Accreditation Evidence Mapping|2026-04-29 Accreditation Evidence Mapping]] |
| 2026-05-13 | Decision | [[Decisions/DEC-08 Adopt Research Data Governance Framework|DEC-08 Adopt Research Data Governance Framework]] |
| 2026-05-13 | Decision | [[Decisions/DEC-09 Reject proctoring analytics DPIA|DEC-09 Reject proctoring analytics DPIA]] |
| 2026-05-13 | Meeting | [[Meetings/2026-05-13 AI Steering Committee — Q3|2026-05-13 AI Steering Committee — Q3]] |
| 2026-06-01 | Term start | [[Terms/Summer 2026|Summer 2026]] |
| 2026-06-03 | Decision | [[Decisions/DEC-10 Resume Tarhal with human-in-the-loop for record lookups|DEC-10 Resume Tarhal with human-in-the-loop for record lookups]] |
| 2026-06-03 | Meeting | [[Meetings/2026-06-03 WS5 Automation Roadmap|2026-06-03 WS5 Automation Roadmap]] |
| 2026-06-17 | Meeting | [[Meetings/2026-06-17 Mock Site Visit Debrief|2026-06-17 Mock Site Visit Debrief]] |
| 2026-07-08 | Decision | [[Decisions/DEC-11 Cap infrastructure spend and reprioritise WS4|DEC-11 Cap infrastructure spend and reprioritise WS4]] |
| 2026-07-08 | Meeting | [[Meetings/2026-07-08 Budget Mid-year Review|2026-07-08 Budget Mid-year Review]] |
| 2026-08-12 | Decision | [[Decisions/DEC-12 Pay adjuncts for cohort hours|DEC-12 Pay adjuncts for cohort hours]] |
| 2026-08-12 | Meeting | [[Meetings/2026-08-12 Cohort 5 Retrospective|2026-08-12 Cohort 5 Retrospective]] |
| 2026-08-24 | Term start | [[Terms/Fall 2026|Fall 2026]] |
| 2026-08-26 | Decision | [[Decisions/DEC-13 Approve Year-2 plan and Cohort 6|DEC-13 Approve Year-2 plan and Cohort 6]] |
| 2026-08-26 | Decision | [[Decisions/DEC-14 Add AI competency to promotion criteria|DEC-14 Add AI competency to promotion criteria]] |
| 2026-08-26 | Decision | [[Decisions/DEC-15 Publish annual AI transparency report|DEC-15 Publish annual AI transparency report]] |
| 2026-08-26 | Meeting | [[Meetings/2026-08-26 AI Steering Committee — Year-1 Review|2026-08-26 AI Steering Committee — Year-1 Review]] |
